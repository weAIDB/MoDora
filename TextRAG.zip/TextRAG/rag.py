import re
import numpy as np
import json
import os
from pathlib import Path
from openai import OpenAI
from sentence_transformers import SentenceTransformer
from typing import List
import time
from tqdm import tqdm

API_KEY = ""
API_URL = ""
MODEL = ""

def chunk_text(text: str) -> List[str]:
    if not text:
        return []

    max_len = 300
    overlap = 50
    soft_break_pattern = re.compile(r"[ \t,.;:!?，。；：！？、\-—]")

    n = len(text)
    i = 0
    chunks: List[str] = []

    while i < n:
        end = min(i + max_len, n)
        if end == n:
            chunks.append(text[i:end])
            break

        cut = -1
        last_nl = text.rfind("\n", i + int(max_len * 0.5), end)
        if last_nl != -1 and last_nl > i:
            cut = last_nl + 1

        if cut == -1:
            search_start = i + int(max_len * 0.5)
            window = text[search_start:end]
            for pos in range(len(window) - 1, -1, -1):
                if soft_break_pattern.match(window[pos]):
                    cut = search_start + pos + 1
                    break

        if cut == -1 or cut <= i:
            cut = end

        chunks.append(text[i:cut])
        i = max(0, cut - overlap)
        if i < cut - overlap:
            i = cut

    return chunks

# LLM
prompt_template = """
### Instruction
Return a concise answer for the query based on the given information. 

### Query
{query}

### Information
{info}
"""

def gpt_generate(prompt, key=API_KEY, url=API_URL, base_model = MODEL):
    # Call LLM
    client = OpenAI(
        base_url=url,
        api_key=key
    )
    res = ""
    cnt = 0
    if len(prompt) > 100000:
        prompt = prompt[0:100000]

    while cnt < 100:
        try:
            response = client.chat.completions.create(
                model=base_model,
                messages=[
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature = 1
            )
            res = response.choices[0].message.content
            return res

        except Exception as e:
            cnt += 1
            print(f"LLM Error: {e}. Try for time {cnt}！")
            import time; time.sleep(0.1)

    return res

def generate_answer(query, info):
    prompt = prompt_template.format(query=query, info=info)
    return gpt_generate(prompt)

# Embedding
model = SentenceTransformer("Qwen/Qwen3-Embedding-8B")

def call_qwen_em(query, document, k=3):
    chunks = chunk_text(document)
    
    query_emb = model.encode([query], prompt_name="query")
    chunk_embs = model.encode(chunks)
    similarities = model.similarity(query_emb, chunk_embs)[0]
    
    top_indices = np.argsort(-similarities)[:k]
    relevant_chunks = [chunks[i] for i in top_indices]
    
    context = "\n\n".join(relevant_chunks)
    answer = generate_answer(query, context)
    return answer

def process_val_dataset(val_path: str, markdown_dir: str, output_path: str):
    with open(val_path, "r", encoding="utf-8") as f:
        val_data = json.load(f)

    for i, item in enumerate(tqdm(val_data, desc="Processing...")):
        doc_id = item["pdf_id"]  
        question = item["question"]

        md_path = Path(markdown_dir) / f"{doc_id.replace('.pdf', '')}.md" 

        if not md_path.exists():
            print(f"Markdown file not found: {md_path}")
            item["prediction"] = "Error: Markdown file not found"
            continue

        try:
            with open(md_path, "r", encoding="utf-8") as f:
                document = f.read()

            answer = call_qwen_em(question, document)
            item["prediction"] = answer

        except Exception as e:
            print(f"Error in parsing item {item['questionId']} : {str(e)}")
            item["prediction"] = f"Error: {str(e)[:100]}"

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(val_data, f, ensure_ascii=False, indent=2)

if __name__ == "__main__":
    val_json_path = ""
    markdown_directory = ""
    output_json_path = ""
    
    Path(output_json_path).parent.mkdir(parents=True, exist_ok=True)
    
    process_val_dataset(val_json_path, markdown_directory, output_json_path)
