from pathlib import Path
from paddleocr import PPStructureV3
import os
import time

def process_pdf_folder(input_folder: str, output_folder: str):
    Path(output_folder).mkdir(parents=True, exist_ok=True)
    
    pdf_files = []
    for root, _, files in os.walk(input_folder):
        for file in files:
            if file.lower().endswith(".pdf"):
                pdf_files.append(os.path.join(root, file))
    
    if not pdf_files:
        return
    
    pipeline = PPStructureV3()
    
    for i, pdf_path in enumerate(pdf_files):
        start_time = time.time()
        
        try:
            output = pipeline.predict(input=pdf_path)
            
            markdown_list = []
            markdown_images = []
            for res in output:
                md_info = res.markdown
                markdown_list.append(md_info)
                markdown_images.append(md_info.get("markdown_images", {}))
            
            markdown_texts = pipeline.concatenate_markdown_pages(markdown_list)
            
            pdf_name = Path(pdf_path).stem
            mkd_file_path = Path(output_folder) / f"{pdf_name}.md"
            
            mkd_file_path.parent.mkdir(parents=True, exist_ok=True)
            with open(mkd_file_path, "w", encoding="utf-8") as f:
                f.write(markdown_texts)
            
            for item in markdown_images:
                if item:
                    for path, image in item.items():
                        img_file_path = Path(output_folder) / path
                        img_file_path.parent.mkdir(parents=True, exist_ok=True)
                        image.save(img_file_path)
            
            elapsed = time.time() - start_time
            
        except Exception as e:
            continue
    
if __name__ == "__main__":
    input_folder = ""  
    output_folder = ""  
    
    process_pdf_folder(input_folder, output_folder)
