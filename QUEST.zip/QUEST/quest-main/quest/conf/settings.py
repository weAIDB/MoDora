import os
from openai import OpenAI
import tiktoken

from quest.db.connector.connector import create_opengauss_engine

opengauss_conn = create_opengauss_engine()

current_file_path = os.path.abspath(__file__)
dir_name= os.path.dirname(current_file_path)
ABS_PROJECT_ROOT_PATH = "/data/QUEST/jzshe/project/quest"

JOIN_EDIT_DISTANCE_THRESHOLD = 0.8
JOIN_SEMANTIC_THRESHOLD = 0.9

RETRIEVE_FULL_THRESHOLD = 0.1


# LOG
RELATIVE_PROJECT_ROOT_PATH = os.path.join(dir_name, "../..")

LOG_DIR = os.path.join(dir_name, "../tests/log")
LOG_DIR_NAME = os.path.join(LOG_DIR, "zendb_log_sampling.log") # "quest.log"

# local small model
LOCAL_MODEL_DIR = os.path.join(ABS_PROJECT_ROOT_PATH, "model/")

DATASET_DIR = os.path.join(ABS_PROJECT_ROOT_PATH, "data/dataset/")

# index file
INDEX_ROOT_DIR = os.path.join(RELATIVE_PROJECT_ROOT_PATH, "data/index/")

# embedding model
# model = "API" / "E5" / "BGE"

EMBEDDING_MODEL = "API"

# LLM

API_BASE =  "https://aihubmix.com/v1"  
LLM_MODEL = 'openai/gpt-4.1-mini'


API_EMB_MODEL = "text-embedding-3-large"
API_EMB_API_BASE =  "https://aihubmix.com/v1" 
API_EMB_API_KEY = " "

GPT_MODEL = 'openai/gpt-4.1-mini'
GPT_API_BASE =  "https://aihubmix.com/v1" 
GPT_API_KEY =  " "


client = OpenAI(
    base_url="https://aihubmix.com/v1",
    api_key=" "
)

LLM_BATCH_SIZE = 10

os.environ['OPENAI_API_KEY'] = GPT_API_KEY
os.environ['OPENAI_BASE'] = "https://aihubmix.com/v1"
enc = tiktoken.get_encoding("cl100k_base")

Enc_token_cnt = enc

def count_tokens(text):
    tokens = Enc_token_cnt.encode(text)
    return len(tokens)



# SAMPLE

SAMPLE_NUM = 5
TOPK = 20

ZENDB_TOPK = 20

GROUP_SAMPLE_NUM = 3

# CLUSTER

N_CLUSTERS = 3

# others

VALUE_OP = ['<', '>', '>=', '<=']
