from __future__ import annotations

from typing import List

import pandas as pd

from ..evaluator_types import KeySpec
from ..utils.normalize import normalize_str
from .string_join import pd_string_inner_join


def _build_joint_keys_for_groupby(df: "pd.DataFrame", primary_keys_list: List[KeySpec]) -> pd.Series:
	"""构造 GROUP BY 情况下的 `_joint_keys_`。

	- 单列：标准化后直接作为键
	- 多列：对列名按字典序排列后，将各列标准化，使用 '||' 连接
	"""
	if len(primary_keys_list) == 0:
		raise KeyError("primary_keys_list 为空，无法构造 joint keys")
	missing_cols = [c for c in primary_keys_list if c not in df.columns]
	if missing_cols:
		raise KeyError(f"缺失列: {missing_cols}")
	cols = sorted(list(primary_keys_list))
	if len(cols) == 1:
		col = cols[0]
		return df[col].astype(str).map(normalize_str)
	# 多列
	parts = [df[c].astype(str).map(normalize_str) for c in cols]
	return pd.Series(['||'.join(vals) for vals in zip(*parts)], index=df.index)


def _build_joint_keys_for_no_groupby(df: "pd.DataFrame", primary_keys_list: List[KeySpec]) -> pd.Series:
	"""构造非 GROUP BY 情况下的 `_joint_keys_`。

	约定：primary_keys_list 为一个或多个 `table.id` 风格的主键列名；
	- 单表：直接使用该列
	- 多表：按表名（即列名前缀点号前部分）排序后连接
	"""
	if len(primary_keys_list) == 0:
		raise KeyError("primary_keys_list 为空，无法构造 joint keys")
	missing_cols = [c for c in primary_keys_list if c not in df.columns]
	if missing_cols:
		raise KeyError(f"缺失列: {missing_cols}")

	def table_prefix(col: str) -> str:
		return col.split('.', 1)[0] if '.' in col else col

	if len(primary_keys_list) == 1:
		col = primary_keys_list[0]
		return df[col].astype(str).map(normalize_str)
	# 多表 id，按表名前缀排序
	sorted_cols = sorted(primary_keys_list, key=table_prefix)
	parts = [df[c].astype(str).map(normalize_str) for c in sorted_cols]
	return pd.Series(['||'.join(vals) for vals in zip(*parts)], index=df.index)


def _check_unique(series: pd.Series, who: str) -> None:
	# 唯一性检查
	dupes = series.duplicated(keep=False)
	if dupes.any():
		vals = series[dupes].head(5).tolist()
		raise ValueError(f"{who} 出现重复 _joint_keys_，示例: {vals}")


def align_pred_res(
	primary_keys_list: List[KeySpec],
	pred_df: "pd.DataFrame",
	res_df: "pd.DataFrame",
	group_by_flag: bool,
) -> "pd.DataFrame":
	"""返回对齐后的 `aligned_res_pred_df`。

	列顺序：res_joint_keys_, pred_joint_keys_, 然后成对的 res_<col>/pred_<col>。
	"""
	if not isinstance(pred_df, pd.DataFrame) or not isinstance(res_df, pd.DataFrame):
		raise TypeError("pred_df 与 res_df 必须是 pandas.DataFrame")

	# 1) 构造 joint keys
	if group_by_flag:
		pred_joint = _build_joint_keys_for_groupby(pred_df, primary_keys_list)
		res_joint = _build_joint_keys_for_groupby(res_df, primary_keys_list)
	else:
		pred_joint = _build_joint_keys_for_no_groupby(pred_df, primary_keys_list)
		res_joint = _build_joint_keys_for_no_groupby(res_df, primary_keys_list)

	# 2) 唯一性检查
	_check_unique(pred_joint, "pred_df")
	_check_unique(res_joint, "res_df")

	# 保存副本并添加内部键列
	pred_tmp = pred_df.copy()
	res_tmp = res_df.copy()
	pred_tmp['_joint_keys_'] = pred_joint
	res_tmp['_joint_keys_'] = res_joint

	# 3) 对齐
	if group_by_flag:
		# 模糊 1-1 join，优先精确，必要时可加二阶段粗筛（此处默认 precise）
		joined = pd_string_inner_join(
			left_df=res_tmp,  # 以 res 为左
			right_df=pred_tmp,
			join_col='_joint_keys_',
			fuse_match_type="precise",
			fuse_block_type=None,
			join_type="11",
		)
		# joined 中保留两侧键列
		res_used = joined['_joint_keys__left']
		pred_used = joined['_joint_keys__right']
	else:
		# 无 GB：排序后精确对齐，取交集
		left = res_tmp.sort_values('_joint_keys_')
		right = pred_tmp.sort_values('_joint_keys_')
		common = sorted(set(left['_joint_keys_']).intersection(set(right['_joint_keys_'])))
		if len(common) == 0:
			# 返回空对齐
			return pd.DataFrame({
				"res_joint_keys_": pd.Series([], dtype=object),
				"pred_joint_keys_": pd.Series([], dtype=object),
			})
		left = left[left['_joint_keys_'].isin(common)]
		right = right[right['_joint_keys_'].isin(common)]
		joined = left.merge(right, on='_joint_keys_', suffixes=('_left', '_right'))
		res_used = joined['_joint_keys_']
		pred_used = joined['_joint_keys_']

	# 4) 拼接列，添加前缀
	# 生成输出列：res_* 和 pred_*（排除内部 _joint_keys_，其余全部保留）
	res_cols = [c for c in res_df.columns]
	pred_cols = [c for c in pred_df.columns]

	# 从 joined 中抽取相应列
	output = pd.DataFrame({
		"res_joint_keys_": res_used.values,
		"pred_joint_keys_": pred_used.values,
	})

	for c in res_cols:
		colname = f"res_{c}"
		src = f"{c}_left" if f"{c}_left" in joined.columns else c
		if src in joined.columns:
			output[colname] = joined[src].values

	for c in pred_cols:
		colname = f"pred_{c}"
		src = f"{c}_right" if f"{c}_right" in joined.columns else c
		if src in joined.columns:
			output[colname] = joined[src].values

	return output


