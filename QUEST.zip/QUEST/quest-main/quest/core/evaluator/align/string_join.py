from __future__ import annotations

from typing import Optional, Literal, List, Tuple

import pandas as pd

from ..evaluator_types import FuseMatchType, JoinType
from ..utils.normalize import normalize_str
from ..utils.blocking import blocking_filter
from ..matchers.edit_distance import edit_distance_aligned_match
from ..matchers.semantic_sim import semantic_sim_aligned_match, TfidfEmbeddingModel
from ..matchers.llm import llm_aligned_match


def _precise_match(left_values: List[str], right_values: List[str]) -> List[Tuple[int, int]]:
	index_right_by_value: dict[str, List[int]] = {}
	for j, rv in enumerate(right_values):
		index_right_by_value.setdefault(rv, []).append(j)
	results: List[Tuple[int, int]] = []
	for i, lv in enumerate(left_values):
		candidates = index_right_by_value.get(lv, [])
		for j in candidates:
			results.append((i, j))
	return results


def _greedy_11_from_pairs(pairs: List[Tuple[int, int]]) -> List[Tuple[int, int]]:
	used_left: set[int] = set()
	used_right: set[int] = set()
	result: List[Tuple[int, int]] = []
	for i, j in pairs:
		if i in used_left or j in used_right:
			continue
		used_left.add(i)
		used_right.add(j)
		result.append((i, j))
	return result


def _apply_fuzzy(
	left_values: List[str],
	right_values: List[str],
	fuse_match_type: FuseMatchType,
	candidate_pairs: List[Tuple[int, int]],
	**kwargs,
) -> List[Tuple[int, int]]:
	if not candidate_pairs:
		return []
	if fuse_match_type == "precise":
		return candidate_pairs

	# 收集候选文本对
	left_samples = [left_values[i] for i, _ in candidate_pairs]
	right_samples = [right_values[j] for _, j in candidate_pairs]

	if fuse_match_type == "edit_distance":
		tau = int(kwargs.get("tau", 1))
		mask = edit_distance_aligned_match(left_samples, right_samples, tau=tau)
	elif fuse_match_type == "semantic_sim":
		tau = float(kwargs.get("tau", 0.7))
		model = kwargs.get("embedding_model") or TfidfEmbeddingModel()
		mask = semantic_sim_aligned_match(left_samples, right_samples, embedding_model=model, tau=tau)
	elif fuse_match_type == "llm":
		api_model = kwargs.get("api_model", "gpt-3.5-turbo")
		api_base = kwargs.get("api_base", "")
		api_key = kwargs.get("api_key", "")
		mask = llm_aligned_match(left_samples, right_samples, api_model=api_model, api_base=api_base, api_key=api_key)
	else:
		raise ValueError(f"未知的 fuse_match_type: {fuse_match_type}")

	return [pair for pair, ok in zip(candidate_pairs, mask) if ok]


def pd_string_inner_join(
	left_df: "pd.DataFrame",
	right_df: "pd.DataFrame",
	join_col: str,
	fuse_match_type: FuseMatchType = "precise",
	fuse_block_type: Optional[Literal["edit_distance", "semantic_sim"]] = None,
	join_type: JoinType = "11",
	**matcher_kwargs,
) -> "pd.DataFrame":
	"""对字符串列进行内连接。

	流程：
	1) 精确匹配（normalize 后完全相等）
	2) 对未命中部分可选粗筛（blocking）
	3) 对候选进行模糊匹配（edit_distance/semantic_sim/llm/precise）
	4) 根据 join_type 选择 1-1 贪心或多对多
	"""
	if join_type not in ("11", "mm"):
		raise ValueError("join_type 仅支持 '11' 与 'mm'")
	if join_col not in left_df.columns or join_col not in right_df.columns:
		raise KeyError(f"join_col '{join_col}' 不在输入 DataFrame 中")

	left_values = [normalize_str(v) for v in left_df[join_col].tolist()]
	right_values = [normalize_str(v) for v in right_df[join_col].tolist()]

	# 1) 精确匹配
	precise_pairs = _precise_match(left_values, right_values)
	matched_left = {i for i, _ in precise_pairs}
	matched_right = {j for _, j in precise_pairs}

	# 2) 剩余未命中进入粗筛
	remaining_left = [i for i in range(len(left_values)) if i not in matched_left]
	remaining_right = [j for j in range(len(right_values)) if j not in matched_right]
	block_pairs: List[Tuple[int, int]] = []
	if remaining_left and remaining_right and fuse_block_type is not None:
		lv = [left_values[i] for i in remaining_left]
		rv = [right_values[j] for j in remaining_right]
		cand_local = blocking_filter(lv, rv, block_type=fuse_block_type)
		# 映射回原始索引
		block_pairs = [(remaining_left[i], remaining_right[j]) for i, j in cand_local]

	# 3) 对候选进行模糊匹配
	# 若 fuse_match_type == precise，则仅保留精确匹配
	fuzzy_candidates = block_pairs if fuse_block_type is not None else []
	selected = _apply_fuzzy(left_values, right_values, fuse_match_type, fuzzy_candidates, **matcher_kwargs)

	all_pairs = precise_pairs + selected

	# 4) 组装结果 DataFrame
	if join_type == "11":
		# 在 1-1 模式下，若任一方出现重复匹配，直接报错
		left_counts: dict[int, int] = {}
		right_counts: dict[int, int] = {}
		for i, j in all_pairs:
			left_counts[i] = left_counts.get(i, 0) + 1
			right_counts[j] = right_counts.get(j, 0) + 1
		if any(c > 1 for c in left_counts.values()) or any(c > 1 for c in right_counts.values()):
			raise ValueError("'11' 模式下出现一方重复匹配")
		pairs = all_pairs
	else:
		pairs = list(dict.fromkeys(all_pairs))  # 去重，保持顺序

	# 生成行选择并横向拼接
	left_rows = left_df.iloc[[i for i, _ in pairs]].reset_index(drop=True)
	right_rows = right_df.iloc[[j for _, j in pairs]].reset_index(drop=True)
	joined = pd.concat([left_rows.add_suffix("_left"), right_rows.add_suffix("_right")], axis=1)
	return joined


