# 组件 3：结果对齐（align\_pred\_res）

**文件**：`align/aligner.py`

**Signature**

```python
def align_pred_res(
    primary_keys_list: list[KeySpec],
    pred_df: "pd.DataFrame",
    res_df: "pd.DataFrame",
    group_by_flag: bool
) -> "pd.DataFrame":
    """Return aligned_res_pred_df"""
```

**Inputs**

* `primary_keys_list: list[KeySpec]`（`KeySpec = str`）
* `pred_df`（预测结果，无重复）
* `res_df`（GT 执行结果，无重复）
* `group_by_flag: bool`

**Outputs**

* `aligned_res_pred_df`：列顺序

  * `res_joint_keys_`, `pred_joint_keys_`,
  * `res_<col1>`, `pred_<col1>`, `res_<col2>`, `pred_<col2>`, ...

**Errors**

* `pred_df` 或 `res_df` 出现相同 `_joint_keys_` → `ValueError`
* 主键构造失败/缺列 → `KeyError`

**Steps**

1. **构造 `_joint_keys_`**

   * 若 `group_by_flag == True`：对 `primary_keys_list` 指定的每个列，直接从各自 DF 复制并串联（单列直接复制；多列按字典序以 `'||'` 连接）。
   * 若 `group_by_flag == False`：

     * 若有多表：对多个 `table.id` 按表名字典序连接；单表直接用 `table.id`。
2. **唯一性检查**：`pred_df['_joint_keys_']` 与 `res_df['_joint_keys_']` 必须各自唯一。
3. **对齐**

   * **有 GROUP BY**：对 `_joint_keys_` 使用**模糊匹配 1 对 1**（复用 `pd_string_inner_join`，`join_col='_joint_keys_'`, `join_type='11'`, `fuse_match_type` 默认 `"precise"`，失败后可再走 `"edit_distance"` 的二阶段匹配）；得到交集对齐对。
   * **无 GROUP BY**：将两侧 `_joint_keys_` 排序并**精确对齐**，取交集键。
4. **拼接列**

   * 针对 `res_df` 与 `pred_df` 的所有非 `_joint_keys_` 列，分别加前缀 `res_` 与 `pred_`，再按交集键 merge 成 `aligned_res_pred_df`。额外保留 `res_joint_keys_`、`pred_joint_keys_` 两列（为对齐后的 `_joint_keys_` 值）。

**Notes**

* 字段名前缀在**此处一次性**加好，后续 acc 计算直接按照 `res_<col>`、`pred_<col>` 读取。
* `_joint_keys_` 在返回结果中不再暴露，改用 `res_joint_keys_`/`pred_joint_keys_`。

---

# 组件 4：字符串模糊 Join（pd\_string\_inner\_join）

**文件**：`align/string_join.py`

**Signature**

```python
def pd_string_inner_join(
    left_df: "pd.DataFrame",
    right_df: "pd.DataFrame",
    join_col: str,
    fuse_match_type: FuseMatchType = "precise",
    fuse_block_type: Optional[Literal["edit_distance","semantic_sim"]] = None,
    join_type: JoinType = "11",
) -> "pd.DataFrame":
    """Return joined_df (inner)"""
```

**Inputs**

* `left_df`, `right_df`
* `join_col`
* `fuse_match_type`: `"llm" | "precise"`
* `fuse_block_type`: `None | "edit_distance" | "semantic_sim"`（**粗筛**）
* `join_type`: `"11"`（一对一）或 `"mm"`（多对多）

**Outputs**

* `joined_df`：简单横向拼接（假设列名不冲突，前置已是 `table.attr`）

**Errors**

* `"11"` 模式下出现一方重复匹配 → `ValueError`

**Steps**

1. 先做**精确匹配**（`normalize_str` 后判断相等）。把命中的 pair 直接加入结果。
2. 将未命中的样本进入**粗筛**（若指定 `fuse_block_type`），用 `blocking.py` 限缩候选。
   * `"edit_distance"`：调用 `matchers/edit_distance.py`。
   * `"semantic_sim"`：调用 `matchers/semantic_sim.py`。
3. 对候选使用指定 **模糊匹配器**：
   * `"precise"`：跳过（仅精确）。
   * `"llm"`：调用 `matchers/llm.py`（批量判别）。
4. `"11"`：左/右任一行一旦匹配成功即标记为已用，不再参与后续匹配；`"mm"` 则不做限制。
5. 返回 `joined_df`。

**Notes**

* 阈值默认见各 matcher，支持在调用层透传参数（通过可选 kwargs 设计，保持对外函数签名不变）。

---
