
---

# 项目规划总览

* **语言/环境**：Python 3.10+
* **核心依赖**：`pandas`, `numpy`, `duckdb`, `sqlglot`, `rapidfuzz`（编辑距离/相似度），`scikit-learn`（测试期内置向量化器），`litellm`（可选，LLM 模糊匹配）
* **包结构组织**： 所有的项目内包的导入全部使用相对路径导入，比如from .. import xxx，保证这个包可以作为一个子包直接缝到其他的包中。
* **目录结构**

  ```
  evaluator/
    __init__.py
    evaluator_types.py
    utils/
      __init__.py
      normalize.py
      casting.py
      metrics.py
      blocking.py
    sql/
      __init__.py
      parser.py
      executor.py
    align/
      __init__.py
      aligner.py
      string_join.py
    acc/
      __init__.py
      calc.py
      col_int.py
      col_float.py
      col_string.py
      col_set_int.py
      col_set_string.py
    matchers/
      __init__.py
      edit_distance.py
      semantic_sim.py
      llm.py      
    tests/
      test_sql_parser.py
      test_sql_executor.py
      test_align.py
      test_string_join.py
      test_acc_cols.py
      data_fixtures.py
  ```
* **交付物**：可导入的 Python 包 + 单元测试 + 最小端到端示例脚本（`examples/run_demo.py`）。

---

# 公共类型与常量（types.py）

* `KeySpec = str`  （类型别名，用于 `primary_keys_list`。与设计一致：`parse_sql` 返回 `list[str]`，`align_pred_res` 接口中的 `list[KeySpec]` 直接等价）
* `ColType = Literal["int","float","string","set_string","set_int"]`
* `FuseMatchType = Literal["edit_distance","semantic_sim","llm","precise"]`
* `JoinType = Literal["11","mm"]`

---



# 端到端流程（Pred2GroundTruthEvaluator 外观）

提供一个高层封装（可选实现在 `__init__.py`）：

```python
def evaluate_pipeline(sql: str, gt_table_dict: dict[str, "pd.DataFrame"],
                      pred_df: "pd.DataFrame",
                      col_type_dict: dict[str, ColType],
                      **kwargs) -> dict[str, dict[str, Any]]:
    converted_sql, pks, has_gb = parse_sql(sql)
    res_df = execute_sql_on_gt(converted_sql, gt_table_dict)
    aligned = align_pred_res(pks, pred_df, res_df, has_gb)
    return acc_calculation(aligned, len(pred_df), len(res_df), col_type_dict)
```

---

# 单元测试与样例数据（tests/）

1. **SQL 解析**

   * 单表无 GROUP BY：自动补 `id` 到 SELECT FROM。
   * 多表 JOIN 无 GROUP BY：`primary_keys_list` 为多表 `table.id`，按表名排序。
   * 有 GROUP BY：`primary_keys_list` 等于分组列列名；不补 `id`。
2. **SQL 执行**

   * 多表注册，`JOIN`、`WHERE`、`GROUP BY` 与聚合列一致。
   * 单表执行结果的 select from的列不需要加table_name前缀。
3. **对齐**

   * `group_by_flag=False`：两侧 `_joint_keys_` 精确对齐，重复键报错。
   * `group_by_flag=True`：`pd_string_inner_join` 1-1 成功对齐；未命中元素被正确剔除。
4. **字符串 Join**

   * `"precise"`、`"edit_distance"`、`"semantic_sim"`、`"llm"` 四种，覆盖 `"11"` 与 `"mm"`。
5. **列级准确率**

   * `int`：`"10,000"` vs `10000` 匹配。
   * `float`：考虑 `eps` 容忍。
   * `string`：精确+模糊结合。
   * `set_int`：`J(A,B)` 计算与阈值（>0）统计。
   * `set_string`：元素级 1-1 join 后计算 `J(A,B)`。
6. **边界**

   * 空表、仅一侧有数据、特殊字符/大小写/空白、非法数字、NaN/None。



# 游标（Cursor）实施顺序（不依赖用户确认即可逐步推进）

1. **搭骨架**：创建目录结构与 `pyproject.toml/requirements.txt`。
2. **实现 utils**：`normalize.py`、`casting.py`、`metrics.py`、`blocking.py`。
3. **SQL**：完成 `parse_sql`、`execute_sql_on_gt` 与对应测试。
4. **对齐**：完成 `align_pred_res`、`string_join` 与测试。
5. **Matchers**：实现 `edit_distance`、`semantic_sim`、`llm`（其中 `llm` 先空实现返回全 False，再补 litellm 调用），写测试。
6. **Acc**：按 5 个子函数实现与测试；再实现 `acc_calculation` 汇总。
7. **端到端**：`evaluate_pipeline` + 集成测试（含样例 SQL/DF）。
8. **示例脚本**：`examples/run_demo.py`，打印每列 P/R/F1 与样例 `matched_df` 预览。
9. **完善日志与异常信息**：所有关键路径加上上下文与参数摘要。

---

# 示例：关键函数的最小签名清单（便于 Cursor 快速生成骨架）

```python
# sql/parser.py
def parse_sql(sql: str) -> tuple[str, list[str], bool]: ...

# sql/executor.py
def execute_sql_on_gt(converted_sql: str, gt_table_dict: dict[str, "pd.DataFrame"]) -> "pd.DataFrame": ...

# align/aligner.py
def align_pred_res(primary_keys_list: list[str], pred_df: "pd.DataFrame",
                   res_df: "pd.DataFrame", group_by_flag: bool) -> "pd.DataFrame": ...

# align/string_join.py
def pd_string_inner_join(left_df: "pd.DataFrame", right_df: "pd.DataFrame", join_col: str,
                         fuse_match_type: "FuseMatchType" = "precise",
                         fuse_block_type: "Optional[Literal['edit_distance','semantic_sim']]" = None,
                         join_type: "JoinType" = "11") -> "pd.DataFrame": ...

# acc/calc.py
def acc_calculation(aligned_res_pred_df: "pd.DataFrame", len_pred_df: int, len_res_df: int,
                    col_type_dict: dict[str, "ColType"]) -> dict[str, dict[str, "Any"]]: ...

# acc/col_int.py
def acc_cal_col_int(aligned_res_pred_df: "pd.DataFrame", len_pred_df: int, len_res_df: int,
                    col_name: str) -> tuple[float,float,float,"pd.DataFrame"]: ...

# acc/col_float.py
def acc_cal_col_float(aligned_res_pred_df: "pd.DataFrame", len_pred_df: int, len_res_df: int,
                      col_name: str, eps: float = 1e-4) -> tuple[float,float,float,"pd.DataFrame"]: ...

# acc/col_string.py
def acc_cal_col_string(aligned_res_pred_df: "pd.DataFrame", len_pred_df: int, len_res_df: int,
                       col_name: str, fuse_match_type: "FuseMatchType" = "precise",
                       **matcher_kwargs) -> tuple[float,float,float,"pd.DataFrame"]: ...

# acc/col_set_int.py
def acc_cal_col_set_int(aligned_res_pred_df: "pd.DataFrame", len_pred_df: int, len_res_df: int,
                        col_name: str) -> tuple[float,float,float,"pd.DataFrame"]: ...

# acc/col_set_string.py
def acc_cal_col_set_string(aligned_res_pred_df: "pd.DataFrame", len_pred_df: int, len_res_df: int,
                           col_name: str, fuse_match_type: "FuseMatchType" = "precise",
                           **matcher_kwargs) -> tuple[float,float,float,"pd.DataFrame"]: ...

# matchers/edit_distance.py
def edit_distance_aligned_match(pred_val: list[str], res_val: list[str], tau: int) -> list[bool]: ...

# matchers/semantic_sim.py
class EmbeddingModelProto(Protocol):
    def _embed(self, sentences: list[str]) -> "np.ndarray": ...
def semantic_sim_aligned_match(pred_val: list[str], res_val: list[str],
                               embedding_model: "EmbeddingModelProto",
                               tau: float) -> list[bool]: ...

# matchers/llm.py
def llm_aligned_match(pred_val: list[str], res_val: list[str],
                      api_model: str, api_base: str, api_key: str) -> list[bool]: ...
```

---

# 验收清单（自测完成标准）

* [ ] 给定三种 SQL（无 GB、含 JOIN、含 GB），`parse_sql` 输出与期望一致，且 DuckDB 成功执行。
* [ ] `align_pred_res` 在 GB/非 GB 两类路径下均能正确对齐，重复键能被检测。
* [ ] 五类列准确率函数在样例数据上输出合理的 `precision/recall/F1`；
  其中 `set_*` 能正确计算 $J(A,B)$ 并产出 `set_matched_df`。
* [ ] `pd_string_inner_join` 在 `"11"`/`"mm"` 与四种 `fuse_match_type` 下均有覆盖测试。
* [ ] 端到端 `evaluate_pipeline` 返回字典结构满足规范，且 `matched_df`/`set_matched_df` 列集合正确。

---
