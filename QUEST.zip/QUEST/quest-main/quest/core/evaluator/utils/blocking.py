"""
粗筛策略工具

提供简单的粗筛策略实现，用于在模糊匹配前加速处理。
"""

from typing import List, Tuple, Optional
from rapidfuzz import fuzz


def blocking_filter(
    left_values: List[str], 
    right_values: List[str],
    block_type: str = "edit_distance",
    similarity_threshold: float = 0.3
) -> List[Tuple[int, int]]:
    """
    提供简单的粗筛策略实现
    
    策略包括：
    3. 低阈值相似度预筛：使用快速相似度算法预筛
    
    Args:
        left_values: 左侧字符串列表
        right_values: 右侧字符串列表
        block_type: 粗筛类型 ("edit_distance" 或 "semantic_sim")
        similarity_threshold: 相似度阈值
        
    Returns:
        候选对列表 [(left_idx, right_idx), ...]
    """
    candidates = []
    
    for i, left_val in enumerate(left_values):
        for j, right_val in enumerate(right_values):
            # 跳过空值
            if not left_val or not right_val:
                continue
            
            
            # 3. 相似度预筛
            if block_type == "edit_distance":
                # 使用编辑距离的快速预筛
                similarity = fuzz.ratio(left_val.lower(), right_val.lower()) / 100.0
            elif block_type == "semantic_sim":
                # 使用部分字符串匹配作为语义相似度的快速近似
                similarity = fuzz.partial_ratio(left_val.lower(), right_val.lower()) / 100.0
            else:
                # 默认使用编辑距离
                similarity = fuzz.ratio(left_val.lower(), right_val.lower()) / 100.0
            
            if similarity >= similarity_threshold:
                candidates.append((i, j))
    
    return candidates


