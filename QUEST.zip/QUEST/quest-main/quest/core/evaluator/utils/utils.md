# utils通用工具

## utils/normalize.py

* Signature: `normalize_str(s: str) -> str`
* 作用：统一字符串比较前的清洗（去前后空白、转小写、压缩连续空白、去常见分隔符千位符`,`等，但不改变语义）

## utils/casting.py

* `to_int_like(x) -> Optional[int]`：兼容 `"10,000" -> 10000`
* `to_float_like(x) -> Optional[float]`：兼容 `"1,234.50" -> 1234.5`
* `parse_set_int(cell: str) -> set[int]`：按 `"||"` 切分并转 int
* `parse_set_str(cell: str) -> set[str]`：按 `"||"` 切分并 `normalize_str`

## utils/metrics.py

* 精确率/召回率/F1：

  * $\text{Precision} = \frac{\text{matched}}{\text{len\_pred\_df}}$
  * $\text{Recall} = \frac{\text{matched}}{\text{len\_res\_df}}$
  * $F1 = 2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}}$
* Jaccard：

  * $J(A,B) = \frac{|A \cap B|}{|A \cup B|}$

## utils/blocking.py

* 提供简单的**粗筛**策略实现（低阈值相似度预筛），供 `pd_string_inner_join` 在模糊匹配前加速用。

---
