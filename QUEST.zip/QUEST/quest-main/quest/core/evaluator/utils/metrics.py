"""
指标计算工具

提供精确率、召回率、F1分数和Jaccard相似度等指标的计算功能。
"""

from typing import Tuple, Union, Set


def calculate_precision_recall_f1(matched: int, len_pred: int, len_res: int) -> Tuple[float, float, float]:
    """
    计算精确率、召回率和F1分数
    
    公式：
    - Precision = matched / len_pred
    - Recall = matched / len_res  
    - F1 = 2 * (Precision * Recall) / (Precision + Recall)
    
    Args:
        matched: 匹配的数量
        len_pred: 预测结果的总数
        len_res: 真实结果的总数
        
    Returns:
        (precision, recall, f1) 元组
        
    Examples:
        >>> calculate_precision_recall_f1(8, 10, 12)
        (0.8, 0.6666666666666666, 0.7272727272727273)
    """
    # 避免除零错误
    if len_pred == 0:
        precision = 0.0
    else:
        precision = matched / len_pred
    
    if len_res == 0:
        recall = 0.0
    else:
        recall = matched / len_res
    
    # 计算F1分数
    if precision + recall == 0:
        f1 = 0.0
    else:
        f1 = 2 * (precision * recall) / (precision + recall)
    
    return precision, recall, f1


def calculate_jaccard(set_a: Union[Set, list], set_b: Union[Set, list]) -> float:
    """
    计算Jaccard相似度
    
    公式：J(A,B) = |A ∩ B| / |A ∪ B|
    
    Args:
        set_a: 集合A
        set_b: 集合B
        
    Returns:
        Jaccard相似度，范围[0, 1]
        
    Examples:
        >>> calculate_jaccard({1, 2, 3}, {2, 3, 4})
        0.5
        >>> calculate_jaccard({1, 2}, {3, 4})
        0.0
        >>> calculate_jaccard({1, 2}, {1, 2})
        1.0
    """
    # 转换为集合
    if not isinstance(set_a, set):
        set_a = set(set_a)
    if not isinstance(set_b, set):
        set_b = set(set_b)
    
    # 计算交集和并集
    intersection = set_a & set_b
    union = set_a | set_b
    
    # 避免除零错误
    if len(union) == 0:
        return 1.0  # 两个空集合的Jaccard为1
    
    return len(intersection) / len(union)
