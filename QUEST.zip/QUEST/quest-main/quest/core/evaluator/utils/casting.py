"""
类型转换工具

提供各种数据类型的转换功能，包括数字转换和集合解析。
"""

import re
from typing import Optional, Set


def to_int_like(x) -> Optional[int]:
    """
    将输入转换为整数，兼容千位分隔符格式
    
    Args:
        x: 输入值
        
    Returns:
        转换后的整数，如果转换失败返回None
        
    Examples:
        >>> to_int_like("10,000")
        10000
        >>> to_int_like("123")
        123
        >>> to_int_like("abc")
        None
    """
    if x is None:
        return None
    
    # 转换为字符串
    s = str(x).strip()
    
    if not s:
        return None
    
    # 移除千位分隔符
    s = re.sub(r',', '', s)
    
    # 尝试转换为整数
    try:
        return int(s)
    except ValueError:
        return None


def to_float_like(x) -> Optional[float]:
    """
    将输入转换为浮点数，兼容千位分隔符格式
    
    Args:
        x: 输入值
        
    Returns:
        转换后的浮点数，如果转换失败返回None
        
    Examples:
        >>> to_float_like("1,234.50")
        1234.5
        >>> to_float_like("123.45")
        123.45
        >>> to_float_like("abc")
        None
    """
    if x is None:
        return None
    
    # 转换为字符串
    s = str(x).strip()
    
    if not s:
        return None
    
    # 移除千位分隔符
    s = re.sub(r',', '', s)
    
    # 尝试转换为浮点数
    try:
        return float(s)
    except ValueError:
        return None


def parse_set_int(cell: str) -> Set[int]:
    """
    按 "||" 切分字符串并转换为整数集合
    
    Args:
        cell: 包含 "||" 分隔的整数字符串
        
    Returns:
        整数集合
        
    Examples:
        >>> parse_set_int("1||2||3")
        {1, 2, 3}
        >>> parse_set_int("10,000||20,000")
        {10000, 20000}
    """
    if not cell or cell.strip() == "":
        return set()
    
    # 按 "||" 切分
    parts = cell.split("||")
    
    result = set()
    for part in parts:
        part = part.strip()
        if part:
            # 使用 to_int_like 处理千位分隔符
            val = to_int_like(part)
            if val is not None:
                result.add(val)
    
    return result


def parse_set_str(cell: str) -> Set[str]:
    """
    按 "||" 切分字符串并标准化每个元素
    
    Args:
        cell: 包含 "||" 分隔的字符串
        
    Returns:
        标准化后的字符串集合
        
    Examples:
        >>> parse_set_str("hello||world||test")
        {'hello', 'world', 'test'}
        >>> parse_set_str("Hello||World")
        {'hello', 'world'}
    """
    if not cell or cell.strip() == "":
        return set()
    
    # 按 "||" 切分
    parts = cell.split("||")
    
    result = set()
    for part in parts:
        part = part.strip()
        if part:
            # 使用 normalize_str 标准化
            from .normalize import normalize_str
            normalized = normalize_str(part)
            if normalized:
                result.add(normalized)
    
    return result
