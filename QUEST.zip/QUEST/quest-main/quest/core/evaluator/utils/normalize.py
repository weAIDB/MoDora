"""
字符串标准化工具

提供统一的字符串比较前的清洗功能。
"""

import re
from typing import Optional


def normalize_str(s: str) -> str:
    """
    统一字符串比较前的清洗
    
    功能：
    - 去前后空白
    - 转小写
    - 压缩连续空白
    - 去常见分隔符千位符等，但不改变语义
    
    Args:
        s: 原始字符串
        
    Returns:
        标准化后的字符串
    """
    if s is None:
        return ""
    
    # 转换为字符串
    s = str(s)
    
    # 去前后空白
    s = s.strip()
    
    # 转小写
    s = s.lower()
    
    # 压缩连续空白为单个空格
    s = re.sub(r'\s+', ' ', s)
    
    # 去常见分隔符千位符（保留小数点）
    # 移除千位分隔符，如 "1,234.56" -> "1234.56"
    s = re.sub(r',(?=\d)', '', s)
    
    # 移除其他常见分隔符（分号、冒号等）
    s = re.sub(r'[;:]', ' ', s)
    
    # 再次压缩空白
    s = re.sub(r'\s+', ' ', s)
    
    # 最终去前后空白
    s = s.strip()
    
    return s
