"""
通用工具模块

提供字符串标准化、类型转换、指标计算和粗筛策略等通用功能。
"""

from .normalize import normalize_str
from .casting import to_int_like, to_float_like, parse_set_int, parse_set_str
from .metrics import calculate_precision_recall_f1, calculate_jaccard
from .blocking import blocking_filter

__all__ = [
    'normalize_str',
    'to_int_like',
    'to_float_like', 
    'parse_set_int',
    'parse_set_str',
    'calculate_precision_recall_f1',
    'calculate_jaccard',
    'blocking_filter'
]
