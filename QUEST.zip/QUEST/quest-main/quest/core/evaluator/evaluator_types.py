"""
公共类型与常量定义
"""

from typing import Literal

# 类型别名，用于 primary_keys_list
KeySpec = str

# 列类型定义
ColType = Literal["int", "float", "string", "set_string", "set_int"]

# 模糊匹配类型
FuseMatchType = Literal["edit_distance", "semantic_sim", "llm", "precise"]

# Join类型
JoinType = Literal["11", "mm"]
