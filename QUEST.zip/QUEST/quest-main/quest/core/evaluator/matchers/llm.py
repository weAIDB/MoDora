from __future__ import annotations

from typing import List


def _to_text(value: object) -> str:
    if value is None:
        return ""
    return str(value)


def _parse_bool_from_text(text: str) -> bool:
    normalized = text.strip().lower()
    if normalized == "true":
        return True
    if normalized == "false":
        return False
    # Fallback: prefer True if it clearly appears and "false" does not
    return ("true" in normalized) and ("false" not in normalized)


def llm_aligned_match(
    pred_val: List[str],
    res_val: List[str],
    api_model: str,
    api_base: str,
    api_key: str,
) -> List[bool]:
    """Use an LLM to judge pairwise semantic equivalence and return booleans.

    This function attempts to call litellm.batch_completion. If litellm is not
    available or any error occurs during the call, it gracefully falls back to
    returning all False.
    """
    if len(pred_val) != len(res_val):
        raise ValueError("pred_val 与 res_val 长度不一致，无法逐对比对")

    n = len(pred_val)
    if n == 0:
        return []

    try:  # Optional dependency
        from litellm import batch_completion  # type: ignore
    except Exception:
        return [False] * n

    system_prompt = (
    "You are an entity matching assistant. Given 2 strings A and B, determine whether they refer to the same entity (based on semantic judgment). "
    "Only output True or False, do not output any other content."
    )

    messages_batch = []
    for a, b in zip(pred_val, res_val):
        a_text = _to_text(a)
        b_text = _to_text(b)
        user_prompt = f"Text A: {a_text}\nText B: {b_text}\nPlease answer: True or False"
        messages_batch.append([
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ])

    try:
        responses = batch_completion(
            model=api_model,
            messages=messages_batch,
            api_base=api_base,
            api_key=api_key,
            temperature=0,
        )
    except Exception:
        return [False] * n

    results: List[bool] = []
    for resp in responses:
        # litellm returns OpenAI-like objects; support both attr and dict styles
        content: str | None = None
        try:
            content = resp.choices[0].message["content"]  # type: ignore[attr-defined]
        except Exception:
            try:
                content = resp["choices"][0]["message"]["content"]  # type: ignore[index]
            except Exception:
                content = None
        results.append(_parse_bool_from_text(content or ""))
    return results


