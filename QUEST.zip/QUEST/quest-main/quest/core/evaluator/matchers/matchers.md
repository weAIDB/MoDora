# 组件 7：Matchers

`acc/matchers`

* **edit\_distance.py**

  ```python
  def edit_distance_aligned_match(pred_val: list[str], res_val: list[str], tau: int) -> list[bool]:
      """逐对比对，Levenshtein 距离 < tau 视为匹配（用 rapidfuzz.distance.Levenshtein）"""
  ```
* **semantic\_sim.py**

  ```python
  class EmbeddingModelProto(Embeddings):
      def _embed(self, sentences: list[str]) -> "np.ndarray": ...
      # 该接口符合from langchain_core.embeddings import Embeddings类的要求

  def semantic_sim_aligned_match(
      pred_val: list[str],
      res_val: list[str],
      embedding_model: EmbeddingModelProto,
      tau: float
  ) -> list[bool]:
      """批量嵌入，计算余弦相似度 >= tau 视为匹配"""
  ```

  > 测试阶段可提供一个基于 `sklearn.feature_extraction.text.TfidfVectorizer` 的轻量嵌入器以去除外部依赖。
* **llm.py**

  ```python
  def llm_aligned_match(
      pred_val: list[str], res_val: list[str],
      api_model: str, api_base: str, api_key: str
  ) -> list[bool]:
      """使用 litellm.batch_completion，按行输出 True/False"""
  ```

---
