from __future__ import annotations

from typing import List

from rapidfuzz.distance import Levenshtein


def _to_text(value: object) -> str:
    """Convert arbitrary value to string; map None to empty string."""
    if value is None:
        return ""
    return str(value)


def edit_distance_aligned_match(pred_val: List[str], res_val: List[str], tau: int) -> List[bool]:
    """Pairwise compare strings and decide a match by Levenshtein distance.

    A pair is considered matched when distance < tau.

    Parameters
    ----------
    pred_val: List[str]
        Predicted values aligned by index.
    res_val: List[str]
        Ground-truth/result values aligned by index.
    tau: int
        Strict threshold; distance < tau is a match.

    Returns
    -------
    List[bool]
        Boolean list per pair.
    """
    if tau is None or tau < 0:
        raise ValueError("tau 必须是非负整数")
    if len(pred_val) != len(res_val):
        raise ValueError("pred_val 与 res_val 长度不一致，无法逐对比对")

    matches: List[bool] = []
    for left_text, right_text in zip(pred_val, res_val):
        left = _to_text(left_text)
        right = _to_text(right_text)
        distance_value = Levenshtein.distance(left, right)
        matches.append(distance_value < tau)
    return matches


