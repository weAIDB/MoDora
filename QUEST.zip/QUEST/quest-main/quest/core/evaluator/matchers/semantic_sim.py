from __future__ import annotations

from typing import Protocol, List

import numpy as np

from langchain_core.embeddings import Embeddings

EmbeddingModelProto = Embeddings



def _to_text(value: object) -> str:
    if value is None:
        return ""
    return str(value)


def _l2_normalize_rows(matrix: "np.ndarray") -> "np.ndarray":
    if matrix.size == 0:
        return matrix
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    # Avoid divide-by-zero: where norm == 0, keep the row as zeros
    safe_norms = np.where(norms == 0.0, 1.0, norms)
    return matrix / safe_norms


def semantic_sim_aligned_match(
    pred_val: List[str],
    res_val: List[str],
    embedding_model: EmbeddingModelProto,
    tau: float,
) -> List[bool]:
    """Batch-embed two aligned string lists and compute cosine similarity per pair.

    A pair is considered matched when cosine similarity >= tau.
    """
    if tau is None:
        raise ValueError("tau 不能为空")
    if len(pred_val) != len(res_val):
        raise ValueError("pred_val 与 res_val 长度不一致，无法逐对比对")

    n = len(pred_val)
    if n == 0:
        return []

    left_texts = [_to_text(x) for x in pred_val]
    right_texts = [_to_text(x) for x in res_val]

    # One-shot embedding to ensure both sides share the same embedding space
    sentences = left_texts + right_texts
    embeddings = embedding_model._embed(sentences)
    if not isinstance(embeddings, np.ndarray):
        embeddings = np.asarray(embeddings)

    if embeddings.ndim != 2 or embeddings.shape[0] != len(sentences):
        raise ValueError("embedding_model._embed 返回的形状不正确，应为 (N, D)")

    left_vecs = embeddings[:n].astype(np.float32, copy=False)
    right_vecs = embeddings[n:].astype(np.float32, copy=False)

    left_norm = _l2_normalize_rows(left_vecs)
    right_norm = _l2_normalize_rows(right_vecs)

    # Cosine similarity for aligned rows is simply rowwise dot product
    sims = np.sum(left_norm * right_norm, axis=1)
    return [float(sim) >= float(tau) for sim in sims]


# A lightweight embedding model for testing to avoid external dependencies
try:
    from sklearn.feature_extraction.text import TfidfVectorizer  # type: ignore
except Exception:  # pragma: no cover - optional dependency
    TfidfVectorizer = None  # type: ignore


class TfidfEmbeddingModel:
    """A minimal TF-IDF embedding model for tests.

    This model fits a TF-IDF vectorizer on the provided sentences each call,
    returning dense vectors with a shared vocabulary for the batch.
    """

    def __init__(
        self,
        ngram_range: tuple[int, int] = (1, 2),
        lowercase: bool = True,
        max_features: int | None = None,
    ) -> None:
        self.ngram_range = ngram_range
        self.lowercase = lowercase
        self.max_features = max_features

    def _embed(self, sentences: List[str]) -> "np.ndarray":  # noqa: D401
        if TfidfVectorizer is None:
            raise RuntimeError("需要 scikit-learn 才能使用 TfidfEmbeddingModel")
        if len(sentences) == 0:
            return np.zeros((0, 0), dtype=np.float32)
        vectorizer = TfidfVectorizer(
            ngram_range=self.ngram_range,
            lowercase=self.lowercase,
            max_features=self.max_features,
        )
        matrix = vectorizer.fit_transform(sentences)
        return matrix.toarray().astype(np.float32, copy=False)


