from __future__ import annotations

from typing import Any

import pandas as pd

from ..evaluator_types import FuseMatchType
from ..utils.normalize import normalize_str
from ..utils.metrics import calculate_precision_recall_f1
from ..matchers import (
    edit_distance_aligned_match,
    semantic_sim_aligned_match,
    TfidfEmbeddingModel,
    llm_aligned_match,
)


def acc_cal_col_string(
    aligned_res_pred_df: "pd.DataFrame",
    len_pred_df: int,
    len_res_df: int,
    col_name: str,
    fuse_match_type: FuseMatchType = "precise",
    **matcher_kwargs: Any,
) -> tuple[float, float, float, "pd.DataFrame"]:
    """字符串列：精确匹配 + 余量一对一模糊匹配。

    步骤：
    1) 对 res_<col> 与 pred_<col> 分别标准化
    2) 先做精确匹配，记录命中行
    3) 对剩余行做一对一（同序）模糊匹配，成功则补充命中
    4) 指标按命中数量计算
    """
    res_col = f"res_{col_name}"
    pred_col = f"pred_{col_name}"
    for c in (res_col, pred_col, "res_joint_keys_", "pred_joint_keys_"):
        if c not in aligned_res_pred_df.columns:
            raise KeyError(f"缺少列: {c}")

    res_norm = aligned_res_pred_df[res_col].map(normalize_str)
    pred_norm = aligned_res_pred_df[pred_col].map(normalize_str)

    # 1) 精确匹配
    precise_mask = (res_norm == pred_norm) & res_norm.notna() & pred_norm.notna()

    # 2) 余量模糊匹配（同序对齐）
    remaining_idx = (~precise_mask).to_numpy().nonzero()[0].tolist()
    fuzzy_ok_idx: list[int] = []
    if remaining_idx:
        left_vals = [pred_norm.iloc[i] for i in remaining_idx]
        right_vals = [res_norm.iloc[i] for i in remaining_idx]
        if fuse_match_type == "precise":
            fuzzy_mask = [False] * len(remaining_idx)
        elif fuse_match_type == "edit_distance":
            tau = int(matcher_kwargs.get("tau", 1))
            fuzzy_mask = edit_distance_aligned_match(left_vals, right_vals, tau=tau)
        elif fuse_match_type == "semantic_sim":
            tau = float(matcher_kwargs.get("tau", 0.7))
            model = matcher_kwargs.get("embedding_model") or TfidfEmbeddingModel()
            fuzzy_mask = semantic_sim_aligned_match(left_vals, right_vals, embedding_model=model, tau=tau)
        elif fuse_match_type == "llm":
            api_model = matcher_kwargs.get("api_model", "gpt-3.5-turbo")
            api_base = matcher_kwargs.get("api_base", "")
            api_key = matcher_kwargs.get("api_key", "")
            fuzzy_mask = llm_aligned_match(left_vals, right_vals, api_model=api_model, api_base=api_base, api_key=api_key)
        else:
            raise ValueError(f"未知的 fuse_match_type: {fuse_match_type}")
        fuzzy_ok_idx = [remaining_idx[k] for k, ok in enumerate(fuzzy_mask) if ok]

    # 3) 合并命中
    hit_mask = precise_mask.copy()
    if fuzzy_ok_idx:
        hit_mask.iloc[fuzzy_ok_idx] = True

    matched = int(hit_mask.sum())
    precision, recall, f1 = calculate_precision_recall_f1(matched, len_pred_df, len_res_df)

    matched_df = aligned_res_pred_df.loc[hit_mask, [
        "res_joint_keys_",
        "pred_joint_keys_",
        res_col,
        pred_col,
    ]].reset_index(drop=True)

    return precision, recall, f1, matched_df


