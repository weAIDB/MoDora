from __future__ import annotations

import pandas as pd

from ..utils.casting import parse_set_int
from ..utils.metrics import calculate_precision_recall_f1, calculate_jaccard


def acc_cal_col_set_int(
    aligned_res_pred_df: "pd.DataFrame",
    len_pred_df: int,
    len_res_df: int,
    col_name: str,
) -> tuple[float, float, float, "pd.DataFrame"]:
    """集合整型列：逐行计算 Jaccard，相似度 > 0 计为命中。

    返回 set_matched_df：包含 res_joint_keys_, pred_joint_keys_, res_<col>, pred_<col>, jaccard_score
    """
    res_col = f"res_{col_name}"
    pred_col = f"pred_{col_name}"
    for c in (res_col, pred_col, "res_joint_keys_", "pred_joint_keys_"):
        if c not in aligned_res_pred_df.columns:
            raise KeyError(f"缺少列: {c}")

    res_sets = aligned_res_pred_df[res_col].astype(str).map(parse_set_int)
    pred_sets = aligned_res_pred_df[pred_col].astype(str).map(parse_set_int)

    jaccards = [calculate_jaccard(a, b) for a, b in zip(res_sets, pred_sets)]
    match_mask = pd.Series([score > 0.0 for score in jaccards], index=aligned_res_pred_df.index)
    matched = int(match_mask.sum())

    precision, recall, f1 = calculate_precision_recall_f1(matched, len_pred_df, len_res_df)

    set_matched_df = aligned_res_pred_df.loc[:, [
        "res_joint_keys_",
        "pred_joint_keys_",
        res_col,
        pred_col,
    ]].copy()
    set_matched_df["jaccard_score"] = jaccards
    set_matched_df = set_matched_df.loc[match_mask].reset_index(drop=True)

    return precision, recall, f1, set_matched_df


