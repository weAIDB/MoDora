from __future__ import annotations

from typing import Any

import pandas as pd

from ..evaluator_types import FuseMatchType
from ..utils.casting import parse_set_str
from ..utils.metrics import calculate_precision_recall_f1, calculate_jaccard
from ..align.string_join import pd_string_inner_join


def acc_cal_col_set_string(
    aligned_res_pred_df: "pd.DataFrame",
    len_pred_df: int,
    len_res_df: int,
    col_name: str,
    fuse_match_type: FuseMatchType = "precise",
    **matcher_kwargs: Any,
) -> tuple[float, float, float, "pd.DataFrame"]:
    """集合字符串列：元素级展开做 1-1 字符串 join 后按行统计 Jaccard。

    返回 set_matched_df：包含 res_joint_keys_, pred_joint_keys_, res_<col>, pred_<col>, jaccard_score
    """
    res_col = f"res_{col_name}"
    pred_col = f"pred_{col_name}"
    for c in (res_col, pred_col, "res_joint_keys_", "pred_joint_keys_"):
        if c not in aligned_res_pred_df.columns:
            raise KeyError(f"缺少列: {c}")

    # 1) 将 res/pred 集合列解析为 set[str]
    res_sets = aligned_res_pred_df[res_col].astype(str).map(parse_set_str)
    pred_sets = aligned_res_pred_df[pred_col].astype(str).map(parse_set_str)

    # 2) 展开为元素级长表，并保留行 id
    def explode_sets(sets: pd.Series, side: str) -> pd.DataFrame:
        rows = []
        for row_id, s in sets.items():
            if not s:
                continue
            for val in s:
                rows.append({"_row_id": row_id, col_name: val})
        return pd.DataFrame(rows, columns=["_row_id", col_name])

    left_long = explode_sets(res_sets, "res")
    right_long = explode_sets(pred_sets, "pred")

    # 3) 对元素级长表做一对一字符串 join（fuse 使用指定类型）
    if len(left_long) == 0 or len(right_long) == 0:
        joined_long = pd.DataFrame(columns=[f"{col_name}_left", f"{col_name}_right", "_row_id_left", "_row_id_right"])  # empty
    else:
        joined_long = pd_string_inner_join(
            left_df=left_long,
            right_df=right_long,
            join_col=col_name,
            fuse_match_type=fuse_match_type,
            join_type="11",
            **matcher_kwargs,
        )

    # 4) 统计每个原行匹配到的元素数，基于命中数计算每行的 Jaccard：
    #    J(A,B) = matched_count / (|A| + |B| - matched_count)
    matched_counts = joined_long.groupby("_row_id_left").size() if len(joined_long) else pd.Series(dtype=int)

    jaccard_scores: list[float] = []
    for idx in aligned_res_pred_df.index:
        size_a = len(res_sets.loc[idx])
        size_b = len(pred_sets.loc[idx])
        inter = int(matched_counts.get(idx, 0))
        union = size_a + size_b - inter
        if union == 0:
            score = 1.0
        else:
            score = inter / union
        jaccard_scores.append(score)

    match_mask = pd.Series([score > 0.0 for score in jaccard_scores], index=aligned_res_pred_df.index)
    matched = int(match_mask.sum())

    precision, recall, f1 = calculate_precision_recall_f1(matched, len_pred_df, len_res_df)

    set_matched_df = aligned_res_pred_df.loc[:, [
        "res_joint_keys_",
        "pred_joint_keys_",
        res_col,
        pred_col,
    ]].copy()
    set_matched_df["jaccard_score"] = jaccard_scores
    set_matched_df = set_matched_df.loc[match_mask].reset_index(drop=True)

    return precision, recall, f1, set_matched_df


