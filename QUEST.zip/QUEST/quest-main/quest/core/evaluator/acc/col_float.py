from __future__ import annotations

import pandas as pd

from ..utils.casting import to_float_like
from ..utils.metrics import calculate_precision_recall_f1


def acc_cal_col_float(
    aligned_res_pred_df: "pd.DataFrame",
    len_pred_df: int,
    len_res_df: int,
    col_name: str,
    eps: float = 1e-4,
) -> tuple[float, float, float, "pd.DataFrame"]:
    """浮点列的逐行匹配，容忍绝对误差 <= eps。

    返回 matched_df：包含 res_joint_keys_, pred_joint_keys_, res_<col>, pred_<col>
    """
    res_col = f"res_{col_name}"
    pred_col = f"pred_{col_name}"
    for c in (res_col, pred_col, "res_joint_keys_", "pred_joint_keys_"):
        if c not in aligned_res_pred_df.columns:
            raise KeyError(f"缺少列: {c}")

    res_vals = aligned_res_pred_df[res_col].map(to_float_like)
    pred_vals = aligned_res_pred_df[pred_col].map(to_float_like)

    # 匹配：双方非空且差值 <= eps
    diff = (res_vals - pred_vals).abs()
    match_mask = res_vals.notna() & pred_vals.notna() & (diff <= float(eps))
    matched = int(match_mask.sum())

    precision, recall, f1 = calculate_precision_recall_f1(matched, len_pred_df, len_res_df)

    matched_df = aligned_res_pred_df.loc[match_mask, [
        "res_joint_keys_",
        "pred_joint_keys_",
        res_col,
        pred_col,
    ]].reset_index(drop=True)

    return precision, recall, f1, matched_df


