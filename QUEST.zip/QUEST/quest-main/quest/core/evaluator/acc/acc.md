# 组件 5：准确率计算主入口（acc\_calculation）

**文件**：`acc/calc.py`

**Signature**

```python
def acc_calculation(
    aligned_res_pred_df: "pd.DataFrame",
    len_pred_df: int,
    len_res_df: int,
    col_type_dict: dict[str, ColType]
) -> dict[str, dict[str, Any]]:
    """Return {col_name: {'precision':..., 'recall':..., 'f1':..., 'matched_df': or 'set_matched_df'}}"""
```

**Inputs**

* `aligned_res_pred_df`
* `len_pred_df`, `len_res_df`
* `col_type_dict`

**Outputs**

* `col_acc_dict`：逐列的指标与匹配明细（`matched_df` 或 `set_matched_df`）

**Errors**

* 缺少 `res_<col>` 或 `pred_<col>` 时抛出 `KeyError`

**Steps**

1. 未在 `col_type_dict` 指定的列，默认类型为 `"string"`。
2. 逐列分派到子函数：

   * `acc_cal_col_int`
   * `acc_cal_col_float`
   * `acc_cal_col_string`
   * `acc_cal_col_set_string`
   * `acc_cal_col_set_int`
3. 汇总返回。

---

# 组件 6：各列类型的准确率计算

## acc/col\_int.py — `acc_cal_col_int`

**Signature**

```python
def acc_cal_col_int(
    aligned_res_pred_df: "pd.DataFrame",
    len_pred_df: int,
    len_res_df: int,
    col_name: str
) -> tuple[float,float,float,"pd.DataFrame"]:
    """Return precision, recall, f1, matched_df"""
```

**逻辑要点**

* 使用 `to_int_like` 转换后比较。
* `matched_df` 列包含：`res_joint_keys_`, `pred_joint_keys_`, `res_<col_name>`, `pred_<col_name>`。
* 精确率/召回率/F1 公式如上。

## acc/col\_float.py — `acc_cal_col_float`

**Signature**

```python
def acc_cal_col_float(
    aligned_res_pred_df: "pd.DataFrame",
    len_pred_df: int,
    len_res_df: int,
    col_name: str,
    eps: float = 1e-4
) -> tuple[float,float,float,"pd.DataFrame"]:
    ...
```

**逻辑要点**

* `to_float_like` 转换；`abs(res - pred) <= eps` 判匹配。
* 输出同上。

## acc/col\_string.py — `acc_cal_col_string`

**Signature**

```python
def acc_cal_col_string(
    aligned_res_pred_df: "pd.DataFrame",
    len_pred_df: int,
    len_res_df: int,
    col_name: str,
    fuse_match_type: FuseMatchType = "precise",
    **matcher_kwargs
) -> tuple[float,float,float,"pd.DataFrame"]:
    ...
```

**逻辑要点**

1. 先做**精确匹配**（`normalize_str` 后相等），收集命中行。
2. 对剩余行按 `fuse_match_type` 做**一对一模糊匹配**（行对行同序，见需求），匹配成功则并入命中。
3. 合并结果，计算指标并返回 `matched_df`。

> LLM/编辑距离/语义相似度调用见 `matchers/`，三者输出统一 `match_flag: list[bool]`。

## acc/col\_set\_int.py — `acc_cal_col_set_int`

**Signature**

```python
def acc_cal_col_set_int(
    aligned_res_pred_df: "pd.DataFrame",
    len_pred_df: int,
    len_res_df: int,
    col_name: str
) -> tuple[float,float,float,"pd.DataFrame"]:
    """Return precision, recall, f1, set_matched_df(with jaccard_score)"""
```

**逻辑要点**

* 解析单元格为 `set[int]`，计算逐行 $J(A,B)$。
* `jaccard_score > 0` 视为“匹配上”。
* `set_matched_df` 列：`res_joint_keys_`, `pred_joint_keys_`, `res_<col_name>`, `pred_<col_name>`, `jaccard_score`。

## acc/col\_set\_string.py — `acc_cal_col_set_string`

**Signature**

```python
def acc_cal_col_set_string(
    aligned_res_pred_df: "pd.DataFrame",
    len_pred_df: int,
    len_res_df: int,
    col_name: str,
    fuse_match_type: FuseMatchType = "precise",
    **matcher_kwargs
) -> tuple[float,float,float,"pd.DataFrame"]:
    ...
```

**逻辑要点**

1. 将每行的 `set(string)` 展开为两侧 DataFrame 的**元素级**长表，各自携带该行的 `_row_id`。
2. 对元素级长表在该列上调用 `pd_string_inner_join`（`join_type="11"`，**一对一**），fuse 采用 `fuse_match_type`。
3. 对同一原行统计匹配到的元素数，计算 $J(A,B)$。
4. `jaccard_score > 0` 的行进入 `set_matched_df`，同上列结构。
5. 由“`jaccard_score > 0` 的行数”计入 matched，再算 P/R/F1。

---

