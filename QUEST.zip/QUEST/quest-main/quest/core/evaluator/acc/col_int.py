from __future__ import annotations

from typing import Tuple

import pandas as pd

from ..utils.casting import to_int_like
from ..utils.metrics import calculate_precision_recall_f1


def acc_cal_col_int(
    aligned_res_pred_df: "pd.DataFrame",
    len_pred_df: int,
    len_res_df: int,
    col_name: str,
) -> tuple[float, float, float, "pd.DataFrame"]:
    """整数列的逐行精确匹配。

    - 将 `res_<col>` 与 `pred_<col>` 使用 `to_int_like` 转换
    - 匹配条件：两侧值均非 None 且相等
    - 返回 matched_df：包含 res_joint_keys_, pred_joint_keys_, res_<col>, pred_<col>
    """
    res_col = f"res_{col_name}"
    pred_col = f"pred_{col_name}"
    for c in (res_col, pred_col, "res_joint_keys_", "pred_joint_keys_"):
        if c not in aligned_res_pred_df.columns:
            raise KeyError(f"缺少列: {c}")

    res_vals = aligned_res_pred_df[res_col].map(to_int_like)
    pred_vals = aligned_res_pred_df[pred_col].map(to_int_like)

    match_mask = (res_vals.notna()) & (pred_vals.notna()) & (res_vals == pred_vals)
    matched = int(match_mask.sum())

    precision, recall, f1 = calculate_precision_recall_f1(matched, len_pred_df, len_res_df)

    matched_df = aligned_res_pred_df.loc[match_mask, [
        "res_joint_keys_",
        "pred_joint_keys_",
        res_col,
        pred_col,
    ]].reset_index(drop=True)

    return precision, recall, f1, matched_df


