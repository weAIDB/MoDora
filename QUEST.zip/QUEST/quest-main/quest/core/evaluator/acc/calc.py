from __future__ import annotations

from typing import Any, Dict

import pandas as pd

from ..evaluator_types import ColType, FuseMatchType
from .col_int import acc_cal_col_int
from .col_float import acc_cal_col_float
from .col_string import acc_cal_col_string
from .col_set_int import acc_cal_col_set_int
from .col_set_string import acc_cal_col_set_string


def _ensure_required_cols(aligned_res_pred_df: "pd.DataFrame", col_name: str) -> None:
    res_col = f"res_{col_name}"
    pred_col = f"pred_{col_name}"
    missing = [c for c in [res_col, pred_col] if c not in aligned_res_pred_df.columns]
    if missing:
        raise KeyError(f"缺少列: {missing}")


def acc_calculation(
    aligned_res_pred_df: "pd.DataFrame",
    len_pred_df: int,
    len_res_df: int,
    col_type_dict: dict[str, ColType],
    /,
    *,
    default_fuse_match_type: FuseMatchType = "precise",
    **matcher_kwargs: Any,
) -> dict[str, dict[str, Any]]:
    """按列类型计算精确率/召回率/F1 与匹配明细。

    返回结构：{col_name: {"precision":..., "recall":..., "f1":..., "matched_df" 或 "set_matched_df"}}
    未在 col_type_dict 指定的列默认按 "string" 类型处理。
    """
    if not isinstance(aligned_res_pred_df, pd.DataFrame):
        raise TypeError("aligned_res_pred_df 必须为 pandas.DataFrame")

    # 推断候选列名集合：从 aligned_res_pred_df 里的 res_* 与 pred_* 交集提取基础列名
    res_base = {c[len("res_"):] for c in aligned_res_pred_df.columns if c.startswith("res_")}
    pred_base = {c[len("pred_"):] for c in aligned_res_pred_df.columns if c.startswith("pred_")}
    all_cols = sorted(res_base.intersection(pred_base))

    result: Dict[str, Dict[str, Any]] = {}
    for col in all_cols:
        col_type: ColType = col_type_dict.get(col, "string")  # 默认 string
        _ensure_required_cols(aligned_res_pred_df, col)

        if col_type == "int":
            p, r, f1, matched_df = acc_cal_col_int(aligned_res_pred_df, len_pred_df, len_res_df, col)
            result[col] = {"precision": p, "recall": r, "f1": f1, "matched_df": matched_df}
        elif col_type == "float":
            p, r, f1, matched_df = acc_cal_col_float(aligned_res_pred_df, len_pred_df, len_res_df, col)
            result[col] = {"precision": p, "recall": r, "f1": f1, "matched_df": matched_df}
        elif col_type == "string":
            p, r, f1, matched_df = acc_cal_col_string(
                aligned_res_pred_df,
                len_pred_df,
                len_res_df,
                col,
                fuse_match_type=default_fuse_match_type,
                **matcher_kwargs,
            )
            result[col] = {"precision": p, "recall": r, "f1": f1, "matched_df": matched_df}
        elif col_type == "set_int":
            p, r, f1, set_matched_df = acc_cal_col_set_int(aligned_res_pred_df, len_pred_df, len_res_df, col)
            result[col] = {"precision": p, "recall": r, "f1": f1, "set_matched_df": set_matched_df}
        elif col_type == "set_string":
            p, r, f1, set_matched_df = acc_cal_col_set_string(
                aligned_res_pred_df,
                len_pred_df,
                len_res_df,
                col,
                fuse_match_type=default_fuse_match_type,
                **matcher_kwargs,
            )
            result[col] = {"precision": p, "recall": r, "f1": f1, "set_matched_df": set_matched_df}
        else:
            raise ValueError(f"未知列类型: {col_type}")

    return result


