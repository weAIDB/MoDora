import os
import sys
cur_file_path = os.path.dirname(__file__)
sys.path.append(os.path.join(cur_file_path, "../../"))


# 确保可以使用绝对包名 `evaluator` 导入
_CUR_DIR = os.path.dirname(__file__)
_PKG_PARENT = os.path.abspath(os.path.join(_CUR_DIR, os.pardir, os.pardir))
if _PKG_PARENT not in sys.path:
    sys.path.insert(0, _PKG_PARENT)

from evaluator.sql.parser import parse_sql


def test_single_table_no_groupby():
    sql = """
        SELECT name FROM Users WHERE age > 18
    """
    converted_sql, pks, has_gb = parse_sql(sql)

    assert has_gb is False
    assert pks == ["users.id"]

    low = converted_sql.lower()
    # 关键字与表列应被标准化
    assert "from users" in low
    assert "users.name" in low
    assert "users.age" in low
    # 无 group by，主键应被补到 select 列表
    assert "users.id" in low
    assert "group by" not in low

    print(converted_sql)


def test_multi_table_join_no_groupby():
    sql = """
        SELECT u.name, o.amount, o.name
        FROM Users u
        JOIN Orders o ON u.id = o.user_id
        WHERE o.amount > 0
    """
    converted_sql, pks, has_gb = parse_sql(sql)

    assert has_gb is False
    # 多表时主键按表名字典序排序（orders < users）
    assert pks == ["o.id", "u.id"]

    low = converted_sql.lower()
    assert "from users" in low
    assert "join orders" in low
    assert "u.id" in low
    assert "o.id" in low
    assert "u.name" in low
    assert "o.amount" in low

    print(converted_sql)


def test_with_group_by():
    sql = """
        SELECT u.country, COUNT(*) AS cnt
        FROM Users u
        GROUP BY u.country
    """
    converted_sql, pks, has_gb = parse_sql(sql)

    assert has_gb is True
    # 有 GROUP BY 时，主键等于分组列
    assert pks == ["u.country"]

    low = converted_sql.lower()
    assert "from users" in low
    assert "group by u.country" in low
    # 有 group by 时不应强行补 users.id
    assert ".id" not in low or "u.id" not in low


if __name__ == "__main__":
    test_single_table_no_groupby()
    test_multi_table_join_no_groupby()
    test_with_group_by()
