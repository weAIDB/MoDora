import os
import sys
cur_file_path = os.path.dirname(__file__)
sys.path.append(os.path.join(cur_file_path, "../../"))

import pandas as pd

# 确保可以使用绝对包名 `evaluator` 导入
_CUR_DIR = os.path.dirname(__file__)
_PKG_PARENT = os.path.abspath(os.path.join(_CUR_DIR, os.pardir, os.pardir))
if _PKG_PARENT not in sys.path:
    sys.path.insert(0, _PKG_PARENT)

from evaluator.sql.parser import parse_sql
from evaluator.sql.executor import execute_sql_on_gt


def _sample_tables():
    users = pd.DataFrame(
        {
            "id": [1, 2, 3, 4],
            "name": ["alice", "bob", "cindy", "dave"],
            "age": [20, 17, 35, 28],
            "country": ["US", "US", "UK", "CN"],
        }
    )
    orders = pd.DataFrame(
        {
            "id": [10, 11, 12, 13],
            "user_id": [1, 1, 2, 4],
            "amount": [100.0, 50.0, 0.0, 200.0],
        }
    )
    return {"users": users, "orders": orders}


def test_execute_single_table_where():
    tables = _sample_tables()
    sql = "SELECT name, age FROM users WHERE age > 18"
    converted_sql, _, _ = parse_sql(sql)
    df = execute_sql_on_gt(converted_sql, tables)

    # 期望包含补充的主键列 users.id
    # assert set(df.columns) >= {"users.name", "users.age", "users.id"}
    # 过滤结果应只有 age > 18 的行（id: 1,3,4）
    assert set(df["id"].tolist()) == {1, 3, 4}


def test_execute_join_and_filter():
    tables = _sample_tables()
    sql = """
        SELECT u.name , o.amount
        FROM users u
        JOIN orders o ON u.id = o.user_id
        WHERE o.amount > 0
    """
    converted_sql, _, _ = parse_sql(sql)
    df = execute_sql_on_gt(converted_sql, tables)

    # 列应包含 select 列与补充的两个主键列
    expect_cols = {"name", "amount", "orders_id", "users_id"}
    # print("结果包含的列名：  ", df.columns)
    assert expect_cols.issubset(set(df.columns))

    # 根据样例数据，amount > 0 的 join 结果 (orders_id:10,11,13)
    assert set(df["orders_id"].tolist()) == {10, 11, 13}


def test_execute_group_by():
    tables = _sample_tables()
    sql = """
        SELECT u.country, COUNT(*) AS cnt
        FROM users u
        GROUP BY u.country
    """
    converted_sql, pks, has_gb = parse_sql(sql)
    assert has_gb is True
    print("主键列是：  ", pks)
    assert pks == ["country"]

    df = execute_sql_on_gt(converted_sql, tables)
    # group by 时不应补 users.id；列名应小写且带表前缀（count(*) 的别名由 duckdb 生成）
    assert "id" not in df.columns
    assert "country" in df.columns
    # 国家分布（基于样例）：US x2, UK x1, CN x1
    res = dict(zip(df["country"].tolist(), df.iloc[:, 1].tolist()))
    assert res.get("US", 0) == 2
    assert res.get("UK", 0) == 1
    assert res.get("CN", 0) == 1


if __name__ == "__main__":
    test_execute_single_table_where()
    test_execute_join_and_filter()
    test_execute_group_by()