"""
Pred2GroundTruthEvaluator - 预测结果与真实结果对比评估器

提供完整的SQL执行结果评估流程，包括SQL解析、执行、结果对齐和准确率计算。
"""

from typing import Any, Dict

from .evaluator_types import ColType
from .sql.parser import parse_sql
from .sql.executor import execute_sql_on_gt
from .align.aligner import align_pred_res
from .acc.calc import acc_calculation


def evaluate_pipeline(
    sql: str, 
    gt_table_dict: dict[str, "pd.DataFrame"],
    pred_df: "pd.DataFrame",
    col_type_dict: dict[str, ColType],
    **kwargs
) -> dict[str, dict[str, Any]]:
    """
    端到端评估流程
    
    Args:
        sql: 原始SQL语句
        gt_table_dict: 真实数据表字典 {table_name: DataFrame}
        pred_df: 预测结果DataFrame
        col_type_dict: 列类型字典 {col_name: ColType}
        **kwargs: 其他参数
        
    Returns:
        评估结果字典 {col_name: {'precision':..., 'recall':..., 'f1':..., 'matched_df': ...}}
    """
    # 1. SQL解析
    converted_sql, pks, has_gb = parse_sql(sql)
    
    # 2. 在真实数据上执行SQL
    res_df = execute_sql_on_gt(converted_sql, gt_table_dict)
    
    # 3. 结果对齐
    aligned = align_pred_res(pks, pred_df, res_df, has_gb)
    
    # 4. 准确率计算
    return acc_calculation(aligned, len(pred_df), len(res_df), col_type_dict)


__all__ = [
    'evaluate_pipeline',
    'parse_sql',
    'execute_sql_on_gt', 
    'align_pred_res',
    'acc_calculation'
]
