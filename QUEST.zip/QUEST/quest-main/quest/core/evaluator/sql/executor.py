"""
在 GT 上执行 SQL。

按照规范：
1) 在内存中创建 DuckDB 连接；
2) 将传入的 DataFrame 字典按表名注册；
3) 执行传入的 converted_sql 并返回 pandas.DataFrame；
4) 对异常进行封装，包含 SQL 片段与 DuckDB 错误信息。
"""

from typing import Dict

import pandas as pd


def execute_sql_on_gt(converted_sql: str, gt_table_dict: Dict[str, "pd.DataFrame"]) -> "pd.DataFrame":
    """Register dfs in duckdb, execute SQL, return result df.

    Parameters
    ----------
    converted_sql : str
        经过方言统一后的 SQL（DuckDB 方言）。
    gt_table_dict : Dict[str, pd.DataFrame]
        表名到 DataFrame 的映射。

    Returns
    -------
    pd.DataFrame
        查询结果。

    Raises
    ------
    RuntimeError
        包装 DuckDB 的执行错误，带上 SQL 片段和原始错误信息。
    """
    if not isinstance(converted_sql, str) or not converted_sql.strip():
        raise ValueError("Empty SQL input")

    # 惰性导入 duckdb，避免在未使用时成为硬依赖
    try:
        import duckdb  # type: ignore
    except Exception as e:
        raise RuntimeError(f"Failed to import duckdb: {e}")

    try:
        con = duckdb.connect(":memory:")
        try:
            # 将所有表注册到会话中
            for table_name, df in gt_table_dict.items():
                # 列名统一为小写副本，以便与解析阶段的小写列名对齐
                if isinstance(df, pd.DataFrame):
                    df_to_register = df.copy()
                    df_to_register.columns = [str(c).lower() for c in df_to_register.columns]
                else:
                    raise ValueError(f"Table '{table_name}' is not a pandas.DataFrame")
                con.register(table_name.lower(), df_to_register)

            result_df: pd.DataFrame = con.execute(converted_sql).df()
            # 结果列名也统一为小写，保持管道内一致
            result_df.columns = [str(c).lower() for c in result_df.columns]
            return result_df
        finally:
            con.close()
    except Exception as e:
        sql_snippet = converted_sql
        if len(sql_snippet) > 400:
            sql_snippet = sql_snippet[:200] + " ... " + sql_snippet[-200:]
        raise RuntimeError(f"DuckDB execution failed. SQL: {sql_snippet}. Error: {e}")


