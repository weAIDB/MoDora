# 组件 1：SQL 解析（parse\_sql）

**文件**：`sql/parser.py`

**Signature**

```python
def parse_sql(sql: str) -> tuple[str, list[str], bool]:
    """return converted_sql, primary_keys_list, group_by_flag"""
```

**Inputs**

* `sql: str`

**Outputs**

* `converted_sql: str`（多表时检查列名是否带有表前缀；必要时补 SELECT 主键列；DuckDB 方言）
* `primary_keys_list: list[str]`（按规范：无 GROUP BY → `id`(单表时) `table1.id, table2.id`(多表时) ；有 GROUP BY → 所有 group by 列名）
* `group_by_flag: bool`

**Errors**

* SQL 语法错误或 AST 不完整 → `ValueError` 携带原始 SQL 片段与解析阶段信息
* 表/列解析后无法定位主键列 → `RuntimeError`

**Steps**

1. **AST 构建**：用 `sqlglot.parse_one(sql)` 获取 AST，记录所有表、列与别名。
2. **主键列确定**

   * 有 `GROUP BY`：`primary_keys_list` 即 `GROUP BY` 中所有规范化列（顺序按 AST 出现顺序）。
   * 无 `GROUP BY`：
     * 无 JOIN：主键列为 `id`（单表）。
     * 有 JOIN：主键列为所有参与表的 `table.id` (多表)（去重后按表名字典序）。
    注意：不要动别名。
3. **补 SELECT 主键列**（仅当无 `GROUP BY`）：如 SELECT 列未包含所有主键列，则将其追加到 SELECT 列表（保持稳定顺序）。
4. **转 DuckDB 方言**： 得到 `converted_sql`。
5. **返回**：`converted_sql, primary_keys_list, group_by_flag`

**Notes**

* 要想在执行结果中得到table_col的形式(一般是列名冲突的列要这样处理)，需要使用sql的AS语法
* 对大小写统一为小写以便列对齐；保留字符串字面量原样。

        SELECT u.name AS users_name, o.amount AS orders_amount
        FROM users u
        JOIN orders o ON u.id = o.user_id
        WHERE o.amount > 0
---

# 组件 2：在 GT 上执行 SQL（execute\_sql\_on\_gt）

**文件**：`sql/executor.py`

**Signature**

```python
def execute_sql_on_gt(converted_sql: str, gt_table_dict: dict[str, "pd.DataFrame"]) -> "pd.DataFrame":
    """Register dfs in duckdb, execute SQL, return result df"""
```

**Inputs**

* `converted_sql: str`
* `gt_table_dict: map(table_name -> pandas.DataFrame)`

**Outputs**

* `res_df: pandas.DataFrame`

**Errors**

* DuckDB 执行错误（封装并抛出），包含片段 SQL、首尾 200 字符窗口与 DuckDB 错误信息。

**Steps**

1. `duckdb.connect(":memory:")`，逐表 `con.register(table_name, df)`。
2. 执行 `converted_sql`，`con.execute(...).df()`。
3. 返回 `res_df`。

**Notes**

* 不在函数内修改 `gt_table_dict`；必要时复制列名为小写。

---
