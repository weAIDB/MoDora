"""
SQL处理模块

提供SQL解析和执行功能。
"""

from .parser import parse_sql
from .executor import execute_sql_on_gt

__all__ = [
    'parse_sql',
    'execute_sql_on_gt'
]
