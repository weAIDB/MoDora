"""
SQL解析器

按照规范：
1) 使用 sqlglot 构建 AST；
2) 将所有列统一到小写的 "table.col" 形式，其中 table 为原始别名（如存在）否则为真实表名（均小写）；
   注意：不再将别名替换为真实表名，以便在后续精度评估中与预测列对齐。
3) 推断主键列：有 GROUP BY → 使用分组列（保留其别名前缀）；
   无 GROUP BY → 使用所有参与“实体”（有别名用别名、无别名用表名）的 entity.id（单表/多表 JOIN/自连接）；
4) 当无 GROUP BY 时，如 SELECT 不包含所有主键列，则将其追加；
5) 输出 DuckDB 方言 SQL、主键列表与 group_by 标志。
"""

from typing import List, Tuple

import sqlglot
from sqlglot import exp


def _identifier_name(identifier: exp.Expression) -> str:
    """获取 Identifier/Column/Table 的名称（小写）。"""
    if identifier is None:
        return ""
    # sqlglot 的 Identifier/Column/Table 通常都有 .name 或 .this，可统一转字符串后降为小写
    try:
        name = identifier.name  # type: ignore[attr-defined]
    except Exception:
        name = str(identifier)
    return (name or "").strip("`\"").lower()


def _table_real_and_alias(table_expr: exp.Table) -> Tuple[str, str]:
    """返回 (real_table, alias) 均为小写；无别名时 alias==real_table。"""
    real_table = _identifier_name(table_expr)
    alias_expr = table_expr.args.get("alias")
    alias_name = _identifier_name(alias_expr) if alias_expr is not None else ""
    if not alias_name:
        alias_name = real_table
    return real_table, alias_name


def _collect_tables_and_aliases(root: exp.Expression) -> Tuple[List[str], dict]:
    """
    收集参与的“实体”名称与别名映射：
    - 实体名称列表 entities：对每个 FROM/JOIN 表，若存在别名则取别名，否则取真实表名；均为小写，按出现顺序。
    - alias_to_real：将每个实体名（别名或真实表名）映射到其真实表名；均为小写。
    """
    alias_to_real: dict[str, str] = {}
    entities: List[str] = []
    for t in root.find_all(exp.Table):
        real, alias = _table_real_and_alias(t)
        entity_name = alias if alias else real
        if entity_name:
            entities.append(entity_name)
        # 映射：实体名 -> 真实表名
        alias_to_real[entity_name] = real
        # 同时保留真实表名自身映射，便于识别显式使用真实表名限定的列
        alias_to_real[real] = real
    return entities, alias_to_real


def _normalize_table_names(root: exp.Expression, alias_to_real: dict[str, str]) -> None:
    """
    将所有 Table 节点的真实表名与别名统一为小写：
    - 表名使用真实表名的小写形式；
    - 若存在别名，保留别名并降为小写（不替换为真实表名）。
    """
    for t in root.find_all(exp.Table):
        real, _ = _table_real_and_alias(t)
        # 统一表名为小写真实表（FROM 子句中注册使用真实表名）
        t.set("this", exp.to_identifier(real))
        # 若存在别名，保持别名（降为小写）
        alias_expr = t.args.get("alias")
        if alias_expr is not None:
            alias_name = _identifier_name(alias_expr)
            if alias_name:
                alias_expr.set("this", exp.to_identifier(alias_name))


def _resolve_column_table(
    col: exp.Column, participating_entities: List[str], alias_to_real: dict[str, str]
) -> Tuple[str, str]:
    """
    解析列所属的实体名与列名，均为小写；
    - 实体名优先保留原始别名；
    - 若列未限定且存在多个实体，则报歧义错误；
    - 若列未限定且仅单一实体，则使用该实体名（可能为别名）。
    """
    col_name = _identifier_name(col.args.get("this"))
    tbl_identifier = col.args.get("table")
    if tbl_identifier is None or str(tbl_identifier) == "":
        if len(participating_entities) == 1:
            table_name = participating_entities[0]
        else:
            raise ValueError(
                f"Ambiguous unqualified column '{col_name}' in multi-table query"
            )
    else:
        # 使用用户提供的限定名（别名或真实表名），不再映射为真实表名
        qualifier = _identifier_name(tbl_identifier)
        table_name = qualifier
    return table_name, col_name


def _normalize_all_columns(root: exp.Expression, participating_entities: List[str], alias_to_real: dict[str, str]) -> None:
    """将所有 Column 统一为小写的 entity.col（entity 为别名或真实表名）。"""
    for col in root.find_all(exp.Column):
        table_name, col_name = _resolve_column_table(col, participating_entities, alias_to_real)
        col.set("this", exp.to_identifier(col_name))
        col.set("table", exp.to_identifier(table_name))


def _collect_group_by_columns(select: exp.Select, participating_entities: List[str], alias_to_real: dict[str, str]) -> List[str]:
    group = select.args.get("group")
    if not isinstance(group, exp.Group):
        return []
    group_cols: List[str] = []
    # group.expressions 是分组项列表，逐项找其中的 Column
    for expr_item in group.expressions:
        # 支持 group by table.col 或仅列名（会在归一化列阶段被统一）
        if isinstance(expr_item, exp.Column):
            t, c = _resolve_column_table(expr_item, participating_entities, alias_to_real)
            group_cols.append(f"{t}.{c}")
        else:
            # 若 group by 表达式中含表达式（如函数），尝试在其内部寻找 Column
            for col in expr_item.find_all(exp.Column):
                t, c = _resolve_column_table(col, participating_entities, alias_to_real)
                col.set("this", exp.to_identifier(c))
                col.set("table", exp.to_identifier(t))
                group_cols.append(f"{t}.{c}")
    return group_cols


def _select_existing_columns(select: exp.Select) -> List[str]:
    """抽取 SELECT 投影中出现的列（规范化后）。不展开星号。"""
    cols: List[str] = []
    for e in select.expressions:
        for c in e.find_all(exp.Column):
            t = _identifier_name(c.args.get("table"))
            n = _identifier_name(c.args.get("this"))
            if t and n:
                cols.append(f"{t}.{n}")
    return list(dict.fromkeys(cols))


def _append_missing_pk_to_select(select: exp.Select, pks: List[str]) -> None:
    existing = set(_select_existing_columns(select))
    for pk in pks:
        if pk not in existing:
            table_name, col_name = pk.split(".", 1)
            # 使用 exp.Column 构造函数而不是 exp.column 函数
            # 这样可以避免多余的引号
            select.append("expressions", exp.Column(
                this=exp.to_identifier(col_name),
                table=exp.to_identifier(table_name)
            ))


def _apply_disambiguating_aliases(select: exp.Select, alias_to_real: dict[str, str]) -> None:
    """
    为 SELECT 投影中的简单列添加去重别名，防止 JOIN 后输出列名冲突：
    - 仅处理简单列（exp.Column）且未显式起别名的情形；
    - 对于同名的未命名列（如 u.name 与 o.name 都会默认输出为 name），
      为其添加别名为 "<real_table>_<column>"（如 users_name、orders_name）；
    - 主键列在多表情况下通常也会重复为 id，也会因此被别名为 users_id 等；
    - 已显式起别名或为复杂表达式/星号的投影项不改动。
    """
    # 收集所有未显式别名的简单列的“默认输出名”（即列名本身）计数
    items: list[tuple[int, exp.Expression, exp.Column, str, str, str]] = []
    # (idx, original_expr, column_expr, table_entity, real_table, col_name)
    name_counts: dict[str, int] = {}

    for idx, expr_item in enumerate(list(select.expressions)):
        # 已有别名的表达式
        if isinstance(expr_item, exp.Alias):
            continue
        # 仅处理简单列
        if isinstance(expr_item, exp.Column):
            table_name = _identifier_name(expr_item.args.get("table"))
            col_name = _identifier_name(expr_item.args.get("this"))
            if not col_name:
                continue
            real_table = alias_to_real.get(table_name or "", table_name or "")
            items.append((idx, expr_item, expr_item, table_name, real_table, col_name))
            name_counts[col_name] = name_counts.get(col_name, 0) + 1
        else:
            # 复杂表达式或星号跳过
            continue

    # 为重复名称的简单列添加别名：<real_table>_<column>
    for idx, original_expr, col_expr, table_entity, real_table, col_name in items:
        if name_counts.get(col_name, 0) > 1:
            alias_name = f"{real_table}_{col_name}" if real_table else col_name
            # 用带别名的新表达式替换对应位置
            aliased = exp.alias_(col_expr.copy(), alias_name)
            select.expressions[idx] = aliased


def _build_select_projection_output_name_map(select: exp.Select) -> dict[str, str]:
    """
    构建 SELECT 投影中“输入列 → 输出列名”的映射，仅处理简单列：
    - Key 为标准化的 "table.col"（table 为别名或真实表名，均小写）；
    - Value 为该列在结果集中的输出名称：若显式 AS 别名则取别名，否则为列名本身（不含表前缀）。
    """
    mapping: dict[str, str] = {}
    for expr_item in select.expressions:
        # 形如: <column> AS alias
        if isinstance(expr_item, exp.Alias):
            underlying = expr_item.this
            if isinstance(underlying, exp.Column):
                t = _identifier_name(underlying.args.get("table"))
                c = _identifier_name(underlying.args.get("this"))
                if t and c:
                    alias_name = _identifier_name(expr_item.args.get("alias"))
                    if alias_name:
                        mapping[f"{t}.{c}"] = alias_name
        # 简单列，无别名
        elif isinstance(expr_item, exp.Column):
            t = _identifier_name(expr_item.args.get("table"))
            c = _identifier_name(expr_item.args.get("this"))
            if t and c and f"{t}.{c}" not in mapping:
                mapping[f"{t}.{c}"] = c
        # 复杂表达式与星号忽略
    return mapping

def parse_sql(sql: str) -> Tuple[str, List[str], bool]:
    """
    解析SQL语句，返回转换后的SQL、主键列表和GROUP BY标志。

    Returns:
        converted_sql, primary_keys_list, group_by_flag

    Raises:
        ValueError: SQL语法错误或AST不完整/不支持的结构
        RuntimeError: 无法定位主键列
    """
    if not isinstance(sql, str) or not sql.strip():
        raise ValueError("Empty SQL input")

    try:
        root = sqlglot.parse_one(sql, read="duckdb")
    except Exception as e:
        raise ValueError(f"Failed to parse SQL: {e}")

    # 仅支持单一 SELECT 查询（不处理 CTE/UNION 等复杂语法的多段返回场景）
    select = root if isinstance(root, exp.Select) else root.find(exp.Select)
    if not isinstance(select, exp.Select):
        raise ValueError("Only SELECT queries are supported for now")

    # 收集参与实体（别名优先）与映射
    participating_entities, alias_to_real = _collect_tables_and_aliases(root)
    if not participating_entities:
        raise ValueError("No table found in SQL")

    # 统一表名/别名为小写
    _normalize_table_names(root, alias_to_real)

    # 列名统一为小写且全部带上 table 前缀（多表时未限定列报错）
    _normalize_all_columns(root, participating_entities, alias_to_real)

    # 判断是否存在 GROUP BY，并收集分组列
    group_by_cols = _collect_group_by_columns(select, participating_entities, alias_to_real)
    group_by_flag = len(group_by_cols) > 0

    if group_by_flag:
        # 对 SELECT 投影应用防重复列名的别名策略（基于真实表名），
        # 以便主键列名称与最终输出列名一致（若发生重复将被自动加别名）。
        _apply_disambiguating_aliases(select, alias_to_real)

        # 构建投影映射，优先取显式/自动 AS 别名，否则取列名本身（不含表前缀）
        proj_map = _build_select_projection_output_name_map(select)

        # 将 group by 的标准化列转换为输出列名；若不在投影中，则回退为列名本身
        primary_keys_list = []
        for qualified in group_by_cols:
            out_name = proj_map.get(qualified)
            if out_name is None:
                out_name = qualified.split(".", 1)[1]
            primary_keys_list.append(out_name)
    else:
        # 无 GROUP BY，则主键取所有参与实体的 entity.id；多实体时按实体名字典序
        pk_candidates = [f"{ent}.id" for ent in participating_entities]
        # 去重（保持顺序），并在多实体时按实体名排序
        pk_candidates = list(dict.fromkeys(pk_candidates))
        if len(participating_entities) > 1:
            pk_candidates = sorted(pk_candidates, key=lambda x: x.split(".")[0])

        # 将缺失的主键列补充到 SELECT
        _append_missing_pk_to_select(select, pk_candidates)

        # 应用去重别名（如 users.id / orders.id → users_id / orders_id）
        _apply_disambiguating_aliases(select, alias_to_real)

        # 依据投影映射，得到主键在最终输出中的列名：
        # 若存在显式/自动 AS，则取别名；否则取列名本身
        proj_map = _build_select_projection_output_name_map(select)
        primary_keys_list = []
        for qualified in pk_candidates:
            out_name = proj_map.get(qualified)
            if out_name is None:
                out_name = qualified.split(".", 1)[1]
            primary_keys_list.append(out_name)

    if not primary_keys_list:
        raise RuntimeError("Failed to determine primary key columns")

    # 转为 DuckDB 方言输出
    converted_sql = root.sql(dialect="duckdb")

    return converted_sql, primary_keys_list, group_by_flag
