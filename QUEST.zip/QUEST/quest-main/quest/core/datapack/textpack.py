from .pack import Pack

class BaseTextPack(Pack):
    """
    Base class for text packs.
    """
    def __init__(self, pack_type = 'BaseTextPack'):
        super().__init__(pack_type)
        
    def parse(self):
        """
        Get main data
        """
        pass

class TextPack(BaseTextPack):
    """
    textpack includes: doc_id, text, column
    """
    def __init__(self, doc_id, text, column):
        super().__init__('Text')
        self.doc_id = doc_id
        self.column = column
        self.text = text
        
    def parse(self):
        """
        Get main data
        """
        return self.text

class TextListPack(BaseTextPack):
    """
    textpack includes: doc_id, textList, column
    """
    def __init__(self, doc_id, textList, column):
        super().__init__('TextList')
        self.doc_id = doc_id
        self.column = column
        self.textList = textList
        
    def parse(self):
        """
        Get main data
        """
        return self.textList
    
class TextDictPack(BaseTextPack):
    """
    textpack includes: doc_id, textDict: {column1 : [text1, text2, ..]}
    """
    def __init__(self, doc_id, textDict):
        super().__init__('TextDict')
        self.doc_id = doc_id
        self.textDict = textDict
        
    def parse(self):
        """
        Get main data
        """
        return self.textDict
