from docx import Document
from io import BytesIO
from PIL import Image
import base64
import pandas as pd

def image_to_base64(image_data):
    # input bytes，outpput base64
    image = Image.open(BytesIO(image_data))
    buffer = BytesIO()
    image.save(buffer, format="JPEG")
    base64_str = base64.b64encode(buffer.getvalue()).decode('utf-8')
    return base64_str

def base64_to_image(base64_str):
    # imput base64, output PIL format photo
    byte_data = base64.b64decode(base64_str) # base64 to binary
    image = Image.open(BytesIO(byte_data)) # binary to PIL
    return image

def extract_text(wordfile):
    paragraphs = wordfile.paragraphs 

    res = ""
    for para in paragraphs:
        print(para.text)
        res += para.text
    
    return res

def extract_image(wordfile):
    image_list = []
    for rel in wordfile.part.rels.values():  
        # is photo
        if "image" in rel.reltype:  
            # get image
            img_data = rel.target_part.blob
            extension = rel.target_ref.split('.')[-1]
            image_list.append(img_data)
            print(image_to_base64(img_data))
    return image_list
            
def extract_tables(wordfile):
    tables = wordfile.tables
    table_list = []

    for table in tables:
        headers = [cell.text.strip() for cell in table.rows[0].cells]
        data = []
        for row in table.rows[1:]:
            row_data = [cell.text.strip() for cell in row.cells]
            data.append(row_data)
        df = pd.DataFrame(data, columns=headers)
        table_list.append(df)
        print(df)
    
    return table


def parse_wordfile(wordpath):
    wordfile = Document(wordpath)
    text = extract_text(wordfile)
    df_list = extract_tables(wordfile)
    image_list = extract_image(wordfile)

    res = {}
    res.setdefault('text', text)
    res.setdefault('table', df_list)
    res.setdefault('image', image_list)
    
    return res

