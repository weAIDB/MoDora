
# 核心需求:
- parse_sql:   解析sql，做好别名替换，获取主键名(表.id或者group by的属性列)
- execute_sql_on_gt:  在gt_df_dict上执行sql，得到gt_res_df
- align_pred_res:  根据主键对齐pred_df和gt_res_df
- acc_calculation:  根据列类型逐列比较pred_df和gt_res_df，获得准确率信息


# 扩展需求

- 实现简单的自定义sql语法解析，比如多值属性的list_contains和list_intersect语法转译
- 实现pandas表格列类型的自动推断。
- 根据attr_type， 对gt_table和pred_table进行清洗
- 准确率计算：实现STRING类型的模糊匹配(使用litellm批量对比两列值)
- 准确率计算：实现多值LIST[STRING]属性的模糊匹配(1对1模糊join)
- 准确率计算：实现多值LIST[INT]属性的精确匹配(Jaccard相似度作为单组值的匹配率值。)


# 需要用到STRING模糊匹配的接口

