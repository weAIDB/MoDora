class DeprecatedFuncExtractionEvaluator:
    def execute_sql_on_gt(self, sql,  gt_table) -> pd.DataFrame:
        # 在内存中注册gt_table为duckdb的表
        con = duckdb.connect(database=':memory:')
        con.register('wikiart', gt_table)
        # 执行SQL
        result_df = con.execute(sql).fetchdf()
        con.close()
        return result_df
    

    def gen_primary_keys_and_drop_dups(self, pred_df, gt_res_df, primary_keys):
        # 先把primary_keys列-联合主键，加一列，然后pred_df和gt_res_df分别对主键列去重(如果有重复的需要给出Warning并且输出重复行的内容到stderr)
        # 先生成联合主键列名(即便是单主键，也采用这个主键名：__joint_key__)
        key_col = '__joint_key__'
        # 生成联合主键列
        pred_df[key_col] = pred_df[primary_keys].astype(str).agg('||'.join, axis=1)
        gt_res_df[key_col] = gt_res_df[primary_keys].astype(str).agg('||'.join, axis=1)

        # 检查并输出重复主键
        pred_dups = pred_df[pred_df.duplicated(key_col, keep=False)]
        gt_dups = gt_res_df[gt_res_df.duplicated(key_col, keep=False)]

        if not pred_dups.empty:
            print(f"[Warning] pred_df 存在重复主键行：", file=sys.stderr)
            print(pred_dups, file=sys.stderr)
        if not gt_dups.empty:
            print(f"[Warning] gt_df 存在重复主键行：", file=sys.stderr)
            print(gt_dups, file=sys.stderr)

        # 去重
        pred_df = pred_df.drop_duplicates(key_col, keep='first')
        gt_res_df = gt_res_df.drop_duplicates(key_col, keep='first')

        return pred_df, gt_res_df


    def align_pred_gt_by_fixed_primary_keys(self, pred_df, gt_res_df):
        
        key_col = '__joint_key__'

        # 求交集 
        joint_keys_intersection = set(pred_df[key_col]) & set(gt_res_df[key_col])
        pred_df = pred_df[pred_df[key_col].isin(joint_keys_intersection)]
        gt_res_df = gt_res_df[gt_res_df[key_col].isin(joint_keys_intersection)]

        # 按主键排序
        aligned_pred_df = pred_df.sort_values(by=key_col).reset_index(drop=True)
        aligned_gt_df = gt_res_df.sort_values(by=key_col).reset_index(drop=True)

        return aligned_pred_df, aligned_gt_df # 在debug状态下，这2个表要存下来，由于按主键排序，方便逐行对照查错。


    def cal_acc_fixed(self, aligned_pred_df, aligned_gt_df, primary_keys, len_pred_table, len_gt_table):
        """
        计算aligned_pred_df和aligned_gt_df逐列的准确率precision, recall, f1
        aligned_pred_df, aligned_gt_df: pd.DataFrame，已经按primary_keys对齐并且取交集后的pred_df和gt_res_df
        primary_keys: list[str]，primary_keys的列名
        fixed使用精确匹配的方式，即2个值必须完全相同才算相等。
        返回：嵌套字典，metrics[col]中包括precision, recall, f1这3个值。
        不需要计算primary keys列的准确率-否则可能拉高平均准确率。
        """
        metrics = {}
        sum_precision = 0.0
        sum_recall = 0.0
        sum_f1 = 0.0
        num_cols = 0
        # 遍历除primary_keys以外的所有列
        for col in aligned_gt_df.columns:
            if col in primary_keys or col == '__joint_key__':
                continue

            num_cols += 1

            y_true = aligned_gt_df[col]
            y_pred = aligned_pred_df[col]

            # 精确匹配
            correct = (y_true == y_pred)
            tp = correct.sum()  # 真正例

            if len_pred_table == 0 and len_gt_table == 0: 
                precision = 1.0
                recall = 1.0
                f1 = 1.0
            else:
                precision = tp / len_pred_table if len_pred_table > 0 else 0.0
                recall = tp / len_gt_table if len_gt_table > 0 else 0.0
                f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) > 0 else 0.0

            sum_precision += precision
            sum_recall += recall
            sum_f1 += f1
            metrics[col] = {
                'precision': precision,
                'recall': recall,
                'f1': f1
            }
        # 补充上平均准确率:
        avg_precision = sum_precision / num_cols if num_cols > 0 else 0.0
        avg_recall = sum_recall / num_cols if num_cols > 0 else 0.0
        avg_f1 = sum_f1 / num_cols if num_cols > 0 else 0.0
        metrics['__avg__'] = {
            'precision': avg_precision,
            'recall': avg_recall,
            'f1': avg_f1
        }

        return metrics


    def parse_and_convert_sql(self, sql: str):
        """
        尝试将sql转换为适用于duckdb的sql，用sqlglot
        并从中提取出group by的属性列名(之后join pred_table和gt_table时将被用作join列/主键列)
        并将表名、属性名、别名全部转换为小写
        并将所有表别名和列别名都替换成原始的表名和列名
        返回: (duckdb_sql: str, candidate_primary_keys: list[str])
        """
        sql_clean = ' '.join(sql.strip().split())

        try:
            parsed = sqlglot.parse_one(sql_clean)
        except Exception as e:
            raise ValueError(f"SQL 解析失败: {e}")

        # 替换表别名和列别名为原始表名和列名
        def remove_aliases(node):
            # 替换表别名为原始表名
            if node.__class__.__name__ == "TableAlias":
                return node.this  # 返回原始表节点
            # 替换列别名为原始表达式
            if node.__class__.__name__ == "Alias":
                return node.this  # 返回原始表达式
            return node

        # 将别名替换为原始表名
        parsed = parsed.transform(remove_aliases)

        # 转小写
        for node in parsed.walk():
            # 列名
            if node.__class__.__name__ == "Column":
                if node.args.get("this"):
                    node.set("this", node.args["this"].copy().transform(lambda n: n.lower() if isinstance(n, str) else n))
                if node.args.get("table"):
                    node.set("table", node.args["table"].copy().transform(lambda n: n.lower() if isinstance(n, str) else n))
            # 表名
            if node.__class__.__name__ == "Table":
                if node.args.get("this"):
                    node.set("this", node.args["this"].copy().transform(lambda n: n.lower() if isinstance(n, str) else n))
            # 别名
            if node.args.get("alias"):
                alias = node.args["alias"]
                if hasattr(alias, "set"):
                    if alias.args.get("this"):
                        alias.set("this", alias.args["this"].copy().transform(lambda n: n.lower() if isinstance(n, str) else n))

        duckdb_sql = parsed.to_sql(dialect="duckdb")

# ...existing code...
        candidate_primary_keys = [] # group by 的列名
        group = parsed.args.get("group")

        if group:
            for g in group.expressions:
                # 处理带表名前缀的列
                if hasattr(g, "args"):
                    table = None
                    col = None
                    # 兼容 Column 节点
                    if "table" in g.args and g.args["table"]:
                        table = str(g.args["table"]).lower()
                    if "this" in g.args and hasattr(g.args["this"], "name"):
                        col = g.args["this"].name.lower()
                    elif hasattr(g, "name"):
                        col = g.name.lower()
                    if table and col:
                        candidate_primary_keys.append(f"{table}.{col}")
                    elif col:
                        candidate_primary_keys.append(col)
                    else:
                        candidate_primary_keys.append(str(g).lower())
                else:
                    candidate_primary_keys.append(str(g).lower())

        else:
            # 已知一般情况下，primary keys名称是f"{table_name}.id"
            # Sql中没有group by-aggregation操作，直接根据出现的所有表名来推断primary keys的列表
            table_names = []
            for node in parsed.walk():
                if node.__class__.__name__ == "Table":
                    if node.args.get("this"):
                        table_name = str(node.args["this"]).lower()
                        table_names.append(table_name)
            # 去重
            table_names = list(set(table_names))
            # 构造主键名
            for table_name in table_names:
                candidate_primary_keys.append(f"{table_name}.id")
        # 为了后续与pred_table做准确率比较，必须要在SELCT FROM中包含candidate_primary_keys的那些列。
        # 保证duckdb_sql的SELECT中包含所有candidate_primary_keys
        # 如果缺失，则补到select前面
        # 利用AST再次检查
        select_cols = []
        select_node = parsed.args.get('expressions')
        if select_node:
            # select_node 是list
            for sel in select_node:
                if hasattr(sel, 'args') and 'this' in sel.args:
                    if sel.args.get('this'):
                        # 兼容col、函数等
                        if hasattr(sel.args['this'], 'name'):
                            select_cols.append(sel.args['this'].name.lower())
                        elif isinstance(sel.args['this'], str):
                            select_cols.append(sel.args['this'].lower())
                        else:
                            select_cols.append(str(sel.args['this']).lower())
                elif hasattr(sel, 'name'):
                    select_cols.append(sel.name.lower())
                else:
                    select_cols.append(str(sel).lower())
        else:
            # 无select？跳过
            select_cols = []

        # 检查primary key列是否都在select中，否则补上
        missing_pks = [pk for pk in candidate_primary_keys if pk not in select_cols]
        if missing_pks:
            # 补到select头部，重新构造select
            select_text = ', '.join(missing_pks + [expr.sql(dialect='duckdb') for expr in parsed.args['expressions']])
            # 替换掉原来的select部分
            # 重建SQL字符串
            from_idx = duckdb_sql.lower().find('from')
            if from_idx != -1:
                duckdb_sql = f"SELECT {select_text} {duckdb_sql[from_idx:]}"
            else:
                # 理论上不会走到这里
                raise Exception("补充primary key到select from失败，无法找到from子句")

        return duckdb_sql, candidate_primary_keys



    def clean_table(self, df: pd.DataFrame, primary_keys: list[str] = []) -> pd.DataFrame:
        # 执行默认的清洗流程
        # 对于字符串类型的值，trim首尾空格，相邻token间的连续空白符统一转换成1个空格
        # 对于primary key, 统一按照字符串类型处理，如果是int，则需要转化成字符串。
        # 对于多值字符串属性，我们不需要知道它是不是多值属性，我们只需要在处理字符串时先按照分隔符'||' split，然后对split出来的每个组分别做清洗，最后再用||拼接各个组即可。如果本来是单值属性，就不会拼接上||，所以逻辑也是对的。        
        
        def clean_str(val):
            
            if pd.isnull(val):
                return val
            # 转为字符串
            val = str(val)
            # 多值处理
            parts = val.split('||')
            cleaned_parts = []
            for part in parts:
                # 去除首尾空白，合并中间连续空白
                cleaned = re.sub(r'\s+', ' ', part.strip())
                cleaned_parts.append(cleaned)
            return '||'.join(cleaned_parts)

        # 处理主键列-全部转化成字符串
        for col in primary_keys:
            if col in df.columns:
                df[col] = df[col].astype(str).apply(clean_str)

        # 处理所有object类型的列（字符串列）
        for col in df.select_dtypes(include=['object']).columns:
            if col not in primary_keys:
                df[col] = df[col].apply(clean_str)

        # 列名全部转为小写，并处理table_name.attr为table_name.attr的小写
        new_columns = []
        for col in df.columns:
            if '.' in col:
                parts = col.split('.')
                parts = [p.lower() for p in parts]
                new_columns.append('.'.join(parts))
            else:
                new_columns.append(col.lower())
        df.columns = new_columns

        return df


