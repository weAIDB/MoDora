

import json
import pandas as pd
from quest.core.evaluator.evaluator import DeprecatedFuncExtractionEvaluator


evaluator = DeprecatedFuncExtractionEvaluator()

gt_table_path = "/data/QUEST/jzshe/project/quest/data/benchmark/ground_truth/player.csv"
pred_table_path = "/data/QUEST/jzshe/project/quest/quest/tests/log/player/SF3.csv"


## 指定获得pred所使用的sql语句
## 非aggregation语句，比较的主键列是fixed的，取决于参与join的两个表的id。
sql="""SELECT player.name, team.name,  team.location
           FROM player
           INNER JOIN team ON player.team = team.name
        """

## 读取并且清洗gt，之后在gt上执行sql，得到result_gt
gt_df = pd.read_csv(gt_table_path, encoding='utf-8')
gt_cleaned_df = evaluator.clean_table(gt_df, primary_keys=["team_name"], type = "gt")
result_gt = evaluator.execute_sql_on_gt(sql, primary_keys=["team.id, player.id"], gt_table = gt_df) # primary_keys的列如果没有出现在sql中，需要加上

## 读取并且清洗pred表
pred_df = pd.read_csv(pred_table_path, encoding='utf-8')
pred_cleaned_df = evaluator.clean(pred_df, type = "pred")

# 对确定主键的两个表进行逐列准确率计算。
report = evaluator.cal_intersection_and_acc(    
    aligned_pred_df=
)

    # gt_table=result_gt,      # 全量正确答案
    # pred_table=pred_cleaned_df,       # Agent 懒抽取得到

print(json.dumps(report, indent=2, ensure_ascii=False))
