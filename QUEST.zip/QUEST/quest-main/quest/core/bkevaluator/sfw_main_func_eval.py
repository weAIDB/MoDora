

import json
import pandas as pd
from quest.core.evaluator.evaluator import DeprecatedFuncExtractionEvaluator


evaluator = DeprecatedFuncExtractionEvaluator()

gt_table_path = "/data/QUEST/jzshe/project/quest/data/benchmark/ground_truth/player.csv"
pred_table_path = "/data/QUEST/jzshe/project/quest/quest/tests/log/player/SF3.csv"


## 指定获得pred所使用的sql语句
## 非aggregation语句，比较的主键列是fixed的，取决于参与join的两个表的id。
sql="""SELECT position
    FROM player
    WHERE ((((age>=25 AND nationality='Italian') AND position='Frontcourt') OR draft_year<=1979) OR fiba_world_cup=1);
        """

duckdb_sql , primary_keys = evaluator.parse_and_convert_sql(sql) # primary_keys的列如果没有出现在sql中，需要加上

## 读取并且清洗gt，之后在gt上执行sql，得到result_gt
gt_df = pd.read_csv(gt_table_path, encoding='utf-8')
gt_cleaned_df = evaluator.clean_table(gt_df, primary_keys=primary_keys)
result_gt = evaluator.execute_sql_on_gt(sql,  gt_table = gt_df)

## 读取并且清洗pred表
pred_df = pd.read_csv(pred_table_path, encoding='utf-8')
pred_cleaned_df = evaluator.clean_table(pred_df, primary_keys=primary_keys)

len_pred_table = len(pred_cleaned_df)
len_gt_table = len(result_gt)

print(f"len_pred_table: {len_pred_table}")
print(f"len_gt_table: {len_gt_table}")

pred_with_primary_key, gt_with_primary_key = evaluator.gen_primary_keys_and_drop_dups(pred_cleaned_df, result_gt, primary_keys)

aligned_pred_df, aligned_gt_df = evaluator.align_pred_gt_by_fixed_primary_keys(pred_with_primary_key, gt_with_primary_key)


# 对确定主键的两个表进行逐列准确率计算。
report = evaluator.cal_acc_fixed(    
    aligned_pred_df=pred_cleaned_df,       # Agent 懒抽取得到
    aligned_gt_df=result_gt,      # 全量正确答案
    primary_keys=primary_keys,
    len_pred_table=len_pred_table,
    len_gt_table=len_gt_table
)


print(json.dumps(report, indent=2, ensure_ascii=False))
