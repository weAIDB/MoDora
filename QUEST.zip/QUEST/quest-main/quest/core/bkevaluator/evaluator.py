
import sys
import numpy as np
import pandas as pd
import duckdb
import re
import sqlglot

"""
SELECT marriage, AVG(age) FROM wikiart GROUP BY marriage

SELECT zodiac, MAX(age) FROM wikiart GROUP BY zodiac

SELECT century, MAX(age) FROM wikiart GROUP BY century

SELECT birth_continent, COUNT(name) FROM wikiart GROUP BY birth_continent
"""


class ExtractionEvaluator():
    def __init__(self, sql, pred_table, gt_table_dict, attr_type_dict = None):
        # attr_type_dict : map(table_name, map(attr_name, attr_type))
        self.sql = sql
        self.pred_table = pred_table
        self.gt_table_dict = gt_table_dict
        # 如果只有1个表，要把这个默认表明存下来，便于后续cal_acc_by_type时使用。
        if len(gt_table_dict) == 1:
            self.default_gt_table_name = list(gt_table_dict.keys())[0]
        else:
            self.default_gt_table_name = None
        # gt_table在有join的情况下可能会有多个表。以dict map(table_name, table)的形式来存储它们。
        self.attr_type_dict = attr_type_dict
        if self.attr_type_dict is None:
            self.attr_type_dict = {}
            for table_name, table_df in gt_table_dict.items():
                self.infer_attr_type(table_name, table_df)
        pass

    def infer_attr_type(self, table_name, table_df):
        # 对于用户没有给出每一列类型的表，自动推断出每一列的类型
        # 需要支持的常见类型包括： INT, FLOAT, STRING, DATE, BOOLEAN, LIST[STRING]
        # 其中LIST[STRING]是用||分隔的字符串，在clean_table中会被转化成list
        
        attr_type_map = {}
        
        for col_name in table_df.columns:
            col_series = table_df[col_name]
            
            if col_series.dtype == 'float64':
                # Check if all non-null values are actually integers
                if col_series.dropna().apply(lambda x: float(x).is_integer()).all():
                    attr_type_map[col_name] = 'INT'
                else:
                    attr_type_map[col_name] = 'FLOAT'
            elif col_series.dtype == 'int64':
                attr_type_map[col_name] = 'INT'
            elif col_series.dtype == 'object':
                # Try to convert to datetime
                try:
                    pd.to_datetime(col_series)
                    attr_type_map[col_name] = 'DATE'
                except ValueError:
                    # Check for boolean type
                    unique_values = set(col_series.dropna().unique())
                    if unique_values.issubset({True, False}) or unique_values.issubset({'True', 'False'}) or unique_values.issubset({'true', 'false'}):
                        attr_type_map[col_name] = 'BOOLEAN'
                    # Check for LIST[STRING] type
                    elif col_series.str.contains('\|\|').any():
                        attr_type_map[col_name] = 'LIST[STRING]'
                    else:
                        attr_type_map[col_name] = 'STRING'
            else:
                attr_type_map[col_name] = str(col_series.dtype)

        self.attr_type_dict[table_name] = attr_type_map
        return attr_type_map

    def infer_attr_type_and_clean(self, gt_table_dict, pred_df):
        # 使用gt_table_dict中的table_name和table_df，来推断出每个表格中每个属性的类型，然后根据这些类型信息对pred_df中的每个属性进行逐列清洗
        # 当Sql语句不包含join时，pred_df的属性名就是attr_name
        # 当Sql语句包含join时，pred_df会出现table_name.attr_name的属性
        # 当Sql语句包含group by时，pred_df会出现avg(attr_name), max(attr_name)这种情况。
        pass


    def parse_and_convert_sql(self):
        """
        尝试将sql转换为适用于duckdb的sql，用sqlglot
        并从中提取出group by的属性列名(之后join pred_table和gt_table时将被用作join列/主键列)
        并将表名、属性名、别名全部转换为小写
        并将所有表别名和列别名都替换成原始的表名和列名
        返回: (duckdb_sql: str, candidate_primary_keys: list[str])
        """
        sql  = self.sql
        sql_clean = ' '.join(sql.strip().split())

        try:
            parsed = sqlglot.parse_one(sql_clean)
        except Exception as e:
            raise ValueError(f"SQL 解析失败: {e}")

        # 替换表别名和列别名为原始表名和列名
        def remove_aliases(node):
            # 替换表别名为原始表名
            if node.__class__.__name__ == "TableAlias":
                return node.this  # 返回原始表节点
            # 替换列别名为原始表达式
            if node.__class__.__name__ == "Alias":
                return node.this  # 返回原始表达式
            return node

        # 将别名替换为原始表名
        parsed = parsed.transform(remove_aliases)

        # 转小写
        for node in parsed.walk():
            # 列名
            if node.__class__.__name__ == "Column":
                if node.args.get("this"):
                    node.set("this", node.args["this"].copy().transform(lambda n: n.lower() if isinstance(n, str) else n))
                if node.args.get("table"):
                    node.set("table", node.args["table"].copy().transform(lambda n: n.lower() if isinstance(n, str) else n))
            # 表名
            if node.__class__.__name__ == "Table":
                if node.args.get("this"):
                    node.set("this", node.args["this"].copy().transform(lambda n: n.lower() if isinstance(n, str) else n))
            # 别名
            if node.args.get("alias"):
                alias = node.args["alias"]
                if hasattr(alias, "set"):
                    if alias.args.get("this"):
                        alias.set("this", alias.args["this"].copy().transform(lambda n: n.lower() if isinstance(n, str) else n))

        duckdb_sql = parsed.to_sql(dialect="duckdb")

# ...existing code...
        candidate_primary_keys = [] # group by 的列名
        group = parsed.args.get("group")

        if group:
            for g in group.expressions:
                # 处理带表名前缀的列
                if hasattr(g, "args"):
                    table = None
                    col = None
                    # 兼容 Column 节点
                    if "table" in g.args and g.args["table"]:
                        table = str(g.args["table"]).lower()
                    if "this" in g.args and hasattr(g.args["this"], "name"):
                        col = g.args["this"].name.lower()
                    elif hasattr(g, "name"):
                        col = g.name.lower()
                    if table and col:
                        candidate_primary_keys.append(f"{table}.{col}")
                    elif col:
                        candidate_primary_keys.append(col)
                    else:
                        candidate_primary_keys.append(str(g).lower())
                else:
                    candidate_primary_keys.append(str(g).lower())

        else:
            # 已知一般情况下，primary keys名称是f"{table_name}.id"
            # Sql中没有group by-aggregation操作，直接根据出现的所有表名来推断primary keys的列表
            table_names = []
            for node in parsed.walk():
                if node.__class__.__name__ == "Table":
                    if node.args.get("this"):
                        table_name = str(node.args["this"]).lower()
                        table_names.append(table_name)
            # 去重
            table_names = list(set(table_names))
            # 构造主键名
            for table_name in table_names:
                candidate_primary_keys.append(f"{table_name}.id")
        # 为了后续与pred_table做准确率比较，必须要在SELCT FROM中包含candidate_primary_keys的那些列。
        # 保证duckdb_sql的SELECT中包含所有candidate_primary_keys
        # 如果缺失，则补到select前面
        # 利用AST再次检查
        select_cols = []
        select_node = parsed.args.get('expressions')
        if select_node:
            # select_node 是list
            for sel in select_node:
                if hasattr(sel, 'args') and 'this' in sel.args:
                    if sel.args.get('this'):
                        # 兼容col、函数等
                        if hasattr(sel.args['this'], 'name'):
                            select_cols.append(sel.args['this'].name.lower())
                        elif isinstance(sel.args['this'], str):
                            select_cols.append(sel.args['this'].lower())
                        else:
                            select_cols.append(str(sel.args['this']).lower())
                elif hasattr(sel, 'name'):
                    select_cols.append(sel.name.lower())
                else:
                    select_cols.append(str(sel).lower())
        else:
            # 无select？跳过
            select_cols = []

        # 检查primary key列是否都在select中，否则补上
        missing_pks = [pk for pk in candidate_primary_keys if pk not in select_cols]
        if missing_pks:
            # 补到select头部，重新构造select
            select_text = ', '.join(missing_pks + [expr.sql(dialect='duckdb') for expr in parsed.args['expressions']])
            # 替换掉原来的select部分
            # 重建SQL字符串
            from_idx = duckdb_sql.lower().find('from')
            if from_idx != -1:
                duckdb_sql = f"SELECT {select_text} {duckdb_sql[from_idx:]}"
            else:
                # 理论上不会走到这里
                raise Exception("补充primary key到select from失败，无法找到from子句")

        return duckdb_sql, candidate_primary_keys

    def align_pred_gt_by_joint_key(self, pred_df, gt_res_df):
        if self.group_by_flag == False: 
            aligned_pred_df, aligned_gt_res_df = self.fixed_align_pred_gt_by_joint_key(pred_df, gt_res_df)
        else:
            aligned_pred_df, aligned_gt_res_df = self.unfixed_align_pred_gt_by_joint_key(pred_df, gt_res_df) # 需要使用1对1的join来模糊匹配pred_df和gt_df的group by列
        return aligned_pred_df, aligned_gt_res_df

    def unfixed_align_pred_gt_by_joint_key(self, pred_df, gt_res_df):
        group_by_primary_key = self.primary_keys[0] # 这里默认group by的属性只有1个
        # 调用pd_fuse_join进行1对1的join，匹配pred_df和gt_df的group by列，没匹配上的行需要丢弃。
        pass

    def fixed_align_pred_gt_by_joint_key(self, pred_df, gt_res_df):
        
        key_col = '__joint_key__'

        # 求交集 
        joint_keys_intersection = set(pred_df[key_col]) & set(gt_res_df[key_col])
        pred_df = pred_df[pred_df[key_col].isin(joint_keys_intersection)]
        gt_res_df = gt_res_df[gt_res_df[key_col].isin(joint_keys_intersection)]

        # 按主键排序
        aligned_pred_df = pred_df.sort_values(by=key_col).reset_index(drop=True)
        aligned_gt_res_df = gt_res_df.sort_values(by=key_col).reset_index(drop=True)

        return aligned_pred_df, aligned_gt_res_df # 在debug状态下，这2个表要存下来，由于按主键排序，方便逐行对照查错。

    def udf_clean_table(self, df: pd.DataFrame) -> pd.DataFrame:
        # 根据table_name将主键列名更改为table_name.id的形式
        table_name = self.table_name
        # 将'id'列重命名为'table_name.id'
        df.rename(columns={'id': f'{table_name}.id'}, inplace=True)
        return df



    def clean_table(self, df: pd.DataFrame) -> pd.DataFrame:
        # 执行默认的清洗流程
        # 对于字符串类型的值，trim首尾空格，相邻token间的连续空白符统一转换成1个空格
        # 对于primary key, 统一按照字符串类型处理，如果是int，则需要转化成字符串。
        # 对于多值字符串属性，我们不需要知道它是不是多值属性，我们只需要在处理字符串时先按照分隔符'||' split，然后对split出来的每个组分别做清洗，最后再用||拼接各个组即可。如果本来是单值属性，就不会拼接上||，所以逻辑也是对的。        
        
        def clean_str(val):
            
            if pd.isnull(val):
                return val
            # 转为字符串
            val = str(val)
            # 多值处理
            parts = val.split('||')
            cleaned_parts = []
            for part in parts:
                # 去除首尾空白，合并中间连续空白
                cleaned = re.sub(r'\s+', ' ', part.strip())
                cleaned_parts.append(cleaned)
            return '||'.join(cleaned_parts)

        primary_keys = self.primary_keys
        # 处理主键列-全部转化成字符串
        for col in primary_keys:
            if col in df.columns:
                df[col] = df[col].astype(str).apply(clean_str)

        # 处理所有object类型的列（字符串列）
        for col in df.select_dtypes(include=['object']).columns:
            if col not in primary_keys:
                df[col] = df[col].apply(clean_str)

        # 列名全部转为小写，并处理table_name.attr为table_name.attr的小写
        new_columns = []
        for col in df.columns:
            if '.' in col:
                parts = col.split('.')
                parts = [p.lower() for p in parts]
                new_columns.append('.'.join(parts))
            else:
                new_columns.append(col.lower())
        df.columns = new_columns

        return df


    def execute_sql_on_gt(self, sql,  gt_table_dict) -> pd.DataFrame:
        # 在内存中逐一注册gt_table_dict中的表格为duckdb的表
        # gt_table_dict : map(table_name, table_df)
        con = duckdb.connect(database=':memory:')
        for table_name, table_df in gt_table_dict.items():
            con.register(table_name, table_df)
        # 执行SQL
        result_df = con.execute(sql).fetchdf()
        con.close()
        return result_df

    def gen_joint_key_and_drop_dups(self, pred_df, gt_res_df):
        # 先把primary_keys列-联合主键，加一列，然后pred_df和gt_res_df分别对主键列去重(如果有重复的需要给出Warning并且输出重复行的内容到stderr)
        # 先生成联合主键列名(即便是单主键，也采用这个主键名：__joint_key__)
        primary_keys = self.primary_keys
        key_col = '__joint_key__'
        # 生成联合主键列
        pred_df[key_col] = pred_df[primary_keys].astype(str).agg('||'.join, axis=1)
        gt_res_df[key_col] = gt_res_df[primary_keys].astype(str).agg('||'.join, axis=1)

        # 检查并输出重复主键
        pred_dups = pred_df[pred_df.duplicated(key_col, keep=False)]
        gt_dups = gt_res_df[gt_res_df.duplicated(key_col, keep=False)]

        if not pred_dups.empty:
            print(f"[Warning] pred_df 存在重复主键行：", file=sys.stderr)
            print(pred_dups, file=sys.stderr)
        if not gt_dups.empty:
            print(f"[Warning] gt_df 存在重复主键行：", file=sys.stderr)
            print(gt_dups, file=sys.stderr)

        # 去重
        pred_df = pred_df.drop_duplicates(key_col, keep='first')
        gt_res_df = gt_res_df.drop_duplicates(key_col, keep='first')

        return pred_df, gt_res_df




    def evaluate(self):
        ## 1. 解析SQL，提取primary-keys，转化成duckDB支持的标准形式。
        duckdb_sql , primary_keys = self.parse_and_convert_sql()
        self.duckdb_sql = duckdb_sql
        self.primary_keys = primary_keys
        ## 2. 清洗pred_table和gt_table
        gt_cleaned_df = self.clean_table(self.gt_table_dict, primary_keys=primary_keys)
        pred_cleaned_df = self.clean_table(self.pred_table, primary_keys=primary_keys)
        ## 3. 执行SQL
        gt_res_df = self.execute_sql_on_gt(duckdb_sql, gt_cleaned_df)
        ## 4. 生成主键列joint_key(兼容多表join的情况)，去除重复行
        pred_cleaned_df, gt_res_df = self.gen_joint_key_and_drop_dups(pred_cleaned_df, gt_res_df)
        len_pred_table = len(pred_cleaned_df)
        len_gt_table = len(gt_res_df)
        ## 5. 根据联合主键joint_key，对齐两表。
        aligned_pred_df, aligned_gt_res_df = self.align_pred_gt_by_joint_key(pred_cleaned_df, gt_res_df)
        ## 6. 用对齐后的两表逐列计算准确率。
        acc_report = self.calc_acc(aligned_pred_df, aligned_gt_res_df, len_pred_table, len_gt_table)

        return


    def calc_acc(self, aligned_pred_df, aligned_gt_res_df, len_pred_table, len_gt_table):
        if self.fixed_acc_flag == True:
            acc_report = self.calc_acc_fixed(aligned_pred_df, aligned_gt_res_df, len_pred_table, len_gt_table) # 每一列都是精确比较。
        return acc_report


        # 根据之前self.attr_type_dict中每一列的类型信息，逐列计算准确率
        # 注意在含join结果的表中，结果属性名是{table_name}.{attr_name}
        # jztodo
    def cal_acc_by_type(self, aligned_pred_df, aligned_gt_df, primary_keys, len_pred_table, len_gt_table):
        """
        根据每一列的类型信息，采用不同的方式逐列计算准确率/召回率/F1
        """
        metrics = {}
        sum_precision = 0.0
        sum_recall = 0.0
        sum_f1 = 0.0
        num_cols = 0

        for col in aligned_gt_df.columns:
            if col in primary_keys or col == '__joint_key__':
                continue

            # 获取表名和字段名
            if '.' in col:
                table_name, attr_name = col.split('.', 1)
            else:
                # 没有表前缀的情形
                table_name, attr_name = None, col

            attr_type = None
            if table_name and table_name in self.attr_type_dict and attr_name in self.attr_type_dict[table_name]:
                attr_type = self.attr_type_dict[table_name][attr_name]
            elif self.default_gt_table_name is not None and attr_name in self.attr_type_dict[self.default_gt_table_name]:
                attr_type = self.attr_type_dict[self.default_gt_table_name][attr_name]
            else:
                # fallback
                attr_type = 'STRING'

            y_true = aligned_gt_df[col]
            y_pred = aligned_pred_df[col]
            correct = None

            # 类型相关的比对
            if attr_type == 'FLOAT':
                # 允许微小误差
                correct = (np.isclose(y_true, y_pred, atol=1e-4) | ((y_true.isnull()) & (y_pred.isnull())))
            elif attr_type == 'INT':
                correct = ((y_true == y_pred) | ((y_true.isnull()) & (y_pred.isnull())))
            elif attr_type == 'DATE':
                # 转成日期再比较
                y_true_dt = pd.to_datetime(y_true, errors='coerce')
                y_pred_dt = pd.to_datetime(y_pred, errors='coerce')
                correct = ((y_true_dt == y_pred_dt) | ((y_true_dt.isnull()) & (y_pred_dt.isnull())))
            elif attr_type == 'BOOLEAN':
                # 先标准化
                def norm_bool(x):
                    if pd.isnull(x): return None
                    if isinstance(x, bool): return x
                    s = str(x).strip().lower()
                    if s in ('1','true','yes'): return True
                    if s in ('0','false','no'): return False
                    return None
                correct = ([norm_bool(a)==norm_bool(b) for a,b in zip(y_true, y_pred)])
                correct = pd.Series(correct)
            elif attr_type == 'LIST[STRING]':
                def split_and_norm(s):
                    if pd.isnull(s): return []
                    return sorted([t.strip().lower() for t in str(s).split('||') if t.strip() != ''])
                correct = ([split_and_norm(a)==split_and_norm(b) for a,b in zip(y_true, y_pred)])
                correct = pd.Series(correct)
            else:
                # 默认按字符串、忽略大小写和空白
                def norm_str(x):
                    if pd.isnull(x): return ''
                    return ' '.join(str(x).strip().lower().split())
                correct = ([norm_str(a)==norm_str(b) for a,b in zip(y_true, y_pred)])
                correct = pd.Series(correct)

            tp = correct.sum()

            if len_pred_table == 0 and len_gt_table == 0: 
                precision = 1.0
                recall = 1.0
                f1 = 1.0
            else:
                precision = tp / len_pred_table if len_pred_table > 0 else 0.0
                recall = tp / len_gt_table if len_gt_table > 0 else 0.0
                f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) > 0 else 0.0

            sum_precision += precision
            sum_recall += recall
            sum_f1 += f1
            num_cols += 1

            metrics[col] = {
                'precision': precision,
                'recall': recall,
                'f1': f1
            }

        # 平均
        metrics['__avg__'] = {
            'precision': sum_precision / num_cols if num_cols > 0 else 0.0,
            'recall': sum_recall / num_cols if num_cols > 0 else 0.0,
            'f1': sum_f1 / num_cols if num_cols > 0 else 0.0
        }

        return metrics



    def calc_acc_fixed(self, aligned_pred_df, aligned_gt_res_df, len_pred_table, len_gt_table):
        """
        计算aligned_pred_df和aligned_gt_df逐列的准确率precision, recall, f1
        aligned_pred_df, aligned_gt_df: pd.DataFrame，已经按primary_keys对齐并且取交集后的pred_df和gt_res_df
        primary_keys: list[str]，primary_keys的列名
        这里暂且使用精确匹配的方式，即2个值必须完全相同才算相等。
        返回：嵌套字典，metrics[col]中包括precision, recall, f1这3个值。
        不需要计算primary keys列的准确率-否则可能拉高平均准确率。
        """
        primary_keys = self.primary_keys
        metrics = {}
        # 遍历除primary_keys以外的所有列
        for col in aligned_gt_res_df.columns:
            if col in primary_keys or col == '__joint_key__':
                continue

            y_true = aligned_gt_res_df[col]
            y_pred = aligned_pred_df[col]

            # 精确匹配
            correct = (y_true == y_pred)
            tp = correct.sum()  # 真正例

            if len_pred_table == 0 and len_gt_table == 0: 
                precision = 1.0
                recall = 1.0
                f1 = 1.0
            else:
                precision = tp / len_pred_table if len_pred_table > 0 else 0.0
                recall = tp / len_gt_table if len_gt_table > 0 else 0.0
                f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) > 0 else 0.0

            metrics[col] = {
                'precision': precision,
                'recall': recall,
                'f1': f1
            }
        # 这里需要加一个所有列的平均准确率
        metrics['average'] = {
            'precision': np.mean([metrics[col]['precision'] for col in metrics]),
            'recall': np.mean([metrics[col]['recall'] for col in metrics]),
            'f1': np.mean([metrics[col]['f1'] for col in metrics])
        }

        return metrics





