import sys
sys.path.append('/home/lijianhui/workspace/quest')

import os
from quest.sql.parser import sqlparser
from quest.utils.class2json import ClassToJson
from quest.sql.planner.baselogical import BaseLogicalPlanner
from quest.sql.planner.physical import TextPhysicalPlanner
from quest.sql.processer.processer import Processer
from quest.db.indexer.indexer import GlobalIndexer, load_all_indexer
from quest.core.llm.sampler import AttrSampler
from quest.core.llm.llm_query import TextLLMQuerier, LLMInfo
from quest.utils.log import print_log
from quest.conf.settings import RELATIVE_PROJECT_ROOT_PATH
from quest.db.indexer.indexer import GlobalIndexer, build_all_indexer

fin_docs_dir = "/data/QUEST/benchmark/small_datasets/finance"

def run(sql, prompt):
    print(sql)

    # build AST
    ast = sqlparser.parse_sql(sql)
    jsonConverter = ClassToJson()
    js = jsonConverter.toJson(ast)
    print("AST:\n", js)

    # build logical plan

    logicalPlanner = BaseLogicalPlanner()
    logical = logicalPlanner.build_logical_plan(ast)
    js = jsonConverter.toJson(logical)
    print_log("Logical Plan:\n",js)

    # indexer and sampler

    # gb_indexer = build_all_indexer(
    #     doc_dirs=[fin_docs_dir],
    #     tables_name=["finance"],
    #     types=["TextDoc"],
    #     debug_flag= False
    # )

    gb_indexer = load_all_indexer(table_to_type = {"finance" : "TextDoc"})
    
    gb_sampler = AttrSampler(schema = prompt)
    gb_querier = TextLLMQuerier(prompt=prompt)

    gb_sampler.try_sample(gb_indexer.get_indexer("finance")[0], prompt)

    # build physical plan

    physicalPlanner = TextPhysicalPlanner(gb_indexer, gb_querier, sampler=gb_sampler)
    physical = physicalPlanner.build(logical)
    #js = jsonConverter.toJson(physical)
    #print_log("Physical Plan:\n",js)

    # process

    processer = Processer()
    result = processer.process(physical)
    print_log("Result Table:\n", result)

    # LLM latency
    print("query_times : ", LLMInfo.tot_query_times)
    print("input_tokens : ", LLMInfo.tot_input_tokens)
    print("output_tokens : ", LLMInfo.tot_output_tokens)


    # 存到log/x.csv里 RELATIVE_PROJECT_ROOT_PATH
    result.to_csv(os.path.join(RELATIVE_PROJECT_ROOT_PATH, "../experiment_result/embedding/qwen/SF10.csv"))

    return result

if __name__ == "__main__":
    sql = "SELECT net_assets, exchange_code, major_equity_changes FROM finance"
    prompt = \
    """
    net_assets: net asset value at the end of the reporting period. Enter a number. If the original currency is not USD, convert to USD according to the latest available exchange rate.\n \
    exchange_code: The code of the stock exchange where the company is listed (e.g., ASX, SUN).\n \
    major_equity_changes: whether there were major equity changes during the period; choose one from ['Yes', 'No'].\n
    """
    run(sql, prompt)