import sys
sys.path.append('/home/lijianhui/workspace/quest')
#sys.path.append('/data/QUEST/jzshe/project/quest')

import os
from quest.sql.parser import sqlparser
from quest.utils.class2json import ClassToJson
from quest.sql.planner.baselogical import BaseLogicalPlanner
from quest.sql.planner.physical import TextPhysicalPlanner
from quest.sql.processer.processer import Processer
from quest.db.indexer.indexer import GlobalIndexer, load_all_indexer
from quest.core.llm.sampler import AttrSampler
from quest.core.llm.llm_query import TextLLMQuerier, LLMInfo
from quest.utils.log import print_log
from quest.conf.settings import RELATIVE_PROJECT_ROOT_PATH
from quest.sql.optimizer.optimizer_filter import OptimizerFilter
from quest.db.indexer.indexer import GlobalIndexer, build_all_indexer

lcr_docs_dir = "/data/QUEST/benchmark/small_datasets/legal_case"

def run(sql, prompt):
    print(sql)

    # build AST
    ast = sqlparser.parse_sql(sql)
    jsonConverter = ClassToJson()
    js = jsonConverter.toJson(ast)
    print("AST:\n", js)

    # build logical plan

    logicalPlanner = BaseLogicalPlanner()
    logical = logicalPlanner.build_logical_plan(ast)
    js = jsonConverter.toJson(logical)
    print_log("Logical Plan:\n",js)

    # indexer and sampler

    # gb_indexer = build_all_indexer(
    #     doc_dirs=[lcr_docs_dir],
    #     tables_name=["lcr"],
    #     types=["TextDoc"],
    #     debug_flag= False
    # )

    gb_indexer = load_all_indexer(table_to_type = {"lcr" : "TextDoc"})
    
    gb_sampler = AttrSampler(schema = prompt)
    gb_querier = TextLLMQuerier(prompt=prompt)

    gb_sampler.try_sample(gb_indexer.get_indexer("lcr")[0], prompt)

    # build physical plan

    print("optimize now! - - - - -")

    optimizer = OptimizerFilter(indexer = gb_indexer, querier = gb_querier, sampler = gb_sampler, batch_size=30)
    opt = optimizer.build(logical)

    print("physical now! - - - - -")

    physicalPlanner = TextPhysicalPlanner(gb_indexer, gb_querier, sampler=gb_sampler)
    physical = physicalPlanner.build(opt)
    #js = jsonConverter.toJson(physical)
    #print_log("Physical Plan:\n",js)

    # process

    processer = Processer()
    result = processer.process(physical)
    print_log("Result Table:\n", result)

    # LLM latency
    print("query_times : ", LLMInfo.tot_query_times)
    print("input_tokens : ", LLMInfo.tot_input_tokens)
    print("output_tokens : ", LLMInfo.tot_output_tokens)


    # 存到log/x.csv里 RELATIVE_PROJECT_ROOT_PATH
    result.to_csv(os.path.join(RELATIVE_PROJECT_ROOT_PATH, "../experiment_result/embedding/qwen/lcr/SFW6.csv"))

    return result

if __name__ == "__main__":
    sql = "SELECT fine_amount, legal_basis_num, plaintiff FROM lcr WHERE ((verdict=='Dismissed' AND judgment_year>2008) AND evidence==1)"
    prompt = \
    """
    first_judge: whether it was the first judgment (1 if yes, 0 if none; e.g., 1). \n \
    case_type: type of the case, choose one from [Criminal Case, Civil Case, Commercial Case, Administrative Case]; (e.g., Criminal Case).\n \
    judge_name: name of the judge presiding over the case (e.g., arshall J.).\n \
    charges: list of specific legal accusations or charges brought against the defendant (e.g., misleading conduct; price fixing; use a semicolon to separate multiple charges; leave empty if not applicable) \n \
    defendant: name of the first person or entity being sued or accused (if there are multiple defendants, extract only the first one mentioned; e.g., Narnia Investments Pty Ltd). \n \
    case_number: Number of distinct precedent cases referenced in the judgment, including those cited, considered, discussed, or applied (e.g., 'Australian Competition and Consumer Commission v Rana' counts as 1; enter an integer, e.g., 1). \n \
    fine_amount: total monetary amount of fines imposed in the case (include all fines, partial payments, and fines for multiple parties; leave empty if none; e.g., 250000). \n \
    legal_basis_num: Number of distinct legal statutes or codes cited in the judgment (e.g., 'Trade Practices Act 1974' counts as 1; enter an integer, e.g., 1).\n \
    verdict: court's decision, choose one from [Guilty, Not Guilty, Others, Dismissed, Approved]; (e.g., Guilty)\n \
    judgment_year: year when the judgment was delivered; use format YYYY (e.g., 2009).\n \
    defendant_current_status: current occupation or type of the defendant (rules same as for plaintiff; e.g., government). \n \
    evidence: whether evidence was provided (1 if yes, 0 if none; e.g., 1). \n \
    plaintiff: name of the first person or entity who initiates a lawsuit or legal action(if there are multiple plaintiffs, extract only the first one mentioned; e.g., Cairnsmore Holdings Pty Ltd). \n \
    nationality_for_applicant: applicant’s nationality (e.g., Australia). \n \
    legal_fees: total amount of legal fees awarded or imposed (sum all applicable fees; leave empty if none; e.g., 30000). \n
    """
    run(sql, prompt)