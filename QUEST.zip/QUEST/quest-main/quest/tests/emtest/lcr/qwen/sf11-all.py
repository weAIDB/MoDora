import sys
sys.path.append('/home/lijianhui/workspace/quest')
#sys.path.append('/data/QUEST/jzshe/project/quest')

import os
from quest.sql.parser import sqlparser
from quest.utils.class2json import ClassToJson
from quest.sql.planner.baselogical import BaseLogicalPlanner
from quest.sql.planner.physical import TextPhysicalPlanner
from quest.sql.processer.processer import Processer
from quest.db.indexer.indexer import GlobalIndexer, load_all_indexer
from quest.core.llm.sampler import AttrSampler
from quest.core.llm.llm_query import TextLLMQuerier, LLMInfo
from quest.utils.log import print_log
from quest.conf.settings import RELATIVE_PROJECT_ROOT_PATH
from quest.db.indexer.indexer import GlobalIndexer, build_all_indexer

lcr_docs_dir = "/data/QUEST/benchmark/small_datasets/legal_case"

def run(sql, prompt):
    print(sql)

    # build AST
    ast = sqlparser.parse_sql(sql)
    jsonConverter = ClassToJson()
    js = jsonConverter.toJson(ast)
    print("AST:\n", js)

    # build logical plan

    logicalPlanner = BaseLogicalPlanner()
    logical = logicalPlanner.build_logical_plan(ast)
    js = jsonConverter.toJson(logical)
    print_log("Logical Plan:\n",js)

    # indexer and sampler

    # gb_indexer = build_all_indexer(
    #     doc_dirs=[lcr_docs_dir],
    #     tables_name=["lcr"],
    #     types=["TextDoc"],
    #     debug_flag= False
    # )

    gb_indexer = load_all_indexer(table_to_type = {"lcr" : "TextDoc"})
    
    gb_sampler = AttrSampler(schema = prompt)
    gb_querier = TextLLMQuerier(prompt=prompt)

    gb_sampler.try_sample(gb_indexer.get_indexer("lcr")[0], prompt)

    # build physical plan

    physicalPlanner = TextPhysicalPlanner(gb_indexer, gb_querier, sampler=gb_sampler)
    physical = physicalPlanner.build(logical)
    #js = jsonConverter.toJson(physical)
    #print_log("Physical Plan:\n",js)

    # process

    processer = Processer()
    result = processer.process(physical)
    print_log("Result Table:\n", result)

    # LLM latency
    print("query_times : ", LLMInfo.tot_query_times)
    print("input_tokens : ", LLMInfo.tot_input_tokens)
    print("output_tokens : ", LLMInfo.tot_output_tokens)


    # 存到log/x.csv里 RELATIVE_PROJECT_ROOT_PATH
    result.to_csv(os.path.join(RELATIVE_PROJECT_ROOT_PATH, "quest/tests/log/legal_case/SF11.csv"))

    return result

if __name__ == "__main__":
    sql = "SELECT hearing_year, judgment_year, case_type, verdict, legal_basis_num, counsel_for_applicant, nationality_for_applicant, legal_fees FROM lcr"
    prompt = \
    """
    hearing_year: year when the hearing began; use format YYYY (e.g., 2009). \n \
    judgment_year: year when the judgment was delivered; use format YYYY (e.g., 2009).\n \
    case_type: type of the case, choose one from [Criminal Case, Civil Case, Commercial Case, Administrative Case]; (e.g., Criminal Case). \n \
    verdict: court's decision, choose one from [Guilty, Not Guilty, Others, Dismissed, Approved]; (e.g., Guilty). \n \
    legal_basis_num: Number of distinct legal statutes or codes cited in the judgment (e.g., 'Trade Practices Act 1974' counts as 1; enter an integer, e.g., 1). \n \
    counsel_for_applicant: name of the applicant's lawyer (e.g., Mr I Faulkner SC). \n \
    nationality_for_applicant: applicant's nationality (e.g., Australia). \n \
    legal_fees: total amount of legal fees awarded or imposed (sum all applicable fees; leave empty if none; e.g., 30000). \n
    """
    run(sql, prompt)