import sys
sys.path.append('/home/lijianhui/workspace/quest')
#sys.path.append('/data/QUEST/jzshe/project/quest')

import os
from quest.sql.parser import sqlparser
from quest.utils.class2json import ClassToJson
from quest.sql.planner.joinlogical import JoinLogicalPlanner
from quest.sql.planner.joinphysical import JoinPhysicalPlanner
from quest.sql.processer.processer import Processer
from quest.db.indexer.indexer import GlobalIndexer, load_all_indexer
from quest.core.llm.sampler import AttrSampler
from quest.core.llm.llm_query import TextLLMQuerier, LLMInfo
from quest.utils.log import print_log
from quest.conf.settings import RELATIVE_PROJECT_ROOT_PATH
from quest.db.indexer.indexer import GlobalIndexer, build_all_indexer
from quest.sql.optimizer.optimizer_filter import OptimizerFilter
from quest.sql.optimizer.optimizer_join import OptimizerJoin

nba_player_docs_dir = "/data/QUEST/benchmark/datasets/player"
wikiart_docs_dir = "/data/QUEST/benchmark/small_datasets/Wiki_Text"
fin_docs_dir = "/data/QUEST/benchmark/small_datasets/finance"
lcr_docs_dir = "/data/QUEST/benchmark/small_datasets/legal_case"
disease_docs_dir = "/data/QUEST/benchmark/small_datasets/disease"
drug_docs_dir  = "/data/QUEST/benchmark/small_datasets/drug"
institutes_docs_dir = "/data/QUEST/benchmark/small_datasets/institutes"

def run(sql, prompt):
    print(sql)

    # build AST
    ast = sqlparser.parse_sql(sql)
    jsonConverter = ClassToJson()
    js = jsonConverter.toJson(ast)
    print("AST:\n", js)

    # build logical plan

    logicalPlanner = JoinLogicalPlanner()
    logical = logicalPlanner.build_logical_plan(ast)
    js = jsonConverter.toJson(logical)
    print_log("Logical Plan:\n",js)

    # indexer and sampler

    gb_indexer = build_all_indexer(
        doc_dirs=[nba_player_docs_dir, wikiart_docs_dir, lcr_docs_dir, disease_docs_dir, drug_docs_dir, institutes_docs_dir ,fin_docs_dir],
        tables_name=["player", "wikiart", "lcr", "disease", "drug", "institutes", "finance"],
        types=["TextDoc","TextDoc","TextDoc","TextDoc", "TextDoc", "TextDoc", "TextDoc"],
        debug_flag= False
    )

    #gb_indexer = load_all_indexer(table_to_type = {"wikiart" : "TextDoc"})

if __name__ == "__main__":

    sql = "SELECT team.team_name, player.name, team.location FROM team, player WHERE player.team == team.team_name AND team.founded_year <= 1989 AND player.nba_championships <= 2"

    prompt = \
    """
    team.founded_year: found_year is the year of this team team founded, a number (e.g., 1947). \n \
    team.location: location is the name of the city where the team is based (e.g., Los Angeles). \n \
    team.team_name: team_name is the name of the NBA team. \n \
    player.name: the full name of the NBA player (e.g., LeBron James). \n \
    player.team: the current NBA team the player belongs to, or the last NBA team the player joined if not currently active (e.g., Los Angeles Lakers). \n \
    player.nba_championships: the number of NBA championships won by the player, a number (e.g., 4). \n 
    """
    
    run(sql, prompt)