import sys
sys.path.append('/home/lijianhui/workspace/quest')
#sys.path.append('/data/QUEST/jzshe/project/quest')

import os
from quest.sql.parser import sqlparser
from quest.utils.class2json import ClassToJson
from quest.sql.planner.baselogical import BaseLogicalPlanner
from quest.sql.planner.physical import TextPhysicalPlanner
from quest.sql.processer.processer import Processer
from quest.db.indexer.indexer import GlobalIndexer, load_all_indexer
from quest.core.llm.sampler import AttrSampler
from quest.core.llm.llm_query import TextLLMQuerier, LLMInfo
from quest.utils.log import print_log
from quest.conf.settings import RELATIVE_PROJECT_ROOT_PATH
from quest.db.indexer.indexer import GlobalIndexer, build_all_indexer
from quest.sql.optimizer.optimizer_filter import OptimizerFilter

wiki_art_docs_dir = "/data/QUEST/benchmark/small_datasets/Wiki_Text"

def run(sql, prompt):
    print(sql)

    # build AST
    ast = sqlparser.parse_sql(sql)
    jsonConverter = ClassToJson()
    js = jsonConverter.toJson(ast)
    print("AST:\n", js)

    # build logical plan

    logicalPlanner = BaseLogicalPlanner()
    logical = logicalPlanner.build_logical_plan(ast)
    js = jsonConverter.toJson(logical)
    print_log("Logical Plan:\n",js)

    # indexer and sampler

    # gb_indexer = build_all_indexer(
    #     doc_dirs=[wiki_art_docs_dir],
    #     tables_name=["wikiart"],
    #     types=["TextDoc"],
    #     debug_flag= False
    # )

    gb_indexer = load_all_indexer(table_to_type = {"wikiart" : "TextDoc"})
    
    gb_sampler = AttrSampler(schema = prompt)
    gb_querier = TextLLMQuerier(prompt=prompt)

    print("sample now! - - - - - ")

    gb_sampler.try_sample(gb_indexer.get_indexer("wikiart")[0], prompt)
    sample_table = gb_sampler.sample_table
    # 存到log/test_sample_table.csv里 RELATIVE_PROJECT_ROOT_PATH
    #sample_table.to_csv(os.path.join(RELATIVE_PROJECT_ROOT_PATH, "quest/tests/log/test_sample_table.csv"))
    #attr_2_evidence = gb_sampler.map_attr_evidence
    #print_log(attr_2_evidence)

    # build physical plan

    print("optimize now! - - - - -")

    optimizer = OptimizerFilter(indexer = gb_indexer, querier = gb_querier, sampler = gb_sampler, batch_size=50)
    opt = optimizer.build(logical)

    print("physical now! - - - - -")

    physicalPlanner = TextPhysicalPlanner(gb_indexer, gb_querier, sampler=gb_sampler)
    physical = physicalPlanner.build(opt)
    #js = jsonConverter.toJson(physical)
    #print_log("Physical Plan:\n",js)

    # process

    print("process now! - - - - - ")

    processer = Processer()
    result = processer.process(physical)
    print_log("Result Table:\n", result)

    # LLM latency
    print("query_times : ", LLMInfo.tot_query_times)
    print("input_tokens : ", LLMInfo.tot_input_tokens)
    print("output_tokens : ", LLMInfo.tot_output_tokens)


    # 存到log/x.csv里 RELATIVE_PROJECT_ROOT_PATH
    result.to_csv(os.path.join(RELATIVE_PROJECT_ROOT_PATH, "../experiment_result/embedding/qwen/wikiart/SFW8.csv"))

    return result

if __name__ == "__main__":

    sql = "SELECT birth_date, death_country, death_city FROM wikiart WHERE name=='David Garshen Bomberg' OR (death_date>'2011/4/8' AND zodiac=='Libra') OR age>=92"

    prompt = \
    """
    death_country: country where the artist died, or leave empty if not applicable (e.g., switzerland). \n \
    death_city: city where the artist died, or leave empty if not applicable. \n \
    age: age of the artist (if death_date is given, compute as death_date - birth_date; otherwise, compute as 2025/1/1 - birth_date). \n \
    name: full name of the artist.\n \
    birth_date: date in %Y/%-m/%-d format (e.g., 1839/1/9), or leave empty if not applicable. \n \
    death_date: date in %Y/%-m/%-d format (e.g., 1836/1/1), or leave empty if not applicable. \n \
    zodiac: western zodiac sign based on birth date, choose only one from [Aries, Taurus, Gemini, Cancer, Leo, Virgo, Libra, Scorpio, Sagittarius, Capricorn, Aquarius, Pisces]. \n
    """
    
    run(sql, prompt)