import sys
sys.path.append('/home/lijianhui/workspace/quest')
#sys.path.append('/data/QUEST/jzshe/project/quest')

import os
from quest.sql.parser import sqlparser
from quest.utils.class2json import ClassToJson
from quest.sql.planner.baselogical import BaseLogicalPlanner
from quest.sql.planner.physical import TextPhysicalPlanner
from quest.sql.processer.processer import Processer
from quest.db.indexer.indexer import GlobalIndexer, load_all_indexer
from quest.core.llm.sampler import AttrSampler
from quest.core.llm.llm_query import TextLLMQuerier, LLMInfo
from quest.utils.log import print_log
from quest.conf.settings import RELATIVE_PROJECT_ROOT_PATH
from quest.db.indexer.indexer import GlobalIndexer, build_all_indexer

wiki_art_docs_dir = "/data/QUEST/benchmark/small_datasets/Wiki_Text"

def run(sql, prompt):
    print(sql)

    # build AST
    ast = sqlparser.parse_sql(sql)
    jsonConverter = ClassToJson()
    js = jsonConverter.toJson(ast)
    print("AST:\n", js)

    # build logical plan

    logicalPlanner = BaseLogicalPlanner()
    logical = logicalPlanner.build_logical_plan(ast)
    js = jsonConverter.toJson(logical)
    print_log("Logical Plan:\n",js)

    # indexer and sampler

    # gb_indexer = build_all_indexer(
    #     doc_dirs=[wiki_art_docs_dir],
    #     tables_name=["wikiart"],
    #     types=["TextDoc"],
    #     debug_flag= True
    # )

    gb_indexer = load_all_indexer(table_to_type = {"wikiart" : "TextDoc"})
    
    gb_sampler = AttrSampler(schema = prompt)
    gb_querier = TextLLMQuerier(prompt=prompt)

    gb_sampler.try_sample(gb_indexer.get_indexer("wikiart")[0], prompt)
    sample_table = gb_sampler.sample_table
    # 存到log/test_sample_table.csv里 RELATIVE_PROJECT_ROOT_PATH
    #sample_table.to_csv(os.path.join(RELATIVE_PROJECT_ROOT_PATH, "quest/tests/log/test_sample_table.csv"))
    #attr_2_evidence = gb_sampler.map_attr_evidence
    #print_log(attr_2_evidence)

    # build physical plan

    physicalPlanner = TextPhysicalPlanner(gb_indexer, gb_querier, sampler=gb_sampler)
    physical = physicalPlanner.build(logical)
    #js = jsonConverter.toJson(physical)
    #print_log("Physical Plan:\n",js)

    # process

    processer = Processer()
    result = processer.process(physical)
    print_log("Result Table:\n", result)

    # LLM latency
    print("query_times : ", LLMInfo.tot_query_times)
    print("input_tokens : ", LLMInfo.tot_input_tokens)
    print("output_tokens : ", LLMInfo.tot_output_tokens)


    # 存到log/x.csv里 RELATIVE_PROJECT_ROOT_PATH
    result.to_csv(os.path.join(RELATIVE_PROJECT_ROOT_PATH, "quest/tests/log/Wiki_Text/SF11.csv"))

    return result

if __name__ == "__main__":
    sql = "SELECT art_movement, century, zodiac, birth_city, birth_continent, death_city FROM wikiart"
    prompt = \
    """
    art_movement: art movement contributed to (e.g., impressionism). \n \
    century: century when the artist was active or influential (e.g., 19th or 19th–20th; can span multiple centuries). \n \
    zodiac: western zodiac sign based on birth date, choose one form [Aries, Taurus, Gemini, Cancer, Leo, Virgo, Libra, Scorpio, Sagittarius, Capricorn, Aquarius, Pisces], seperated by `||` (e.g. Aries).\n \
    birth_city: city where the artist was born.\n \
    birth_continent: continent where the artist was born (e.g., europe, asia).\n \
    death_city: city where the artist died, or leave empty if not applicable.\n
    """
    
    run(sql, prompt)