#!/usr/bin/env python3
"""
测试test_chunker的程序
使用"/data/QUEST/jzshe/project/quest/data/dataset/NBAPlayer/docs"中的5个随机文档进行测试
"""

import sys
import os

# 添加项目根目录到Python路径
sys.path.append('/data/QUEST/jzshe/project/quest')

import tiktoken

from quest.db.indexer.indexer import USED_EMBEDDING_MODEL
tokenizer = tiktoken.encoding_for_model("gpt-3.5-turbo")
def count_tokens(text, tokenizer):
    return len(tokenizer.encode(text))




from quest.core.chunker.chunker import TokenTextChunker, RecursiveTokenTextChunker, GrammarSemanticChunker, SentenceTransformerTokenTextChunker
from quest.core.embedding.e5Embedding import batchedE5Embeddings
from quest.core.datapack.doc import Doc


import os
import random

def load_test_documents():
    """随机加载5个txt文档"""
    docs = []
    base_path = "/data/QUEST/jzshe/project/quest/data/dataset/NBAPlayer/docs"
    try:
        all_files = [f for f in os.listdir(base_path)]
        if len(all_files) < 5:
            print("✗ 文件数量不足5个，实际数量:", len(all_files))
            return docs
        selected_files = random.sample(all_files, 10)
    except Exception as e:
        print(f"✗ 列出文件时出错: {e}")
        return docs

    for fname in selected_files:
        file_path = os.path.join(base_path, fname)
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read().strip()
                # 用文件名去掉后缀作为doc_id（或自定义逻辑）
                doc_id = os.path.splitext(fname)[0]
                doc = Doc(content=content, doc_id=doc_id)
                docs.append(doc)
                print(f"✓ 成功加载文档 {fname} (长度: {count_tokens(content, tokenizer)} token)")
        except Exception as e:
            print(f"✗ 加载文档 {fname} 时出错: {e}")

    return docs



def test_grammar_semantic_chunker():
    """测试test_chunker"""
    print("=" * 60)
    print("test_chunker 测试程序")
    print("=" * 60)

    # 1. 初始化embedding模型
    print("\n1. 初始化embedding模型...")
    try:
        embedding_model = batchedE5Embeddings()
        print(f"✓ 成功初始化E5 embedding模型 (维度: {embedding_model.emb_size})")
    except Exception as e:
        print(f"✗ 初始化embedding模型失败: {e}")
        return

    # 2. 初始化test_chunker
    print("\n2. 初始化test_chunker...")
    try:
        chunker =  GrammarSemanticChunker(USED_EMBEDDING_MODEL, min_chunk_size=128, max_chunk_size=512)
        # chunker = TokenTextChunker(chunk_size=512, chunk_overlap=128)
        print("✓ 成功初始化test_chunker")
    except Exception as e:
        print(f"✗ 初始化test_chunker失败: {e}")
        return

    # 3. 加载测试文档
    print("\n3. 加载测试文档...")
    docs = load_test_documents()
    if not docs:
        print("✗ 没有成功加载任何文档")
        return

    # 4. 对每个文档进行分块测试
    print("\n4. 开始分块测试...")
    print("-" * 60)

    total_chunks = 0
    total_tokens = 0
    chunk_lengths = []

    for doc in docs:
        print(f"\n📄 文档 {doc.doc_id}.txt:")
        print(f"   原文长度: {count_tokens(doc.content, tokenizer)} token")
        total_tokens += count_tokens(doc.content, tokenizer)

        try:
            # 进行分块
            chunks = chunker.split_text(doc.content)
            chunk_count = len(chunks)
            total_chunks += chunk_count

            print(f"   分块数量: {chunk_count}")
            print(f"   各分块长度:")

            doc_chunk_lengths = []
            for i, chunk in enumerate(chunks, 1):
                chunk_length = count_tokens(chunk, tokenizer)
                chunk_lengths.append(chunk_length)
                doc_chunk_lengths.append(chunk_length)

                # 显示每个分块的长度和前50个char作为预览
                preview = chunk[:50].replace('\n', ' ').replace('\r', ' ')
                if count_tokens(chunk, tokenizer) > 50:
                    preview += "..."
                print(f"     分块 {i}: {chunk_length} token - \"{preview}\"")

            # 显示该文档的分块统计
            if doc_chunk_lengths:
                avg_length = sum(doc_chunk_lengths) / len(doc_chunk_lengths)
                min_length = min(doc_chunk_lengths)
                max_length = max(doc_chunk_lengths)
                print(f"   分块长度统计: 平均 {avg_length:.0f}, 最小 {min_length}, 最大 {max_length}")

        except Exception as e:
            print(f"   ✗ 分块失败: {e}")
            continue

    # 5. 总结
    print("\n" + "=" * 60)
    print("测试总结:")
    print(f"  测试文档数量: {len(docs)}")
    print(f"  总token数: {total_tokens:,}")
    print(f"  总分块数量: {total_chunks}")
    print(f"  平均每文档分块数: {total_chunks/len(docs):.1f}")

    if chunk_lengths:
        avg_chunk_length = sum(chunk_lengths) / len(chunk_lengths)
        min_chunk_length = min(chunk_lengths)
        max_chunk_length = max(chunk_lengths)
        print(f"  分块长度统计:")
        print(f"    平均长度: {avg_chunk_length:.0f} token")
        print(f"    最小长度: {min_chunk_length} token")
        print(f"    最大长度: {max_chunk_length} token")
        print(f"    压缩比: {(total_tokens/total_chunks):.0f} token/分块")

    print("=" * 60)


if __name__ == "__main__":
    test_grammar_semantic_chunker()