import sys
# sys.path.append('/home/lijianhui/workspace/quest')
sys.path.append('/data/QUEST/jzshe/project/quest')

# 假设你已经配置好 litellm 支持的 embedding 模型
from quest.conf.settings import GPT_API_BASE, GPT_API_KEY
from quest.core.embedding.apiEmbedding import ApiEmbeddings
from quest.core.embedding.e5Embedding import batchedBGEEmbeddings


API_EMB_MODEL = "openai/Qwen/Qwen3-Embedding-0.6B"
API_EMB_API_BASE =  "https://aihubmix.com/v1" 
API_EMB_API_KEY = "sk-DrStrjrlXohoCI2iBc14Eb41A38c428b88A0973aA29fCc3b"

# emb = ApiEmbeddings(model=API_EMB_MODEL, api_key=API_EMB_API_KEY,  api_base = API_EMB_API_BASE)
emb = batchedBGEEmbeddings()

vec = emb.embed_query("hello world")
vecs = emb.embed_documents(["hello", "world"])
print("嵌入列表向量的维度：", vecs.shape)
print("嵌入单个向量的维度：", vec.shape)
# print(emb.emb_size)  # 向量维度
