import sys
sys.path.append('/home/lijianhui/workspace/quest')
#sys.path.append('/data/QUEST/jzshe/project/quest')

import os
from quest.sql.parser import sqlparser
from quest.utils.class2json import ClassToJson
from quest.sql.planner.semlogical import SemanticLogicalPlanner
from quest.sql.planner.baselogical import BaseLogicalPlanner
from quest.sql.planner.physical import TextPhysicalPlanner
from quest.sql.processer.processer import Processer
from quest.db.indexer.indexer import GlobalIndexer, load_all_indexer
from quest.core.llm.sampler import AttrSampler
from quest.core.llm.llm_query import TextLLMQuerier, LLMInfo
from quest.utils.log import print_log
from quest.conf.settings import RELATIVE_PROJECT_ROOT_PATH
from quest.db.indexer.indexer import GlobalIndexer, build_all_indexer
from quest.sql.optimizer.optimizer_filter import OptimizerFilter

nba_player_docs_dir = "/data/QUEST/benchmark/datasets/player"

def run(sql, prompt):
    print(sql)

    # build AST
    ast = sqlparser.parse_sql(sql)
    jsonConverter = ClassToJson()
    js = jsonConverter.toJson(ast)
    print("AST:\n", js)

    # build logical plan

    logicalPlanner = BaseLogicalPlanner()
    logical = logicalPlanner.build_logical_plan(ast)
    js = jsonConverter.toJson(logical)
    print_log("Logical Plan:\n",js)

    # indexer and sampler

    # gb_indexer = build_all_indexer(
    #     doc_dirs=[nba_player_docs_dir],
    #     tables_name=["player"],
    #     types=["TextDoc"],
    #     debug_flag= False
    # )

    gb_indexer = load_all_indexer(table_to_type = {"player" : "TextDoc", "playersen" : "TextDoc"})
    
    gb_sampler = AttrSampler(schema = prompt)
    gb_querier = TextLLMQuerier(prompt=prompt)

    print("sample now! - - - - - ")

    gb_sampler.try_sample(gb_indexer.get_indexer("player")[0], prompt)

    print("optimize now! - - - - -")

    optimizer = OptimizerFilter(indexer = gb_indexer, querier = gb_querier, sampler = gb_sampler, batch_size=30)
    opt = optimizer.build(logical)

    print("physical now! - - - - -")

    physicalPlanner = TextPhysicalPlanner(gb_indexer, gb_querier, sampler=gb_sampler)
    physical = physicalPlanner.build(opt)
    #js = jsonConverter.toJson(physical)
    #print_log("Physical Plan:\n",js)

    # process

    processer = Processer()
    result = processer.process(physical)
    print_log("Result Table:\n", result)

    # LLM latency
    print("query_times : ", LLMInfo.tot_query_times)
    print("input_tokens : ", LLMInfo.tot_input_tokens)
    print("output_tokens : ", LLMInfo.tot_output_tokens)


    # 存到log/x.csv里 RELATIVE_PROJECT_ROOT_PATH
    result.to_csv(os.path.join(RELATIVE_PROJECT_ROOT_PATH, "../experiment_result/sfwga/player/none/SFWGA3.csv"))

    return result

if __name__ == "__main__":

    sql = "SELECT team, COUNT(olympic_gold_medals) FROM player WHERE ((((fiba_world_cup==0 OR mvp_awards==4) OR draft_year<=1979) AND college=='Wake Forest University') OR age>=25) GROUP BY team"

    prompt = \
    """
    team: the current NBA team the player belongs to, or the last NBA team the player joined if not currently active (e.g., Los Angeles Lakers). \n \
    college:  the college the player attended, if applicable (e.g., Duke University).\n \
    age: age of the player (if death_date is given, compute as death_date - birth_date; otherwise, compute as 2025/1/1 - birth_date).\n \
    draft_year: the year the player was selected in the NBA draft; use format YYYY (e.g., 2003). \n \
    olympic_gold_medals: number of Olympic gold medals the player has won (e.g., 3).\n \
    fiba_world_cup:  number of FIBA World Cup titles the player has won (e.g., 1).\n \
    mvp_awards: number of NBA MVP awards the player has won; use 0 if none (e.g., 2).\n
    """
    
    run(sql, prompt)