import sys
sys.path.append('/home/lijianhui/workspace/quest')
#sys.path.append('/data/QUEST/jzshe/project/quest')

import os
from quest.sql.parser import sqlparser
from quest.utils.class2json import ClassToJson
from quest.sql.planner.semlogical import SemanticLogicalPlanner
from quest.sql.planner.physical import TextPhysicalPlanner
from quest.sql.processer.processer import Processer
from quest.db.indexer.indexer import GlobalIndexer, load_all_indexer
from quest.core.llm.sampler import AttrSampler
from quest.core.llm.llm_query import TextLLMQuerier, LLMInfo
from quest.utils.log import print_log
from quest.conf.settings import RELATIVE_PROJECT_ROOT_PATH
from quest.db.indexer.indexer import GlobalIndexer, build_all_indexer
from quest.sql.optimizer.optimizer_filter import OptimizerFilter

nba_player_docs_dir = "/data/QUEST/benchmark/datasets/player"

def run(sql, prompt):
    print(sql)

    # build AST
    ast = sqlparser.parse_sql(sql)
    jsonConverter = ClassToJson()
    js = jsonConverter.toJson(ast)
    print("AST:\n", js)

    # build logical plan

    logicalPlanner = SemanticLogicalPlanner(7)
    logical = logicalPlanner.build_logical_plan(ast)
    js = jsonConverter.toJson(logical)
    print_log("Logical Plan:\n",js)

    # indexer and sampler

    gb_indexer = build_all_indexer(
        doc_dirs=[nba_player_docs_dir],
        tables_name=["playersen"],
        types=["TextDoc"],
        debug_flag= False
    )


if __name__ == "__main__":

    sql = "SELECT marriage, AVG(age) FROM wikiart GROUP BY marriage"

    prompt = \
    """
    marriage: marital status of the artist, reflecting the artist's latest (final) marital status as mentioned in the biography. Choose one from [Cohabiting, Divorced, Married, Remarried, Separated, Unmarried, Widowed]. Only extract and fill in the last marital status referenced in the text. \n \
    age: age of the artist (if death_date is given, compute as death_date - birth_date; otherwise, compute as 2025/1/1 - birth_date). \n \
    """
    
    run(sql, prompt)