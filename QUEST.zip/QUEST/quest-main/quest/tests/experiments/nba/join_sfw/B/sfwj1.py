import sys
sys.path.append('/home/lijianhui/workspace/quest')
#sys.path.append('/data/QUEST/jzshe/project/quest')

import os
from quest.sql.parser import sqlparser
from quest.utils.class2json import ClassToJson
from quest.sql.planner.joinlogical import JoinLogicalPlanner
from quest.sql.planner.joinphysical import JoinPhysicalPlanner
from quest.sql.processer.processer import Processer
from quest.db.indexer.indexer import GlobalIndexer, load_all_indexer
from quest.core.llm.sampler import AttrSampler
from quest.core.llm.llm_query import TextLLMQuerier, LLMInfo
from quest.utils.log import print_log
from quest.conf.settings import RELATIVE_PROJECT_ROOT_PATH
from quest.db.indexer.indexer import GlobalIndexer, build_all_indexer
from quest.sql.optimizer.optimizer_filter import OptimizerFilter
from quest.sql.optimizer.optimizer_join import OptimizerJoin

nba_player_docs_dir = "/data/QUEST/benchmark/datasets/player"
city_docs_dir = "/data/QUEST/benchmark/datasets/city"
team_docs_dir = "/data/QUEST/benchmark/datasets/team"
owner_docs_dir = "/data/QUEST/benchmark/datasets/owner"


def run(sql, prompt):
    print(sql)

    # build AST
    ast = sqlparser.parse_sql(sql)
    jsonConverter = ClassToJson()
    js = jsonConverter.toJson(ast)
    print("AST:\n", js)

    # build logical plan

    logicalPlanner = JoinLogicalPlanner()
    logical = logicalPlanner.build_logical_plan(ast)
    js = jsonConverter.toJson(logical)
    print_log("Logical Plan:\n",js)

    # indexer and sampler

    # gb_indexer = build_all_indexer(
    #     doc_dirs=[nba_player_docs_dir],
    #     tables_name=["player"],
    #     types=["TextDoc"],
    #     debug_flag= False
    # )

    gb_indexer = load_all_indexer(table_to_type = {"city" : "TextDoc", "team" : "TextDoc"})
    
    gb_sampler = AttrSampler(schema = prompt)
    gb_querier = TextLLMQuerier(prompt=prompt)

    print("sample now! - - - - - ")

    gb_sampler.try_sample(gb_indexer.get_indexer("city")[0], prompt)
    gb_sampler.try_sample(gb_indexer.get_indexer("team")[0], prompt)

    #print("optimize now! - - - - -")

    optimizer = OptimizerFilter(indexer = gb_indexer, querier = gb_querier, sampler = gb_sampler, batch_size=30)
    opt = optimizer.build(logical)

    #optimizer_join = OptimizerJoin(indexer=gb_indexer, querier=gb_querier, sampler=gb_sampler, batch_size=30)
    #opt2 = optimizer_join.build(opt)

    print("physical now! - - - - -")

    physicalPlanner = JoinPhysicalPlanner(gb_indexer, gb_querier, sampler=gb_sampler)
    physical = physicalPlanner.build(logical)
    #js = jsonConverter.toJson(physical)
    #print_log("Physical Plan:\n",js)

    # process

    processer = Processer()
    result = processer.process(physical)
    print_log("Result Table:\n", result)

    # LLM latency
    print("query_times : ", LLMInfo.tot_query_times)
    print("input_tokens : ", LLMInfo.tot_input_tokens)
    print("output_tokens : ", LLMInfo.tot_output_tokens)


    # 存到log/x.csv里 RELATIVE_PROJECT_ROOT_PATH
    result.to_csv(os.path.join(RELATIVE_PROJECT_ROOT_PATH, "../experiment_result/join_optimize/nba/B/SFWJ1.csv"))

    return result

if __name__ == "__main__":

    sql = "SELECT city.population, team.ownership, team.location, city.city_name FROM team, city WHERE team.championship>5 AND team.location == city.city_name"

    prompt = \
    """
    city.population: population is the population of the city, a number (e.g., 1000000). \n \
    team.ownership:  ownership is the name of the team's onwer (e.g., John Doe). \n \
    team.championship: championship is the number of championships won by the team, a number (e.g., 10). \n \
    team.location: location is the name of the city where the team is based (e.g., Los Angeles). \n \
    city.city_name: city_name is the name of the city (e.g., Los Angeles). \n \
    """
    
    run(sql, prompt)