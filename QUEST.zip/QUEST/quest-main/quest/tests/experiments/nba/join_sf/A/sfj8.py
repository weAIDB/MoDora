import sys
sys.path.append('/home/lijianhui/workspace/quest')
#sys.path.append('/data/QUEST/jzshe/project/quest')

import os
from quest.sql.parser import sqlparser
from quest.utils.class2json import ClassToJson
from quest.sql.planner.baselogical import BaseLogicalPlanner
from quest.sql.planner.physical import TextPhysicalPlanner
from quest.sql.processer.processer import Processer
from quest.db.indexer.indexer import GlobalIndexer, load_all_indexer
from quest.core.llm.sampler import AttrSampler
from quest.core.llm.llm_query import TextLLMQuerier, LLMInfo
from quest.utils.log import print_log
from quest.conf.settings import RELATIVE_PROJECT_ROOT_PATH
from quest.db.indexer.indexer import GlobalIndexer, build_all_indexer
from quest.sql.optimizer.optimizer_filter import OptimizerFilter

nba_player_docs_dir = "/data/QUEST/benchmark/datasets/player"
city_docs_dir = "/data/QUEST/benchmark/datasets/city"
team_docs_dir = "/data/QUEST/benchmark/datasets/team"
owner_docs_dir = "/data/QUEST/benchmark/datasets/owner"


def run(sql, prompt):
    print(sql)

    # build AST
    ast = sqlparser.parse_sql(sql)
    jsonConverter = ClassToJson()
    js = jsonConverter.toJson(ast)
    print("AST:\n", js)

    # build logical plan

    logicalPlanner = BaseLogicalPlanner()
    logical = logicalPlanner.build_logical_plan(ast)
    js = jsonConverter.toJson(logical)
    print_log("Logical Plan:\n",js)

    # indexer and sampler

    # gb_indexer = build_all_indexer(
    #     doc_dirs=[nba_player_docs_dir],
    #     tables_name=["player"],
    #     types=["TextDoc"],
    #     debug_flag= False
    # )

    gb_indexer = load_all_indexer(table_to_type = {"team" : "TextDoc", "owner" : "TextDoc", "city" : "TextDoc"})
    
    gb_sampler = AttrSampler(schema = prompt)
    gb_querier = TextLLMQuerier(prompt=prompt)

    print("sample now! - - - - - ")

    gb_sampler.try_sample(gb_indexer.get_indexer("owner")[0], prompt)
    gb_sampler.try_sample(gb_indexer.get_indexer("team")[0], prompt)
    gb_sampler.try_sample(gb_indexer.get_indexer("city")[0], prompt)

    #print("optimize now! - - - - -")

    #optimizer = OptimizerFilter(indexer = gb_indexer, querier = gb_querier, sampler = gb_sampler, batch_size=30)
    #opt = optimizer.build(logical)

    print("physical now! - - - - -")

    physicalPlanner = TextPhysicalPlanner(gb_indexer, gb_querier, sampler=gb_sampler)
    physical = physicalPlanner.build(logical)
    #js = jsonConverter.toJson(physical)
    #print_log("Physical Plan:\n",js)

    # process

    processer = Processer()
    result = processer.process(physical)
    print_log("Result Table:\n", result)

    # LLM latency
    print("query_times : ", LLMInfo.tot_query_times)
    print("input_tokens : ", LLMInfo.tot_input_tokens)
    print("output_tokens : ", LLMInfo.tot_output_tokens)


    # 存到log/x.csv里 RELATIVE_PROJECT_ROOT_PATH
    result.to_csv(os.path.join(RELATIVE_PROJECT_ROOT_PATH, "../experiment_result/join_optimize/nba/A/SFJ8.csv"))

    return result

if __name__ == "__main__":

    sql = "SELECT owner.age, city.state_name, team.team_name FROM team, city, owner WHERE team.location == city.city_name AND team.team_name == owner.nba_team"

    prompt = \
    """
    owner.age: the age of the current team owner (e.g., 46), if not given the number, compute as (2025/1/1 - birth_date) (e.g. birth at 1946, then age is 2025-1946 = 79) . \n \
    city.state_name: state_name is the name of the state the city is located in (e.g., California). \n \
    city.city_name: the full name of the city. \n \
    owner.nba_team: the full name of the team that the person owned. (e.g. Los Angeles Lakers). \n  \
    team.location: location is the name of the city where the team is based (e.g., Los Angeles). \n \
    team.team_name: team_name is the full name of the team. (e.g. Los Angeles Lakers).\n 
    """
    
    run(sql, prompt)