import sys
sys.path.append('/home/lijianhui/workspace/quest')
#sys.path.append('/data/QUEST/jzshe/project/quest')

import os
from quest.sql.parser import sqlparser
from quest.utils.class2json import ClassToJson
from quest.sql.planner.baselogical import BaseLogicalPlanner
from quest.sql.planner.physical import TextPhysicalPlanner
from quest.sql.processer.processer import Processer
from quest.db.indexer.indexer import GlobalIndexer, load_all_indexer
from quest.core.llm.sampler import AttrSampler
from quest.core.llm.llm_query import TextLLMQuerier, LLMInfo
from quest.utils.log import print_log
from quest.conf.settings import RELATIVE_PROJECT_ROOT_PATH
from quest.db.indexer.indexer import GlobalIndexer, build_all_indexer
from quest.sql.optimizer.optimizer_filter import OptimizerFilter

nba_player_docs_dir = "/data/QUEST/benchmark/datasets/player"
city_docs_dir = "/data/QUEST/benchmark/datasets/city"
team_docs_dir = "/data/QUEST/benchmark/datasets/team"
owner_docs_dir = "/data/QUEST/benchmark/datasets/owner"


def run(sql, prompt):
    print(sql)

    # build AST
    ast = sqlparser.parse_sql(sql)
    jsonConverter = ClassToJson()
    js = jsonConverter.toJson(ast)
    print("AST:\n", js)

    # build logical plan

    logicalPlanner = BaseLogicalPlanner()
    logical = logicalPlanner.build_logical_plan(ast)
    js = jsonConverter.toJson(logical)
    print_log("Logical Plan:\n",js)

    # indexer and sampler

    # gb_indexer = build_all_indexer(
    #     doc_dirs=[nba_player_docs_dir],
    #     tables_name=["player"],
    #     types=["TextDoc"],
    #     debug_flag= False
    # )

    gb_indexer = load_all_indexer(table_to_type = {"team" : "TextDoc", "owner" : "TextDoc", "player" : "TextDoc"})
    
    gb_sampler = AttrSampler(schema = prompt)
    gb_querier = TextLLMQuerier(prompt=prompt)

    print("sample now! - - - - - ")

    gb_sampler.try_sample(gb_indexer.get_indexer("owner")[0], prompt)
    gb_sampler.try_sample(gb_indexer.get_indexer("team")[0], prompt)
    gb_sampler.try_sample(gb_indexer.get_indexer("player")[0], prompt)

    #print("optimize now! - - - - -")

    #optimizer = OptimizerFilter(indexer = gb_indexer, querier = gb_querier, sampler = gb_sampler, batch_size=30)
    #opt = optimizer.build(logical)

    print("physical now! - - - - -")

    physicalPlanner = TextPhysicalPlanner(gb_indexer, gb_querier, sampler=gb_sampler)
    physical = physicalPlanner.build(logical)
    #js = jsonConverter.toJson(physical)
    #print_log("Physical Plan:\n",js)

    # process

    processer = Processer()
    result = processer.process(physical)
    print_log("Result Table:\n", result)

    # LLM latency
    print("query_times : ", LLMInfo.tot_query_times)
    print("input_tokens : ", LLMInfo.tot_input_tokens)
    print("output_tokens : ", LLMInfo.tot_output_tokens)


    # 存到log/x.csv里 RELATIVE_PROJECT_ROOT_PATH
    result.to_csv(os.path.join(RELATIVE_PROJECT_ROOT_PATH, "../experiment_result/join_optimize/nba/A/SFJ10.csv"))

    return result

if __name__ == "__main__":

    sql = "SELECT team.ownership, owner.nationality, team.location, player.nationality FROM team, player, owner WHERE player.team == team.team_name AND owner.nba_team == team.team_name"

    prompt = \
    """
    player.team: the current nba team the player belongs to, or the last nba team the player joined if not currently active (e.g., Los Angeles Lakers). \n \
    player.nationality: nationality of the player (e.g., USA, France). \n \
    owner.nba_team: the full name of the team that the person owned. (e.g. Los Angeles Lakers). \n  \
    owner.nationality: nationality of the person (e.g., France). \n \
    team.location: location is the name of the city where the team is based (e.g., Los Angeles). \n \
    team.team_name: team_name is the full name of the team. (e.g. Los Angeles Lakers).\n \
    team.ownership: ownership is the name of the team's onwer (e.g., Joseph Tsai). \n 
    """
    
    run(sql, prompt)