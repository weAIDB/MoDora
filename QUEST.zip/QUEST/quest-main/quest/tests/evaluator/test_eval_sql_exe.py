
import sys
import pandas as pd
sys.path.append('/data/QUEST/jzshe/project/quest')
from quest.core.evaluator.evaluator import DeprecatedFuncExtractionEvaluator


sql = "SELECT birth_continent, COUNT(name) FROM wikiart GROUP BY birth_continent"

order_num = 4
# 4 SELECT birth_continent, COUNT(name) FROM wikiart GROUP BY birth_continent
# 3 SELECT century, MAX(age) FROM wikiart GROUP BY century
# 2 "SELECT zodiac, MAX(age) FROM wikiart GROUP BY zodiac"

# 1 "SELECT marriage, AVG(age) FROM wikiart GROUP BY marriage"

gt_table_path = "/data/QUEST/jzshe/project/quest/data/benchmark/ground_truth/Wiki_Text.csv"
gt_df = pd.read_csv(gt_table_path)  # encoding='utf-8'

evaluator = DeprecatedFuncExtractionEvaluator()
gt_df = evaluator.clean_table(gt_df, primary_keys=[])
result_gt = evaluator.execute_sql_on_gt(sql,  gt_table = gt_df) 
result_gt.to_csv(f"/data/QUEST/jzshe/project/quest/log/aggregationDuckDB/result_gt{order_num}.csv", index=False)
# 对于group by语句，primary_keys留空，由解析器自动从SQL语句中识别

