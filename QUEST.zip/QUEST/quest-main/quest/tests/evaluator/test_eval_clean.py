
import sys
import pandas as pd
sys.path.append('/data/QUEST/jzshe/project/quest')
from quest.core.evaluator.evaluator import DeprecatedFuncExtractionEvaluator


if __name__ == "__main__":
    test_data = {
        "id": [1, 2, 3],
        "name": ["  Alice  ", "Bob\tSmith", "  Carol  ||  Dave  "],
        "desc": ["foo   bar", "   hello\tworld  ", None],
        "multi": ["a  ||  b", "  c||d  ", ""],
        "num": [100, 200, 300]
    }
    df = pd.DataFrame(test_data)
    print("原始数据：")
    print(df)

    evaluator = DeprecatedFuncExtractionEvaluator()
    # 假设主键是id和name
    cleaned_df = evaluator.clean_table(df.copy(), primary_keys=["id", "name"])
    print("\n清洗后数据：")
    print(cleaned_df)