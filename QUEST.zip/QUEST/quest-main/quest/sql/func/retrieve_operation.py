import pandas as pd
from quest.db.indexer.single_indexer import SingleIndexer
from quest.sql.nn.retrieve_text import RetrieveText
from quest.core.llm.sampler import AttrSampler

class RetrieveOperation:
    def __init__(self):
        pass
    
    @staticmethod
    def retrieve_text(table_name: str, column_names: list[str], indexer: SingleIndexer, sampler: AttrSampler) -> pd.DataFrame:
        """
        Retrieve data from the specified table based on column names
        using retrieve_text NN
        """
        node = RetrieveText(column_names, table_name, 'Text')
        node.set_indexer(indexer)
        node.set_sampler(sampler)
        node.set_retrieveList(indexer.get_docs_id())
        node.process()
        return node.output

        