import pandas as pd
from quest.db.indexer.single_indexer import SingleIndexer
from quest.sql.nn.base import Base
from quest.sql.nn.extract_text import ExtractText
from quest.core.llm.llm_query import TextLLMQuerier

class ExtractOperation:
    def __init__(self):
        pass
    
    @staticmethod
    def extract_text(table_name: str, column_names: list[str], input: list, querier: TextLLMQuerier) -> pd.DataFrame:
        """
        Extract data from the specified table based on column names
        using extract_text NN
        """
        pre = Base()
        pre.set_output(input)
        node = ExtractText(column_names, table_name, 'Text')
        node.set_input([pre])
        node.set_querier(querier)
        node.process()
        return node.output
        