import pandas as pd
from quest.db.indexer.single_indexer import SingleIndexer
from quest.sql.nn.base import Base
from quest.sql.nn.projection_text import ProjectionText
from quest.core.llm.llm_query import TextLLMQuerier

class ProjectionOperation:
    def __init__(self):
        pass
    
    @staticmethod
    def projection_text(table_name: str, column_names: list[str], input: list, indexer: SingleIndexer) -> pd.DataFrame:
        """
        projection data from the specified table based on column names
        using projection_text NN
        """
        pre = Base()
        pre.set_output(input)
        node = ProjectionText(column_names,'Text')
        node.set_indexer(indexer)
        node.set_input([pre])
        node.process()
        return node.output
        