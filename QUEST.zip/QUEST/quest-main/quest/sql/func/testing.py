import sys
sys.path.append('/home/lijianhui/workspace/quest')

import pandas as pd
from quest.sql.func.func import FuncObject
from quest.db.indexer.indexer import load_all_indexer, build_all_indexer
from quest.utils.log import print_log
from quest.conf.settings import RELATIVE_PROJECT_ROOT_PATH

def retrieve_text(table_name: str, column_names: list[str], prompt: str) -> list:
    gb_indexer = load_all_indexer(table_to_type = {table_name : "TextDoc"})
    fo = FuncObject() 
    fo.add_global_source(gb_indexer) # gobal one
    fo.add_source(gb_indexer.get_indexer(table_name)[0], table_name, table_name)
    fo.add_descriptions(table_name, prompt)
    
    fo.retrieve_text(table_name, column_names)
    
    result = fo.show_text(table_name)
    return result

def extract_text(table_name: str, column_names: list[str], prompt: str) -> pd.DataFrame:
    gb_indexer = load_all_indexer(table_to_type = {table_name : "TextDoc"})
    fo = FuncObject() 
    fo.add_global_source(gb_indexer) # gobal one
    fo.add_source(gb_indexer.get_indexer(table_name)[0], table_name, table_name)
    fo.add_descriptions(table_name, prompt)
    
    fo.retrieve_text(table_name, column_names)
    fo.extract_text(table_name, column_names)
    fo.projection_text(table_name, column_names)

    result = fo.show_table(table_name)
    return result

def filter_text(table_name: str, column_names: list[str], filter_condition: str, prompt: str) -> pd.DataFrame:
    gb_indexer = load_all_indexer(table_to_type = {table_name : "TextDoc"})
    fo = FuncObject() 
    fo.add_global_source(gb_indexer) # gobal one
    fo.add_source(gb_indexer.get_indexer(table_name)[0], table_name, table_name)
    fo.add_descriptions(table_name, prompt)
    
    fo.retrieve_text(table_name, column_names)
    fo.filter_text(table_name, column_names, filter_condition)
    fo.extract_text(table_name, column_names)
    fo.projection_text(table_name, column_names)

    result = fo.show_table(table_name)
    return result