from quest.core.node.logical_node import FilterNode
from quest.sql.parser import sqlparser
from quest.utils.class2json import ClassToJson
from quest.sql.planner.baselogical import BaseLogicalPlanner


def convert_conditions_to_filter_node(table_name: str, filter_conditions: str) -> FilterNode:
    """
    Convert filter conditions string to a FilterNode.
    This function should parse the filter_conditions and create a FilterNode accordingly.
    use the parse logic from the SQL parser if available.
    """
    # Placeholder for actual implementation
    # This should parse the filter_conditions and return a FilterNode
    # For now, we return an empty FilterNode
    sql = f'SELECT * FROM table WHERE {filter_conditions}'

    ast = sqlparser.parse_sql(sql)
    jsonConverter = ClassToJson()
    js = jsonConverter.toJson(ast)
    print("AST:\n", js)


    logicalPlanner = BaseLogicalPlanner()
    root = logicalPlanner.get_logical_condition(table_name, ast)

    return root