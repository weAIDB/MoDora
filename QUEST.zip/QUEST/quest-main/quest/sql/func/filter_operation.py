import pandas as pd
from quest.db.indexer.single_indexer import SingleIndexer
from quest.sql.nn.filter_text import FilterText
from quest.sql.nn.base import Base
from quest.core.node.logical_node import BinaryNode, FilterNode
from quest.core.llm.llm_query import TextLLMQuerier

class FilterOperation:
    def __init__(self):
        pass
    
    @staticmethod
    def filter_text(table_name: str, column_names: list[str], root: FilterNode, input: list, querier: TextLLMQuerier) -> pd.DataFrame:
        """
        Filter data from the specified table based on column names
        using extract_text NN
        """
        # node : FilterNode
        pre = Base()
        pre.set_output(input)
        node = FilterText(column_names, table_name, 'Text', root)
        node.set_input([pre])
        node.set_querier(querier)
        node.process()
        return node.output
        