from __future__ import annotations
import pandas as pd
from quest.core.datapack import *
from quest.db.indexer.single_indexer import SingleIndexer
from quest.db.indexer.indexer import GlobalIndexer
from quest.sql.func import *
from quest.sql.func.pack_storage import PackStorage
from quest.core.llm.sampler import AttrSampler
from quest.core.llm.llm_query import TextLLMQuerier
from quest.utils.class2json import ClassToJson

class FuncObject(object): 
    """
    indexerDict : {indexer_name: SingleIndexer}
    sourceListDict : {table_name: list[indexer_name]}
    """
    def __init__(
        self
    ) -> None:
        self.data = None
        self.indexerDict = {}
        self.sourceListDict = {}
        self.descriptions = {}
        self.full_description = ""
        self.packStorage = PackStorage()
        self.sampler = AttrSampler()
        self.querier = TextLLMQuerier()

    def parse_output(self, table_name: str, outputs: list) -> None:
        """
        parse the output of the operation
        """
        if not isinstance(outputs, list):
            raise ValueError("Outputs must be a list.")
        
        text_list = []
        for output in outputs:
            if isinstance(output, DocListPack):
                self.packStorage.update_doc_list_pack(table_name, output)
            elif isinstance(output, TablePack):
                self.packStorage.update_table_pack(table_name, output)
            elif isinstance(output, BaseTextPack):
                text_list.append(output)
            else:
                raise TypeError(f"Unsupported output type: {type(output)}")
        if text_list:
            self.packStorage.update_text_pack(table_name, text_list)

    def extract_attr_descriptions_from_schema(self, attr_schema: str):
        attr_descriptions = {}
        lines = attr_schema.strip().split('\n')
        for line in lines:
            line = line.strip()
            if ':' in line:
                attr_name = line.split(':')[0].strip()
                attr_description = line.split(':')[1].strip()
                if attr_name and attr_description:
                    attr_descriptions[attr_name.lower()] = attr_description
        return attr_descriptions

    def add_descriptions(self, table_name: str, descriptions: str) -> None:
        """
        add descriptions to the FuncObject
        parse aff descriptions format as <X: the description of X\n>
        """
        if not isinstance(descriptions, str):
            raise ValueError("Descriptions must be a string.")
        if table_name not in self.sourceListDict:
            raise ValueError(f"Table {table_name} not found in FuncObject.")
        
        self.full_description = self.full_description + '\n' + descriptions
        self.querier.set_attr_descriptions(self.full_description)
        
        indexer_list = self.sourceListDict.get(table_name)
        for indexer_name in indexer_list:
            indexer = self.indexerDict.get(indexer_name)
            if not isinstance(indexer, SingleIndexer):
                raise TypeError(f"Indexer {indexer_name} is not a SingleIndexer.")
            # Sample
            print("trying to sample indexer", indexer_name, " with columns: ", descriptions)
            self.sampler.append_schema(descriptions)
            self.sampler.try_sample(indexer, descriptions)
        #print("evidence:\n", self.sampler.get_evidence())
        #print("sample_table:\n", self.sampler.sample_table)
        new_description = self.extract_attr_descriptions_from_schema(descriptions)

        for key, value in new_description.items():
            if key not in self.descriptions:
                self.descriptions[key] = value
            else:
                print(f"Warning: Description for {key} already exists. Skipping update.")

    def add_global_source(self, gb_indexer: GlobalIndexer) -> None:
        self.global_indexer = gb_indexer

    def add_source(self, indexer: SingleIndexer, indexer_name: str, table_name: str) -> None:
        """
        add a source, an indexer
        """
        self.sourceListDict.setdefault(table_name, [])
        self.sourceListDict[table_name].append(indexer_name)
        self.indexerDict.setdefault(indexer_name, indexer)
        self.packStorage.add_source(indexer_name, table_name)

    def clear_source(self) -> None:
        """
        clear all sources
        """
        self.sourceListDict.clear()
        self.indexerDict.clear()
        self.packStorage.clear()

    def show_table(self, table_name: str) -> pd.DataFrame:
        """
        show the table
        """
        if table_name not in self.packStorage.TablePackDict:
            raise ValueError(f"Table {table_name} not found in FuncObject.")
        
        table_pack_list = self.packStorage.get_table_pack(table_name)
        for table_pack in table_pack_list:
            if not isinstance(table_pack, TablePack):
                raise TypeError(f"Expected TablePack, got {type(table_pack)}")
            return table_pack.table if table_pack else pd.DataFrame()
        return pd.DataFrame()
    
    def transform_text_pack_to_json(self, text_pack: BaseTextPack) -> str:
        """
        transform text pack to json
        """
        res = ""
        if isinstance(text_pack, TextPack):
            res = ClassToJson.toJsonStatic(text_pack) + "\n"
        elif isinstance(text_pack, TextListPack):
            for x in text_pack.textList:
                now = TextPack(text_pack.doc_id, x, text_pack.column)
                res += ClassToJson.toJsonStatic(now) + "\n"
        elif isinstance(text_pack, TextDictPack):
            for column, text_list in text_pack.textDict.items():
                for x in text_list:
                    now = TextPack(text_pack.doc_id, x, column)
                    res += ClassToJson.toJsonStatic(now) + "\n"
        else:
            raise TypeError(f"Unsupported text pack type: {type(text_pack)}")
        return res

    def show_text(self, table_name: str) -> str:
        """
        get all the text have retrieved from the source
        """
        if table_name not in self.packStorage.TablePackDict:
            raise ValueError(f"Table {table_name} not found in FuncObject.")
        text_pack_list = self.packStorage.get_text_pack(table_name)
        js = ""
        for text_pack in text_pack_list:
            js += self.transform_text_pack_to_json(text_pack)
        return js

    def retrieve_text(self, table_name: str, columns: list[str]) -> FuncObject:
        """
        retrieve text from the source
        """
        if table_name not in self.sourceListDict:
            raise ValueError(f"Table {table_name} not found in FuncObject.")

        indexer_list = self.sourceListDict.get(table_name)
        for indexer_name in indexer_list:
            indexer = self.indexerDict.get(indexer_name)
            if not isinstance(indexer, SingleIndexer):
                raise TypeError(f"Indexer {indexer_name} is not a SingleIndexer.")
            
            output = RetrieveOperation.retrieve_text(table_name, columns, indexer, self.sampler)
            self.parse_output(table_name, output)
        
        return self

    def extract_text(self, table_name: str, column_names: list[str]) -> FuncObject:
        """
        extract data from the source
        """
        if table_name not in self.sourceListDict:
            raise ValueError(f"Table {table_name} not found in FuncObject.")
        
        # get needed packs
        input = self.packStorage.get_packs(table_name)
        output = ExtractOperation.extract_text(table_name, column_names, input, self.querier)
        self.parse_output(table_name, output)

        return self

    def filter_text(self, table_name: str, column_names: list[str], filter_conditions: str) -> FuncObject:
        """
        filter data from the source
        这里涉及到一个是不是需要使用filter优化的问题，如果使用，那就要对conditions进行解析，如果不用，就可以整体分析
        解析可以组装成SQL parser的形式进行复用
        """
        if table_name not in self.sourceListDict:
            raise ValueError(f"Table {table_name} not found in FuncObject.")

        from quest.sql.func.convert_utils import convert_conditions_to_filter_node
        filter_node = convert_conditions_to_filter_node(table_name, filter_conditions)
        
        input = self.packStorage.get_packs(table_name)
        output = FilterOperation.filter_text(table_name, column_names, filter_node, input, self.querier)
        self.parse_output(table_name, output)

        return self
    
    def projection_text(self, table_name: str, columns: list[str]) -> FuncObject:
        """
        project certain columns from the source
        """
        if table_name not in self.sourceListDict:
            raise ValueError(f"Table {table_name} not found in FuncObject.")


        input = self.packStorage.get_packs(table_name)
        output = ProjectionOperation.projection_text(table_name, columns, input, self.global_indexer)
        self.parse_output(table_name, output)

        return self
        
        