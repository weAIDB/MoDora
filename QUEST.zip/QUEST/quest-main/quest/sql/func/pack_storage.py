from quest.core.datapack import *

class PackStorage:
    """
    PackStorage is a class that manages the storage of data sources and their associated indexers.
    It allows adding sources, clearing them, and retrieving the list of sources for a given table.
    """

    def __init__(self):
        self.DocListPackDict = {} # {table_name: DocListPack}
        self.TextPackListDict = {} # {table_name: list[TextPack/TextListPack/TextDictPack]}
        self.TablePackDict = {} # {table_name: TablePack}  

    def clear(self) -> None:
        """
        Clear all stored packs.
        """
        self.DocListPackDict.clear()
        self.TextPackListDict.clear()
        self.TablePackDict.clear()

    def add_source(self, name: str, table_name: str) -> None:
        """
        Add a source with its associated indexer to the storage.
        
        :param name: The name of the source.
        :param indexer: The indexer associated with the source.
        :param table_name: The name of the table where the source is stored.
        """
        self.DocListPackDict.setdefault(table_name, [])
        self.TextPackListDict.setdefault(table_name, [])
        self.TablePackDict.setdefault(table_name, [])

    def delect_pack(self, table_name: str) -> None:
        """
        Delect the pack not in DocListPackDict
        """
        if table_name in self.DocListPackDict:
            del self.DocListPackDict[table_name]
        if table_name in self.TextPackListDict:
            del self.TextPackListDict[table_name]
        if table_name in self.TablePackDict:
            del self.TablePackDict[table_name]

    def get_packs(self, table_name: str) -> list:
        """
        Get the list of packs for a given table name.
        
        :param table_name: The name of the table to retrieve packs from.
        :return: A list of packs associated with the specified table.
        """
        res = []
        res.extend(self.get_text_pack(table_name))
        res.extend(self.get_doc_list_pack(table_name))
        res.extend(self.get_table_pack(table_name))
        return res

    def update_text_pack(self, table_name: str, text_pack_list: list) -> None:
        """
        Update the TextPack for a given table name.
        
        :param table_name: The name of the table to update.
        :param text_pack: The TextPack object to be updated.
        """
        print("now update text pack for table: ", table_name)
        print("text_pack_list: ", text_pack_list)
        self.TextPackListDict[table_name] = text_pack_list

    def get_text_pack(self, table_name: str) -> list:
        """
        Get the list of TextPack for a given table name.
        
        :param table_name: The name of the table to retrieve TextPacks from.
        :return: A list of TextPack objects associated with the specified table.
        """
        return self.TextPackListDict.get(table_name, [])
    
    def get_doc_list_pack(self, table_name: str) -> list:
        """
        Get the DocListPack for a given table name.
        
        :param table_name: The name of the table to retrieve the DocListPack from.
        :return: A DocListPack object associated with the specified table.
        """
        return self.DocListPackDict.get(table_name, [])

    def update_doc_list_pack(self, table_name: str, doc_list_pack: DocListPack) -> None:
        """
        Update the DocListPack for a given table name.
        
        :param table_name: The name of the table to update.
        :param doc_list_pack: The DocListPack object to be updated.
        """
        self.DocListPackDict[table_name] = [doc_list_pack]
    
    def get_table_pack(self, table_name: str) -> list:
        """
        Get the TablePack for a given table name.
        
        :param table_name: The name of the table to retrieve the TablePack from.
        :return: A TablePack object associated with the specified table.
        """
        return self.TablePackDict.get(table_name, [])

    def update_table_pack(self, table_name: str, table_pack: TablePack) -> None:
        """
        Update the TablePack for a given table name.
        
        :param table_name: The name of the table to update.
        :param table_pack: The TablePack object to be updated.
        """
        self.TablePackDict[table_name] = [table_pack]
        