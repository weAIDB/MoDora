from quest.sql.planner.joinlogical import JoinLogicalPlanner
from quest.sql.planner.grouplogical import GroupLogicalPlanner
from quest.sql.planner.baselogical import BaseLogicalPlanner

class LogicalPlanner(object):
    def __init__(self):
        # as default
        self.planner = BaseLogicalPlanner()

    def extract_binary_condition(self, node):
        res = []
        if not isinstance(node, astn.BinaryOperationExpr):
            raise Exception('Not a Binary!')
        if node.op in sqlconst.LOGIC_TUPLE:
            # AND / OR
            res.extend(self.extract_binary_condition(node.lhs))
            res.extend(self.extract_binary_condition(node.rhs))
        else:
            # >, <, <>, =, >=, <= 
            if isinstance(node.rhs, astn.ColumnExpr):
                now = BinaryNode(node.lhs, node.op, node.rhs)
                res.append(copy.copy(now))
        return res
    
    def extract_conditions_from_whereClause(self, whereClause):
        if isinstance(whereClause, astn.WhereExpr):
            return self.extract_binary_condition(whereClause.value)
        return []

    def select_logical_plan(self, selectStmt):
        
        """
        SELECT [DISTINCT] <select_list>
        FROM <table_source>
        [JOIN <join_condition_list>]
        [WHERE <where_condition>]
        [GROUP BY <group_by_list>]
        [HAVING <having_condition>]
        [ORDER BY <order_by_list>]
        [LIMIT <limit_number>]
        FROM -> JOIN -> WHERE -> GROUP BY -> HAVING -> SELECT -> DISTINCT -> ORDER BY -> LIMIT

        We consider the best planner here
        """
        if not isinstance(selectStmt, astn.SelectExpr):
            raise Exception('Not a Select Node!')
        
        join_conditions = self.extract_conditions_from_whereClause(selectStmt.whereClause) # join connection with A.t = B.t
        proj_attrs = copy.copy(selectStmt.selectClause.value) # a list of columnExpr and FunctionExpr

        group_attrs = []
        if  selectStmt.groupbyClause!=None:
            group_attrs = selectStmt.groupbyClause.value 
            group_attrs = remove_duplicates_columns(group_attrs) # group by attrs, a list of ColumnExpr
        group_columns = column_util.parse_column_and_func(group_attrs) # group by columns, a list of ColumnExpr and FunctionExpr

        # if no group, no join, use common SFW

        if group_attrs == [] and join_conditions == []:
            self.planner = BaseLogicalPlanner()
        elif group_attrs != [] and join_conditions == []:
            self.planner = GroupLogicalPlanner()
        elif group_attrs == [] and join_conditions != []:
            self.planner = JoinLogicalPlanner()
        else:
            self.planner = BaseLogicalPlanner()
            # self.planner = FullLogicalPlanner()

    def build_logical_plan(self, selectStmt):
        """
        Build the logical plan for the given select statement.
        """
        self.select_logical_plan(selectStmt)
        return self.planner.build_logical_plan(selectStmt)