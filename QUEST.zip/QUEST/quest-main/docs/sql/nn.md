# nn

管理所有算子，包含逻辑算子与物理算子。

# Base

所有算子的基类``Base.py``。

### 类属性

- `name` - name of the class
- `input` - a list of nn
- `output` - a list of [datapack](/core/datapack)
- `additionDict` - any additional data
- `visited` - `0 = unvisited`, `1 = visiting`, `2 = visited`, use for build plan graph
- `indexer` - a [SingleIndexer](/core/indexer), or `None`

### 类方法

```
def set_indexer(self, x):
    self.indexer = x

def set_unvisited(self):
    self.visited = 0

def set_input(self, x):
    self.input = x

def get_input(self):
    return self.input

def get_output(self):
    return self.output

def get_addtion(self):
    return self.additionDict

def append_input(self, x):
    self.input.append(x)

def extend_input(self, x):
    self.input.extend(x)

def append_output(self, x):
    self.output.append(x)

def extend_output(self, x):
    self.output.extend(x)

def add_info(self, key, val):
    self.additionDict.setdefault(key, val)
```

# Logical

逻辑算子的组合描述了逻辑计划，每个逻辑算子可以对应多种不同的物理算子。

| <div style="width: 200px">算子 </div> | <div style="width: 520px">描述</div>   |
| -------------------- | -------------------------------------------------- |
| [`LogicalRetrieve`](/sql/nn/retrieve)    | 逻辑检索算子，包含了检索类型信息和表信息等         |
| [`LogicalExtract`](/sql/nn/extract)     | 逻辑抽取算子，包含提取列信息和表信息等             |
| [`LogicalFilter`](/sql/nn/filter)      | 逻辑过滤算子，包含提取列信息、过滤条件、表信息等   |
| [`LogicalGroup`](/sql/nn/group)       | 逻辑分组算子，包含分组列信息、分组条件、分组方案等 |
| [`LogicalAggregation`](/sql/nn/aggregation) | 逻辑聚合算子，包含聚合列信息、聚合条件等     |
| [`LogicalJoin`](/sql/nn/join)        | 逻辑连接算子，包含连接列信息、连接判断方式等       |
| [`LogicalProjection`](/sql/nn/projection)  | 逻辑投影算子，包含投影列信息等           |
| [`LogicalSort`](sql/nn/sort)        | 逻辑排序算子，包含排序条件等                       |
| [`LogicalLimit`](sql/nn/limit)       | 逻辑限制算子，包含限制信息等                       |
| [`LogicalDistinct`](sql/nn/distinct)     | 逻辑去重算子，包含去重列、去重方式等。             |


# Physical

物理算子描述了操作对应的物理实现方式，物理算子的组合描述了物理计划。每个物理算子继承自其相应实现的基类。

| <div style="width: 200px">算子 </div> | <div style="width: 520px">描述</div>   |
| -------------------- | -------------------------------------------------- |
| [`Retrieve`](/sql/nn/retrieve) | 物理检索算子，包含了检索类型信息、检索源信息、表信息等         |
| [`Extract`](/sql/nn/extract)     | 物理抽取算子，包含提取列信息、提取方式、表信息等             |
| [`Filter`](/sql/nn/filter)      | 物理过滤算子，包含提取列信息、过滤条件、表信息等   |
| [`Group`](/sql/nn/group)       | 物理分组算子，包含分组列信息、分组条件、分组方案等 |
| [`Aggregation`](/sql/nn/aggregation) | 物理聚合算子，包含聚合列信息、聚合条件等           |
| [`Join`](/sql/nn/join)        | 物理连接算子，包含连接列信息、连接方式、连接判断方式等       |
| [`Projection`](/sql/nn/projection)  | 物理投影算子，包含投影列信息等                     |
| [`Sort`](sql/nn/sort)        | 物理排序算子，包含排序条件等                       |
| [`Limit`](sql/nn/limit)       | 物理限制算子，包含限制信息等                       |
| [`Distict`](sql/nn/distinct)     | 物理去重算子，包含去重列、去重方式等。             |

### 类方法

物理算子统一实现process方法，用于实现执行这一算子的整个流程。

```
@abstractmethod
def process(self):
    pass
```