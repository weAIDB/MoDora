# LogicalRetrieve

逻辑检索算子，描述了检索过程。

### 类属性

- `columns` - a list of ColumnExpr
- `table`- the retrieve table name
-  `type` - the retrieve type ('Photo'/'Text'/..)


# Retrieve

物理检索算子的基类，实现对指定数据的召回，包括文档/文本块/图像等。

### 类属性

- `sampler` - a [Sampler](/core/sampler) or `None`, use to get the evidence
- `retrieveList` - a list of retrieve ID of the chunks/photos/... , an `ID` can access to a unique element together with `type`

### 类方法

```
def set_retrieveList(self, x):
    self.retrieveList = x

def set_sampler(self, x):
    self.sampler = x
```

# RetrieveText

文本块的检索算子，用于在向量数据库中召回最相似的文本段，输出为`TextPack`

# RetrievePhoto

图像的检索算子，用于在向量数据库中召回最相似的图片，输出为`PhotoPack`

# RetrieveFull

全文检索的检索算子，检索分为两步，第一步通过全文检索召回阈值内的文档，第二步在向量数据库中召回这些文档内最相似的文本段。`type` 表示全文检索的类型，分为`document`,`chunk`,`sentence`级别，输出为`TextPack`


