# LogicalFilter

逻辑过滤算子，描述了过滤筛选的过程。

### 类属性

- `columns` - a list of ColumnExpr
- `table`- the filter table name
- `type` - the filter type ('Photo'/'Text'/..)
- `root` - the filter tree root, filter tree is a tree of [`FilterNode`]()


# Filter

物理检索算子的基类，实现对指定列的过滤功能。支持以下两种方式：提取后过滤、同时提取过滤。对于数值类型属性或指定值域属性采用前者，而对于其他属性采用后者。

### 类属性

-  `querier` - the LLM query object

### 类方法

```
def set_querier(self, x):
        self.querier = x
```

# FilterText

文本块的过滤算子，用于过滤出符合条件的文档和获得过滤条件对应的值。

# FilterPhoto

图像的过滤算子，用于过滤出符合条件的图片和获得过滤条件对应的值。

