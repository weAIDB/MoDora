    # 数据库连接参数
    db_config = {
        "host": "127.0.0.1",
        "port": 18874,
        "database": "testdb",
        "user": "remote_user",
        "password": "dmE43-3654"
    }