
# Connector
抽象类

提供数据库连接对象初始化，注册数据库方言等。

&todo 提供的数据库连接对象用于：
- 实现Querier中对应的方法-标量SQL查询
- 实现VectorDBIndexStorage中的向量sql查询，不用建向量索引，而是通过doc_id前过滤。
