**indexer包**
系统中每个表(主题)中的文档有1个DocIndexer和1个TextChunkIndexer

# GlobalIndexer类

## 描述
这个类用于维护所有的SingleIndexer，即所有表的索引。

## 方法
- **get_indexer(table_name) -> SingleIndexer, str**
  - 参数说明：
    - table_name：索引名称, 表名/文档集合的主题
  - 返回值：对应的SingleIndexer实例和索引类型type(包括"TextDoc"和"PdfDoc"等)

- **build_indexer(tables_name : list[str] , types:list[str] , table2docs :  dict[str, list[Doc]])**
	- 功能：
		- 分别建立table_name到single_indexer和type的映射
		- 依次调用每个表的SingleIndexer，建立二级索引
	- 参数说明:
		- tables_name: list[str], 用户文档集合中所有包含的表名
		- types:list[str] , 每个表中对应的文档类型，即SingleIndexer的类名，顺序与tables_name对应。
		- table2docs: dict[str, list[Doc]] 表到文档集合的映射。


- **save_indexer()**
    - 功能：
      - 存储tables_name到type的映射到磁盘上。
      - 依次调用每个表的SingleIndexer的save_indexer方法，将索引存储到磁盘上。


- load_indexer():
	- 功能：
    - 从磁盘加载构建map[table_name, type]，然后根据type信息构建dict[table_name, SingleIndexer]
		- 依次调用各个表的SingleIndexer的load_indexer。

# SingleIndexer类

## 描述
每个表有一个SingleIndexer。
这个类可以作为所有不同类型文档索引的基类，不同的输入文档可能有不同的索引策略，比如“纯文本文档”、"含图像的文本文档"、“带层级结构的文档(markdown/pdf)”。

## 属性
storage: IndexStorage对象，底层索引存储和查询
table_name: 关联的表的名字。
type: str，索引类型，表示文档的类型，比如"TextDoc"、"PdfDoc"等。
docs_meta : dict[int, dict[str, Any]] : 关联表里包含的文档元数据, 对于TextDocIndexer是 {doc_id: {"file_name": "xxx.txt", ...}}，对于PdfDocIndexer是{doc_id: {"file_name": "xxx.pdf", ...}}。
preprocessor: DocPreprocessor对象，文档预处理器，用于对文档进行分块、embedding等操作。(包含embedding_model和chunker等)
querier: Querier对象，用于缓存建立查询。

## 方法

- `__init__(table_name : str, type: str, **kwargs)`
  - 功能：
    - 初始化SingleIndexer实例，设置表名、索引类型和其他参数。
  - 参数说明：
    - table_name：表名，用于指定索引文件路径/数据库表名
    - type：索引类型，表示文档的类型，比如"TextDoc"、"PdfDoc"等。
    - kwargs：其他参数，可能包括storage、preprocessor等。

- **get_docs_id() -> list[int]**
  - 功能：文档索引：
  - 返回值：返回该表中的所有文档编号


- **build_indexer(docs: list[Doc] )**
	- 功能：
    - 构建docs_meta，获得map(doc_id, metadata)的映射),这个就算文档级索引\
    - 调用针对单个文档的预处理方法，比如用chunker对文档进行分块，注意chunk需要关联到其所在的doc_id。
    - 调用storage的build_index方法，建立索引。
    - 用table_name初始化Querier对象，建立缓存表，将docs_meta中的信息作为初始文档属性存储, 以doc_id为主键，存到opengauss数据库里，表名就是table_name
  - 说明：
    - 注意：每个文档对象Doc的id在它的metadata属性中。

- save_indexer()
  - 功能：
    - 调用storage的save_index方法，将索引存储到磁盘上。  
    
- load_indexer()
  - 功能：
    - 用table_name初始化Querier对象，加载缓存表并SELECT，从而恢复出属性docs_meta
    - 调用storage的load_index方法，加载索引。


# TextDocIndexer(SingleIndexer)

&todo
- **get_relative_chunks_text(doc_id: int, query: str, topk: int) -> list[str]**
  - 功能：查询指定文档中与query相关的文本块内容，需要调用storage的接口查询。
  - 参数说明：
    - doc_id：文档编号
    - query：查询字符串
    - topk：返回的相关块数量
  - 返回值：与query相关的topk个块内容列表

# HierarchicalTextDocIndexer(SingleIndexer)

# PdfDocIndexer(SingleIndexer)



# IndexStorage类

## 描述
实现索引存储和查询的最底层工具类，直接向SingleIndexer中封装的索引操作接口负责。

# TextIndexStorage(IndexStorage)

## 描述
基于文本的索引存储实现，支持对文本块的存储和检索。

# VectorDBTextIndexStorage(TextIndexStorage)

## 描述
将chunk和对应的embedding存储在向量数据库中，并为上层SingleIndexer提供接口

## 属性
db_conn: 向量数据库连接对象，负责与向量数据库进行交互。直接从settings.py中导入

## 方法

- __init__(table_name: str,  db_conn)
  - 功能：初始化VectorDBTextIndexStorage实例
  - 参数说明：
    - table_name：表名，用于构建文件路径
    - embedding_model：文本嵌入模型
    - db_conn：向量数据库连接对象

- **query(query_text: str, topk: int, doc_id: int = None) -> list[tuple[str, float, int]]**
    - 功能：查询与输入文本最相似的chunks
    - 参数说明：
        - query_text：查询文本
        - topk：返回最相似的chunk数量
        - doc_id：必须，限制在特定文档内查询
    - 返回值：[(chunk_text, similarity_score, doc_id), ...] 列表

- **build_index(doc2chunks: dict[int, list[str]], doc2embeddings: dict[int, list[np.ndarray]])**
  - 功能：
    - 根据doc_id到其中包含的chunks和对应的embeddings构建元组，存到opengauss向量数据库中。(不要在embedding列建索引)


- **save_index()**
    - 功能：pass


- **load_index()**
  - 功能：检查数据库里是否有这个表。
  - 返回值：如果表存在，返回True；否则返回False。

# GraphTextIndexStorage(TextIndexStorage)
利用llama-index等高级索引工具建立树索引或者图索引。

