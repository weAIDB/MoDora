处理针对数据库的所有原生SQL语句操作，为DocIndexer的数据库访问提供支持。
为不同的数据库后端提供统一的上层操作接口。
基于sqlAlchemy core的SQL语句执行器统一封装。
使用opengauss数据库，兼容postgreSQL语法

# Querier

这个类会被SingleIndexer调用，在build_indexer阶段调用时，它会build_cache_table,
docs_meta中的信息作为初始文档属性存储，以doc_id为主键，存到opengauss数据库里，表名就是table_name

build_cache_table(table_name: str, metadata_keys_list : list[str] ,docs_meta: dict[int, dict[str, Any]] )
用于建立缓存表，表名就是table_name，列名就是docs_meta的key，每个doc对应的值在docs_meta中。

cache_doc_attr(table_name: str, doc_id : int, attr: str, value )
用于缓存指定主题的某个文档的某个属性值

get_doc_attr(table_name: str, doc_id : int, attr: str) -> class(value)
用于获取指定主题的某个文档的某个属性值，返回值类型取决于属性值类型。

get_doc_attr_row(table_name: str, doc_id : int) -> dict[str, Any]
用于获取指定主题的某个文档的所有属性值列表，返回值map(attr, value)

get_table_attr_column(table_name: str, attr: str) -> dict[int, Any]:
用于获取指定主题的所有文档的某个属性的值列表，返回值map(doc_id, value)

## OpenGaussQuerier(Querier)
使用OpenGauss作为存储后端的Querier，需要实现父类的所有方法
