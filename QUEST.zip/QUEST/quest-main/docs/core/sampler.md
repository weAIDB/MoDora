# Sampler

反正是采样，init的时候肯定会把global indexer传进来，prompt忘记放在哪了

build_sample_table(tableList : list[str], Schema ... )

这个函数内的信息应该是通过 AST树解析得到，AST树也会传进来给Sampler