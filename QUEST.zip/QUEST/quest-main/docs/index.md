# QUEST

## 基本规范

### 文件层级

- 使用合适的层级划分即可，每个层级需要创建对应的``__init__.py``，并在文档中创建对应的``x.md``用于叙述每个子模块的内容
- [PyG](https://pytorch-geometric.readthedocs.io/en/latest/install/installation.html) 参考文档写法，还需要安装一下文档插件
- pyproject.toml配置

### 命名

- 建议使用精简的小写字母和下划线来命名文件夹和文件，使用下划线作为单词之间的分隔符可以提高名称的可读性（例如：``datapack``,``ast_node.py``）
- 建议使用大驼峰命名法来命名类（例如： ``Filter``, ``ValueExpr``），使用相应的小写和下划线来命名对应的py文件（例如：``filter.py``，``ast_node.py``)

### 调用

- 所有导入使用``quest``作为顶层，例如``from quest.sql.nn import *``，``from quest.conf import const``，必要时在``__init__.py``文件中指出``*``的引用范围 
- 部分迁移过来的小组件内部可以使用相对导入，即``from . import xxx``来导入同级模块，或者使用``from .. import xxx``来导入上级模块


### 测试

- 本地测试的main.py函数需要引入顶层路径，一个例子如下：

```
import sys
sys.path.append('D:\Work\projects\GitStore\quest') # windows
# sys.path.append('/data/QUEST/jzshe/project/quest') # linux
```

## 代码编写提示

对每个类或类方法，需要精确指出其可行的输入输出，最小化接口需要传输的信息来实现需求。
需要涉及尽可能完整的类和方法，使得主程序中应当只包含类和类方法，而不涉及对数据进行处理（例如，采样操作可以只通过构造采样器，然后结合索引器和SQL解析出的Schema得到，不需要在主程序中执行循环）。

一个具体的思考过程如下：

考虑现在需要将``LogicalRetrieve``逻辑算子转``TextRetrieve``物理算子，使得物理算子执行能够检索出文本段，需要什么信息。

``LogicalRetrieve``逻辑算子中只包含SQL中能解析出的``Table``、``Column``，而``TextRetrieve``需要的信息有``SingleIndexer``（表对应的索引）、``DocID``（索引中查询的文档编号）、``Text``（采样出的文本段）、``Attr_name``(属性名)、``Attr_description(属性描述)``，这样算子可以通过文档编号+采样文本段+属性名+属性描述，在索引中查找TOP-K相似的文本块，从而得到输出。

- `` SingleIndexer``需要通过全局索引``Indexer``和表的信息来获得
- ``DocID``需要从``SingleIndexer``中获得该索引的编号
- ``Text``需要从采样表中获得

那么我们要支持以下的操作：

- 在``Indexer``中用``Table``和类别（Text、Figure...）获得 ``SingleIndexer``，对文本模态它可以是``TextIndexer``
- 在``TextIndexer``中用``get_indexList``获得``DocID``，或者图像id之类的
- 在``Sampler``中用``Table``和``Column``获得``Text``
- 在``TextIndexer``中用``get_textChunks(DocID, Text)``获得索引出的和``Text``相似的文本段内容

当然，还要考虑多模态的内容，这点通过更换索引器和采样器应当可以实现。