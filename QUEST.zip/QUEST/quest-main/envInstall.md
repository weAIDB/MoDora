
# conda环境部署

```
conda create -n  quest  python=3.10.16
pip install torch==2.1.2 torchvision==0.16.2 torchaudio==2.1.2 --index-url https://download.pytorch.org/whl/cu121
pip install -r  requirements.txt
python -m spacy download en_core_web_sm
python -m spacy download  en_core_web_md

```


# 向量数据库安装
quest的二级索引需要建立在向量数据库上。
需要安装postgreSQL及其对应的向量扩展pgvector。
或者使用华为的opengauss。
建议使用docker容器进行安装。


安装后使用python-sdk连接到数据库
将下面的配置信息替换成自己安装数据库时的配置，填写到
quest/db/connector/connector.py create_opengauss_engine   line62
```
    # 数据库连接参数
    db_config = {
        "host": "127.0.0.1",
        "port": 18874, # 部署数据库时映射的宿主机访问的端口
        "database": "testdb",
        "user": "remote_user",
        "password": "dmE43-3654"
    }
```

具体安装说明见：
opengauss
https://opengauss.org/en/
postgreSQL:
https://www.postgresql.org/


## 示例数据库安装配置
下面以opengauss数据库为例说明数据库的安装和配置，postgreSQL的部署方法类似。
注：openGauss7.0.0-RC1版本内核中集成了向量检索功能，无需安装向量扩展。
如果您选择的是postgreSQL，之后补充安装pgvector插件即可，二者的语法是通用的。
```
下载镜像
wget   https://download-opengauss.osinfra.cn/archive_test/7.0.0-RC1/openGauss7.0.0-RC1.B023/openEuler20.03/x86/openGauss-Docker-7.0.0-RC1-x86_64.tar

加载镜像
sudo docker load -i openGauss-Docker-7.0.0-RC1-x86_64.tar

启动opengauss数据库容器
sudo  docker run --name opengauss --privileged=true -d -e GS_PASSWORD=数据库管理员密码 -p 宿主机访问的端口:5432  opengauss/opengauss-server:latest -v 宿主机持久化存储路径:/var/lib/opengauss 

成功启动容器后，进入容器内部创建用于测试的数据库：

先用管理员账户创建普通用户(管理员账户不能用于远程连接)
sudo  docker exec -it  opengauss  bash
su omm
gsql -d postgres -p 5432
CREATE USER remote_user WITH PASSWORD '你的远程连接密码';
ALTER USER remote_user CREATEDB;
GRANT ALL PRIVILEGES TO remote_user;

ctrl+d退出管理员账户，并登录普通账户创建用于远程连接的数据库
gsql -U remote_user -d postgres -p 5432
输入 '你的远程连接密码'
CREATE DATABASE testdb OWNER remote_user;

```
上述命令执行完毕后，即可正常使用。

